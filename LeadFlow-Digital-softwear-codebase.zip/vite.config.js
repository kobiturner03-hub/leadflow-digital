import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import tailwindcss from '@tailwindcss/vite'
import fs from 'fs'
import path from 'path'

// Plugin to serve the real supabase bundle for ANY old cached hash
function supabaseCacheFixPlugin() {
  return {
    name: 'supabase-cache-fix',
    configureServer(server) {
      server.middlewares.use((req, res, next) => {
        if (req.url && req.url.includes('@supabase_supabase-js.js')) {
          const realFile = path.resolve('node_modules/@supabase/supabase-js/dist/index.mjs')
          if (fs.existsSync(realFile)) {
            const content = fs.readFileSync(realFile, 'utf8')
            res.setHeader('Content-Type', 'application/javascript')
            res.setHeader('Cache-Control', 'no-store')
            res.end(content)
            return
          }
        }
        next()
      })
    }
  }
}

export default defineConfig({
  plugins: [supabaseCacheFixPlugin(), react(), tailwindcss()],
  optimizeDeps: {
    force: true,
    exclude: ['@supabase/supabase-js']
  },
  server: {
    port: 5173,
    host: '0.0.0.0',
    strictPort: true,
    headers: {
      'Cache-Control': 'no-store, no-cache, must-revalidate'
    }
  }
})
