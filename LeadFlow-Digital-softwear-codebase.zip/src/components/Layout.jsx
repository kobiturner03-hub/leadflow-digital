import { useState } from 'react'
import { NavLink, useNavigate, useLocation } from 'react-router-dom'
import { useApp } from '../context/AppContext'
import {
  LayoutDashboard, Users, Kanban, CalendarDays,
  BarChart2, Settings, LogOut, Menu, X, ShieldCheck, CreditCard
} from 'lucide-react'

const NAV_ITEMS = [
  { path: '/dashboard',   label: 'Dashboard',   icon: LayoutDashboard },
  { path: '/leads',       label: 'Leads',        icon: Users },
  { path: '/pipeline',    label: 'Pipeline',     icon: Kanban },
  { path: '/bookings',    label: 'Bookings',     icon: CalendarDays },
  { path: '/analytics',   label: 'Analytics',    icon: BarChart2 },
  { path: '/billing',     label: 'Billing',      icon: CreditCard },
  { path: '/settings',    label: 'Settings',     icon: Settings },
]

const ADMIN_NAV = [
  { path: '/users', label: 'User Management', icon: ShieldCheck },
]

const PAGE_TITLES = {
  '/dashboard':   'Dashboard',
  '/leads':       'Leads',
  '/pipeline':    'Pipeline',
  '/bookings':    'Bookings',
  '/analytics':   'Analytics',
  '/billing':     'Billing & Subscription',
  '/settings':    'Settings',
  '/users':       'User Management',
}

// LeadFlow brand colours
const BRAND = {
  navy:      '#0d1f3c',
  navyLight: '#132848',
  blue:      '#0ea5e9',
  blueDark:  '#0284c7',
  green:     '#22c55e',
}

export default function Layout({ children }) {
  const { currentUser, logout } = useApp()
  const navigate = useNavigate()
  const { pathname } = useLocation()
  const [sidebarOpen, setSidebarOpen] = useState(false)

  const handleLogout = () => { logout(); navigate('/login') }

  return (
    <div className="flex h-screen overflow-hidden" style={{ background: '#f0f4f8' }}>
      {sidebarOpen && (
        <div
          className="fixed inset-0 z-20 lg:hidden"
          style={{ background: 'rgba(0,0,0,0.5)', backdropFilter: 'blur(2px)' }}
          onClick={() => setSidebarOpen(false)}
        />
      )}

      <aside
        className={`fixed inset-y-0 left-0 z-30 flex flex-col lg:static lg:translate-x-0 transition-transform duration-300 ${sidebarOpen ? 'translate-x-0' : '-translate-x-full'}`}
        style={{ width: 252, background: BRAND.navy, borderRight: '1px solid rgba(255,255,255,0.06)' }}
      >
        {/* Logo area — large and prominent */}
        <div className="flex items-center justify-between px-4" style={{ borderBottom: '1px solid rgba(255,255,255,0.08)', background: 'rgba(0,0,0,0.18)', height: 64, overflow: 'hidden' }}>
          <div style={{ display: 'flex', alignItems: 'center', height: '100%', overflow: 'hidden', flex: 1 }}>
            <img
              src="/leadflow-logo.png"
              alt="LeadFlow Digital"
              style={{ height: 110, width: 'auto', objectFit: 'contain', flexShrink: 0 }}
            />
          </div>
          <button onClick={() => setSidebarOpen(false)} className="lg:hidden" style={{ color: 'rgba(255,255,255,0.4)', marginLeft: 8 }}>
            <X size={17} />
          </button>
        </div>

        <p className="px-5 pt-5 pb-2 text-[10px] font-semibold tracking-widest uppercase" style={{ color: 'rgba(255,255,255,0.22)' }}>
          Menu
        </p>

        <nav className="flex-1 px-3 space-y-0.5 overflow-y-auto scrollbar-thin pb-4">
          {NAV_ITEMS.map(({ path, label, icon: Icon }) => (
            <NavLink
              key={path}
              to={path}
              onClick={() => setSidebarOpen(false)}
              style={({ isActive }) => isActive
                ? { display:'flex', alignItems:'center', gap:10, padding:'9px 12px', borderRadius:12, background:`rgba(14,165,233,0.18)`, color:'#fff', fontSize:14, fontWeight:600, textDecoration:'none', borderLeft:`3px solid ${BRAND.blue}` }
                : { display:'flex', alignItems:'center', gap:10, padding:'9px 12px', borderRadius:12, color:'rgba(255,255,255,0.48)', fontSize:14, fontWeight:500, textDecoration:'none', borderLeft:'3px solid transparent' }
              }
            >
              {({ isActive }) => (
                <>
                  <span
                    className="flex items-center justify-center rounded-lg flex-shrink-0"
                    style={{ width:28, height:28, background: isActive ? BRAND.blue : 'rgba(255,255,255,0.07)', color: isActive ? '#fff' : 'rgba(255,255,255,0.4)' }}
                  >
                    <Icon size={14} />
                  </span>
                  <span style={{ flex:1 }}>{label}</span>
                  {isActive && <span style={{ width:6, height:6, borderRadius:'50%', background: BRAND.green, flexShrink:0 }} />}
                </>
              )}
            </NavLink>
          ))}

          {/* Admin-only section */}
          {currentUser?.role === 'admin' && (
            <>
              <p className="px-3 pt-4 pb-1 text-[10px] font-semibold tracking-widest uppercase" style={{ color: 'rgba(255,255,255,0.18)' }}>Admin</p>
              {ADMIN_NAV.map(({ path, label, icon: Icon }) => (
                <NavLink
                  key={path}
                  to={path}
                  onClick={() => setSidebarOpen(false)}
                  style={({ isActive }) => isActive
                    ? { display:'flex', alignItems:'center', gap:10, padding:'9px 12px', borderRadius:12, background:`rgba(34,197,94,0.15)`, color:'#fff', fontSize:14, fontWeight:600, textDecoration:'none', borderLeft:`3px solid ${BRAND.green}` }
                    : { display:'flex', alignItems:'center', gap:10, padding:'9px 12px', borderRadius:12, color:'rgba(255,255,255,0.45)', fontSize:14, fontWeight:500, textDecoration:'none', borderLeft:'3px solid transparent' }
                  }
                >
                  {({ isActive }) => (
                    <>
                      <span
                        className="flex items-center justify-center rounded-lg flex-shrink-0"
                        style={{ width:28, height:28, background: isActive ? BRAND.green : 'rgba(255,255,255,0.07)', color: isActive ? '#fff' : 'rgba(255,255,255,0.4)' }}
                      >
                        <Icon size={14} />
                      </span>
                      <span style={{ flex:1 }}>{label}</span>
                      {isActive && <span style={{ width:6, height:6, borderRadius:'50%', background: BRAND.blue, flexShrink:0 }} />}
                    </>
                  )}
                </NavLink>
              ))}
            </>
          )}
        </nav>

        <div className="px-3 pb-4 pt-3" style={{ borderTop: '1px solid rgba(255,255,255,0.07)' }}>
          <div className="flex items-center gap-3 px-3 py-2.5 rounded-xl" style={{ background: 'rgba(255,255,255,0.05)' }}>
            <div className="w-8 h-8 rounded-full flex items-center justify-center text-white text-xs font-bold flex-shrink-0"
              style={{ background: `linear-gradient(135deg,${BRAND.blue},${BRAND.blueDark})` }}>
              {currentUser?.name?.charAt(0)}
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-white text-xs font-semibold truncate leading-tight">{currentUser?.name}</p>
              <p className="text-xs truncate mt-0.5 capitalize" style={{ color: 'rgba(255,255,255,0.32)' }}>{currentUser?.role}</p>
            </div>
            <button onClick={handleLogout} title="Sign out" style={{ color: 'rgba(255,255,255,0.3)', background:'none', border:'none', cursor:'pointer', padding:4 }}
              onMouseEnter={e => e.currentTarget.style.color='#f87171'}
              onMouseLeave={e => e.currentTarget.style.color='rgba(255,255,255,0.3)'}>
              <LogOut size={15} />
            </button>
          </div>
        </div>
      </aside>

      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        <header className="flex-shrink-0 flex items-center justify-between px-5 lg:px-7"
          style={{ height:58, background:'#fff', borderBottom:'1px solid #e2e8f0', boxShadow:'0 1px 3px rgba(0,0,0,0.05)' }}>
          <div className="flex items-center gap-3">
            <button onClick={() => setSidebarOpen(true)} className="lg:hidden" style={{ color:'#64748b', background:'none', border:'none', cursor:'pointer', padding:4 }}>
              <Menu size={20} />
            </button>
            <p className="font-semibold text-slate-800 text-sm">{PAGE_TITLES[pathname] || 'LeadFlow Digital'}</p>
          </div>
          <div className="flex items-center gap-3">
            <div className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-full"
              style={{ background:'#f0fdf4', border:`1px solid #bbf7d0` }}>
              <span className="w-1.5 h-1.5 rounded-full" style={{ background: BRAND.green, animation:'pulse 2s infinite' }} />
              <span className="text-xs font-semibold" style={{ color:'#15803d' }}>Live</span>
            </div>
            <div className="flex items-center gap-2.5">
              <div className="text-right hidden sm:block">
                <p className="text-xs font-semibold text-slate-700 leading-none">{currentUser?.name}</p>
                <p className="text-xs text-slate-400 mt-0.5 capitalize">{currentUser?.role}</p>
              </div>
              <div className="w-8 h-8 rounded-full flex items-center justify-center text-white text-xs font-bold"
                style={{ background:`linear-gradient(135deg,${BRAND.blue},${BRAND.blueDark})` }}>
                {currentUser?.name?.charAt(0)}
              </div>
            </div>
          </div>
        </header>

        <main className="flex-1 overflow-y-auto scrollbar-thin">
          <div className="page-in">{children}</div>
        </main>
      </div>
    </div>
  )
}
