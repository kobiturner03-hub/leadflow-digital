import { useMemo } from 'react'
import { useApp } from '../context/AppContext'
import { TrendingUp, DollarSign, Clock, Users, ArrowUp, ArrowDown, ArrowRight, Briefcase, CalendarCheck, Activity, Wallet, RefreshCw, Calendar } from 'lucide-react'
import { AreaChart, Area, BarChart, Bar, Cell, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts'

const fmt  = n => new Intl.NumberFormat('en-AU',{style:'currency',currency:'AUD',maximumFractionDigits:0}).format(n)
const fmtK = n => n >= 1000 ? `$${(n/1000).toFixed(0)}k` : `$${n}`

// ── Real data helpers ─────────────────────────────────────────────────────────
function buildWeeklyData(leads) {
  const now = new Date()
  return Array.from({ length: 6 }, (_, i) => {
    const weeksAgo = 5 - i
    const end   = new Date(now); end.setDate(now.getDate() - weeksAgo * 7)
    const start = new Date(end); start.setDate(end.getDate() - 7)
    const slice = leads.filter(l => { const d = new Date(l.dateSubmitted); return d >= start && d < end })
    const rev   = slice.reduce((s, l) => s + (l.jobValue || 0), 0)
    const col   = slice.filter(l => l.paymentStatus === 'Paid').reduce((s, l) => s + (l.jobValue || 0), 0)
    return { w: `W${i + 1}`, rev, col }
  })
}

function buildMonthlyData(leads) {
  const now = new Date()
  return Array.from({ length: 6 }, (_, i) => {
    const monthsAgo = 5 - i
    const d     = new Date(now.getFullYear(), now.getMonth() - monthsAgo, 1)
    const start = new Date(d.getFullYear(), d.getMonth(), 1)
    const end   = new Date(d.getFullYear(), d.getMonth() + 1, 0, 23, 59, 59)
    const slice = leads.filter(l => { const ld = new Date(l.dateSubmitted); return ld >= start && ld <= end })
    const v     = slice.filter(l => l.paymentStatus === 'Paid').reduce((s, l) => s + (l.jobValue || 0), 0)
    const m = d.toLocaleDateString('en-AU', { month: 'short' })
    return { m, v }
  })
}

function getPctChange(leads, field, days = 30) {
  const now      = new Date()
  const cutThis  = new Date(now); cutThis.setDate(now.getDate() - days)
  const cutPrev  = new Date(now); cutPrev.setDate(now.getDate() - days * 2)
  const thisP    = leads.filter(l => new Date(l.dateSubmitted) >= cutThis)
  const prevP    = leads.filter(l => { const d = new Date(l.dateSubmitted); return d >= cutPrev && d < cutThis })
  const thisVal  = thisP.reduce((s, l) => s + (l[field] || 0), 0)
  const prevVal  = prevP.reduce((s, l) => s + (l[field] || 0), 0)
  if (prevVal === 0) return thisVal > 0 ? 100 : 0
  return Math.round(((thisVal - prevVal) / prevVal) * 100)
}

// ── Tooltip ───────────────────────────────────────────────────────────────────
const DarkTooltip = ({ active, payload, label }) => {
  if (!active || !payload?.length) return null
  return (
    <div style={{ background:'#0c1628', border:'1px solid rgba(255,255,255,0.1)', borderRadius:12, padding:'10px 14px', boxShadow:'0 8px 32px rgba(0,0,0,0.35)' }}>
      <p style={{ color:'rgba(255,255,255,0.45)', fontSize:11, marginBottom:6 }}>{label}</p>
      {payload.map((p,i) => (
        <p key={i} style={{ color:p.color, fontSize:13, fontWeight:600 }}>{p.name}: {fmt(p.value)}</p>
      ))}
    </div>
  )
}

const STATUS_BG = {
  'New Lead':     { bg:'rgba(59,130,246,0.08)',  color:'#0ea5e9' },
  'Contacted':    { bg:'rgba(245,158,11,0.1)',   color:'#b45309' },
  'Qualified':    { bg:'rgba(139,92,246,0.1)',   color:'#7c3aed' },
  'Quoted':       { bg:'rgba(249,115,22,0.1)',   color:'#c2410c' },
  'Won (Booked)': { bg:'rgba(34,197,94,0.1)',    color:'#15803d' },
  'Completed':    { bg:'rgba(16,185,129,0.1)',   color:'#065f46' },
}
const Chip = ({ label }) => {
  const s = STATUS_BG[label] || { bg:'#f1f5f9', color:'#64748b' }
  return <span style={{ background:s.bg, color:s.color, fontSize:11, fontWeight:600, padding:'3px 10px', borderRadius:20, whiteSpace:'nowrap' }}>{label}</span>
}

function PctBadge({ pct }) {
  const up = pct >= 0
  return (
    <span style={{ background:'rgba(255,255,255,0.18)', color:'#fff', fontSize:11, fontWeight:700, padding:'3px 10px', borderRadius:20, display:'flex', alignItems:'center', gap:3 }}>
      {up ? <ArrowUp size={9}/> : <ArrowDown size={9}/>} {Math.abs(pct)}%
    </span>
  )
}

export default function Dashboard() {
  const { getMetrics, getLeads, getBookings, currentUser } = useApp()
  const m      = getMetrics()
  const leads  = getLeads()
  const bkgs   = getBookings()

  const weeklyData  = useMemo(() => buildWeeklyData(leads),  [leads])
  const monthlyData = useMemo(() => buildMonthlyData(leads), [leads])
  const revPct      = useMemo(() => getPctChange(leads, 'jobValue', 30), [leads])
  const colPct      = useMemo(() => {
    const paidLeads = leads.filter(l => l.paymentStatus === 'Paid')
    return getPctChange(paidLeads, 'jobValue', 30)
  }, [leads])

  const recent   = leads.slice().sort((a,b)=>new Date(b.dateSubmitted)-new Date(a.dateSubmitted)).slice(0,5)
  const upcoming = bkgs.filter(b=>new Date(b.date+'T00:00:00')>=new Date(new Date().toDateString())).sort((a,b)=>new Date(a.date)-new Date(b.date)).slice(0,4)
  const colRate  = m.revenueGenerated > 0 ? Math.round(m.cashCollected/m.revenueGenerated*100) : 0
  const now      = new Date().toLocaleDateString('en-AU',{ weekday:'long', day:'numeric', month:'long' })

  const recurringLeads   = useMemo(() => leads.filter(l => l.isRecurring), [leads])
  const monthlyRecurring = useMemo(() => recurringLeads.reduce((s, l) => s + (l.recurringAmount || 0), 0), [recurringLeads])
  const annualRecurring  = monthlyRecurring * 12

  const daysUntil = (dateStr) => {
    if (!dateStr) return null
    return Math.ceil((new Date(dateStr) - new Date()) / (1000*60*60*24))
  }
  const urgencyColor = (days) => {
    if (days === null) return '#a78bfa'
    if (days <= 3) return '#ef4444'
    if (days <= 7) return '#f59e0b'
    return '#10b981'
  }

  return (
    <div style={{ background:'#f4f6f9', minHeight:'100%' }}>

      {/* ── Hero banner ── */}
      <div style={{ background:'linear-gradient(135deg,#0d1f3c 0%,#0a3a5c 60%,#062a44 100%)', padding:'28px 28px 80px' }}>
        <div style={{ display:'flex', alignItems:'flex-start', justifyContent:'space-between', marginBottom:28 }}>
          <div>
            <p style={{ color:'rgba(255,255,255,0.35)', fontSize:12, marginBottom:4 }}>{now}</p>
            <h1 style={{ color:'#fff', fontSize:22, fontWeight:700, letterSpacing:'-0.3px' }}>
              Welcome back, {currentUser?.name?.split(' ')[0]} 👋
            </h1>
            <p style={{ color:'rgba(255,255,255,0.4)', fontSize:13, marginTop:4 }}>Here's your live business snapshot</p>
          </div>
        </div>

        <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fit,minmax(200px,1fr))', gap:16 }}>
          {/* Revenue Generated */}
          <div style={{ background:'linear-gradient(135deg,#0284c7,#0ea5e9)', borderRadius:18, padding:'20px 22px', position:'relative', overflow:'hidden', boxShadow:'0 8px 32px rgba(14,165,233,0.35)' }}>
            <div style={{ position:'absolute', top:-20, right:-20, width:90, height:90, borderRadius:'50%', background:'rgba(255,255,255,0.07)' }}/>
            <div style={{ position:'absolute', bottom:-30, left:-10, width:70, height:70, borderRadius:'50%', background:'rgba(255,255,255,0.05)' }}/>
            <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', marginBottom:16, position:'relative' }}>
              <div style={{ width:36, height:36, borderRadius:10, background:'rgba(255,255,255,0.18)', display:'flex', alignItems:'center', justifyContent:'center' }}>
                <TrendingUp size={17} color="#fff"/>
              </div>
              <PctBadge pct={revPct}/>
            </div>
            <p style={{ color:'rgba(255,255,255,0.55)', fontSize:11, fontWeight:600, letterSpacing:'0.06em', textTransform:'uppercase', position:'relative' }}>Revenue Generated</p>
            <p style={{ color:'#fff', fontSize:28, fontWeight:800, letterSpacing:'-0.5px', marginTop:4, position:'relative' }}>{fmt(m.revenueGenerated)}</p>
            <p style={{ color:'rgba(255,255,255,0.45)', fontSize:11, marginTop:6, position:'relative' }}>from {m.completedJobs} completed jobs</p>
          </div>

          {/* Cash Collected */}
          <div style={{ background:'linear-gradient(135deg,#059669,#10b981)', borderRadius:18, padding:'20px 22px', position:'relative', overflow:'hidden', boxShadow:'0 8px 32px rgba(16,185,129,0.3)' }}>
            <div style={{ position:'absolute', top:-20, right:-20, width:90, height:90, borderRadius:'50%', background:'rgba(255,255,255,0.07)' }}/>
            <div style={{ position:'absolute', bottom:-30, left:-10, width:70, height:70, borderRadius:'50%', background:'rgba(255,255,255,0.05)' }}/>
            <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', marginBottom:16, position:'relative' }}>
              <div style={{ width:36, height:36, borderRadius:10, background:'rgba(255,255,255,0.18)', display:'flex', alignItems:'center', justifyContent:'center' }}>
                <Wallet size={17} color="#fff"/>
              </div>
              <PctBadge pct={colPct}/>
            </div>
            <p style={{ color:'rgba(255,255,255,0.55)', fontSize:11, fontWeight:600, letterSpacing:'0.06em', textTransform:'uppercase', position:'relative' }}>Cash Collected</p>
            <p style={{ color:'#fff', fontSize:28, fontWeight:800, letterSpacing:'-0.5px', marginTop:4, position:'relative' }}>{fmt(m.cashCollected)}</p>
            <p style={{ color:'rgba(255,255,255,0.45)', fontSize:11, marginTop:6, position:'relative' }}>{colRate}% collection rate</p>
          </div>

          {/* Outstanding */}
          <div style={{ background:'rgba(255,255,255,0.07)', border:'1px solid rgba(255,255,255,0.1)', borderRadius:18, padding:'20px 22px', backdropFilter:'blur(4px)' }}>
            <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', marginBottom:16 }}>
              <div style={{ width:36, height:36, borderRadius:10, background:'rgba(251,191,36,0.2)', display:'flex', alignItems:'center', justifyContent:'center' }}>
                <Clock size={17} color="#fbbf24"/>
              </div>
              <span style={{ background:'rgba(251,191,36,0.18)', color:'#fbbf24', fontSize:11, fontWeight:600, padding:'3px 10px', borderRadius:20 }}>Unpaid</span>
            </div>
            <p style={{ color:'rgba(255,255,255,0.4)', fontSize:11, fontWeight:600, letterSpacing:'0.06em', textTransform:'uppercase' }}>Outstanding</p>
            <p style={{ color:'#fff', fontSize:26, fontWeight:800, letterSpacing:'-0.4px', marginTop:4 }}>{fmt(m.outstanding)}</p>
            <p style={{ color:'rgba(255,255,255,0.35)', fontSize:11, marginTop:6 }}>Awaiting payment</p>
          </div>

          {/* Avg Job */}
          <div style={{ background:'rgba(255,255,255,0.07)', border:'1px solid rgba(255,255,255,0.1)', borderRadius:18, padding:'20px 22px', backdropFilter:'blur(4px)' }}>
            <div style={{ display:'flex', alignItems:'center', marginBottom:16 }}>
              <div style={{ width:36, height:36, borderRadius:10, background:'rgba(139,92,246,0.2)', display:'flex', alignItems:'center', justifyContent:'center' }}>
                <Briefcase size={17} color="#a78bfa"/>
              </div>
            </div>
            <p style={{ color:'rgba(255,255,255,0.4)', fontSize:11, fontWeight:600, letterSpacing:'0.06em', textTransform:'uppercase' }}>Avg Job Value</p>
            <p style={{ color:'#fff', fontSize:26, fontWeight:800, letterSpacing:'-0.4px', marginTop:4 }}>{fmt(m.avgJobValue)}</p>
            <p style={{ color:'rgba(255,255,255,0.35)', fontSize:11, marginTop:6 }}>Per completed job</p>
          </div>

          {/* Monthly Recurring */}
          <div style={{ background:'linear-gradient(135deg,#5b21b6,#7c3aed)', borderRadius:18, padding:'20px 22px', position:'relative', overflow:'hidden', boxShadow:'0 8px 32px rgba(124,58,237,0.4)' }}>
            <div style={{ position:'absolute', top:-20, right:-20, width:90, height:90, borderRadius:'50%', background:'rgba(255,255,255,0.07)' }}/>
            <div style={{ position:'absolute', bottom:-30, left:-10, width:70, height:70, borderRadius:'50%', background:'rgba(255,255,255,0.05)' }}/>
            <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', marginBottom:16, position:'relative' }}>
              <div style={{ width:36, height:36, borderRadius:10, background:'rgba(255,255,255,0.18)', display:'flex', alignItems:'center', justifyContent:'center' }}>
                <RefreshCw size={17} color="#fff"/>
              </div>
              <span style={{ background:'rgba(255,255,255,0.18)', color:'#fff', fontSize:11, fontWeight:700, padding:'3px 10px', borderRadius:20 }}>{recurringLeads.length} clients</span>
            </div>
            <p style={{ color:'rgba(255,255,255,0.55)', fontSize:11, fontWeight:600, letterSpacing:'0.06em', textTransform:'uppercase', position:'relative' }}>Monthly Recurring</p>
            <p style={{ color:'#fff', fontSize:28, fontWeight:800, letterSpacing:'-0.5px', marginTop:4, position:'relative' }}>{fmt(monthlyRecurring)}</p>
            <p style={{ color:'rgba(255,255,255,0.45)', fontSize:11, marginTop:6, position:'relative' }}>{fmt(annualRecurring)} / year</p>
          </div>
        </div>
      </div>

      <div style={{ padding:'0 28px 28px', marginTop:-44 }}>

        {/* ── Stat pills ── */}
        <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fit,minmax(150px,1fr))', gap:12, marginBottom:24 }}>
          {[
            { icon:Users,         label:'Total Leads',    value:m.totalLeads,         accent:'#0ea5e9', bg:'rgba(14,165,233,0.1)' },
            { icon:Activity,      label:'New Today',      value:m.newToday,            accent:'#0284c7', bg:'rgba(2,132,199,0.1)' },
            { icon:TrendingUp,    label:'Conversion',     value:`${m.conversionRate}%`,accent:'#22c55e', bg:'rgba(34,197,94,0.1)' },
            { icon:CalendarCheck, label:'Jobs Completed', value:m.completedJobs,       accent:'#10b981', bg:'rgba(16,185,129,0.1)' },
          ].map(({ icon:Icon, label, value, accent, bg }) => (
            <div key={label} style={{ background:'#fff', borderRadius:14, padding:'14px 18px', display:'flex', alignItems:'center', gap:12, boxShadow:'0 1px 3px rgba(0,0,0,0.06)', border:'1px solid #eaecf0' }}>
              <div style={{ width:38, height:38, borderRadius:10, background:bg, display:'flex', alignItems:'center', justifyContent:'center', flexShrink:0 }}>
                <Icon size={17} color={accent}/>
              </div>
              <div>
                <p style={{ fontSize:20, fontWeight:800, color:'#0f172a', letterSpacing:'-0.3px', lineHeight:1 }}>{value}</p>
                <p style={{ fontSize:11, color:'#94a3b8', marginTop:3, fontWeight:500 }}>{label}</p>
              </div>
            </div>
          ))}
        </div>

        {/* ── Charts ── */}
        <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:18, marginBottom:24 }}>

          {/* Weekly area chart */}
          <div style={{ background:'#fff', borderRadius:16, padding:'22px 24px', boxShadow:'0 1px 3px rgba(0,0,0,0.06)', border:'1px solid #eaecf0' }}>
            <div style={{ display:'flex', alignItems:'flex-start', justifyContent:'space-between', marginBottom:20 }}>
              <div>
                <p style={{ fontWeight:700, color:'#0f172a', fontSize:14 }}>Revenue Trend</p>
                <p style={{ color:'#94a3b8', fontSize:12, marginTop:2 }}>Last 6 weeks — generated vs collected</p>
              </div>
              <div style={{ display:'flex', gap:14 }}>
                <div style={{ display:'flex', alignItems:'center', gap:6 }}>
                  <span style={{ width:8, height:8, borderRadius:'50%', background:'#0ea5e9', display:'inline-block' }}/>
                  <span style={{ fontSize:11, color:'#64748b', fontWeight:500 }}>Generated</span>
                </div>
                <div style={{ display:'flex', alignItems:'center', gap:6 }}>
                  <span style={{ width:8, height:8, borderRadius:'50%', background:'#10b981', display:'inline-block' }}/>
                  <span style={{ fontSize:11, color:'#64748b', fontWeight:500 }}>Collected</span>
                </div>
              </div>
            </div>
            <ResponsiveContainer width="100%" height={200}>
              <AreaChart data={weeklyData} margin={{ top:4, right:4, left:-12, bottom:0 }}>
                <defs>
                  <linearGradient id="gRev" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#0ea5e9" stopOpacity={0.15}/>
                    <stop offset="100%" stopColor="#0ea5e9" stopOpacity={0}/>
                  </linearGradient>
                  <linearGradient id="gCol" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#10b981" stopOpacity={0.15}/>
                    <stop offset="100%" stopColor="#10b981" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="5 5" stroke="#f1f5f9" vertical={false}/>
                <XAxis dataKey="w" tick={{ fontSize:11, fill:'#94a3b8' }} axisLine={false} tickLine={false}/>
                <YAxis tickFormatter={fmtK} tick={{ fontSize:11, fill:'#94a3b8' }} axisLine={false} tickLine={false} width={38}/>
                <Tooltip content={<DarkTooltip/>} cursor={{ stroke:'#e2e8f0', strokeWidth:1, strokeDasharray:'4 4' }}/>
                <Area type="monotone" dataKey="rev" name="Generated" stroke="#0ea5e9" strokeWidth={2.5} fill="url(#gRev)" dot={false} activeDot={{ r:5, fill:'#0ea5e9', stroke:'#fff', strokeWidth:2 }}/>
                <Area type="monotone" dataKey="col" name="Collected"  stroke="#10b981" strokeWidth={2.5} fill="url(#gCol)" dot={false} activeDot={{ r:5, fill:'#10b981', stroke:'#fff', strokeWidth:2 }}/>
              </AreaChart>
            </ResponsiveContainer>
          </div>

          {/* Monthly bar chart */}
          <div style={{ background:'#fff', borderRadius:16, padding:'22px 24px', boxShadow:'0 1px 3px rgba(0,0,0,0.06)', border:'1px solid #eaecf0' }}>
            <div style={{ marginBottom:20 }}>
              <p style={{ fontWeight:700, color:'#0f172a', fontSize:14 }}>Monthly Revenue</p>
              <p style={{ color:'#94a3b8', fontSize:12, marginTop:2 }}>Cash collected — last 6 months</p>
            </div>
            <ResponsiveContainer width="100%" height={200}>
              <BarChart data={monthlyData} margin={{ top:4, right:4, left:-12, bottom:0 }} barSize={28}>
                <CartesianGrid strokeDasharray="5 5" stroke="#f1f5f9" vertical={false}/>
                <XAxis dataKey="m" tick={{ fontSize:11, fill:'#94a3b8' }} axisLine={false} tickLine={false}/>
                <YAxis tickFormatter={fmtK} tick={{ fontSize:11, fill:'#94a3b8' }} axisLine={false} tickLine={false} width={38}/>
                <Tooltip content={<DarkTooltip/>} cursor={{ fill:'#f8fafc', radius:6 }}/>
                <Bar dataKey="v" name="Revenue" radius={[6,6,0,0]}>
                  {monthlyData.map((_, i) => (
                    <Cell key={i} fill={i === monthlyData.length-1 ? '#0ea5e9' : '#bae6fd'}/>
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* ── Recurring Payments section ── */}
        <div style={{ background:'#fff', borderRadius:16, boxShadow:'0 1px 3px rgba(0,0,0,0.06)', border:'1px solid #eaecf0', overflow:'hidden', marginBottom:24 }}>
          <div style={{ padding:'18px 22px 14px', display:'flex', alignItems:'center', justifyContent:'space-between', borderBottom:'1px solid #f1f5f9' }}>
            <div style={{ display:'flex', alignItems:'center', gap:10 }}>
              <div style={{ width:34, height:34, borderRadius:10, background:'linear-gradient(135deg,#7c3aed,#6d28d9)', display:'flex', alignItems:'center', justifyContent:'center' }}>
                <RefreshCw size={15} color="#fff"/>
              </div>
              <div>
                <p style={{ fontWeight:700, color:'#0f172a', fontSize:14 }}>Recurring Monthly Payments</p>
                <p style={{ color:'#94a3b8', fontSize:12, marginTop:1 }}>Active retainer & subscription clients</p>
              </div>
            </div>
            <div style={{ display:'flex', alignItems:'center', gap:16 }}>
              <div style={{ textAlign:'right' }}>
                <p style={{ fontSize:11, color:'#a78bfa', fontWeight:600, letterSpacing:'0.04em', textTransform:'uppercase' }}>Total / Month</p>
                <p style={{ fontSize:20, fontWeight:800, color:'#7c3aed', letterSpacing:'-0.4px' }}>{fmt(monthlyRecurring)}</p>
              </div>
              <a href="/leads" style={{ display:'flex', alignItems:'center', gap:4, fontSize:12, fontWeight:600, color:'#7c3aed', textDecoration:'none', background:'rgba(124,58,237,0.08)', padding:'6px 12px', borderRadius:9, border:'1px solid #ede9fe' }}>Manage <ArrowRight size={12}/></a>
            </div>
          </div>

          {recurringLeads.length === 0 ? (
            <div style={{ padding:'36px 22px', textAlign:'center' }}>
              <RefreshCw size={28} color="#ddd6fe" style={{ marginBottom:10 }} />
              <p style={{ fontSize:14, fontWeight:600, color:'#94a3b8', marginBottom:4 }}>No recurring clients yet</p>
              <p style={{ fontSize:12, color:'#cbd5e1' }}>Enable "Monthly Recurring Payment" on a lead to track retainer income here.</p>
            </div>
          ) : (
            <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fill,minmax(260px,1fr))', gap:0 }}>
              {recurringLeads.map((lead, i) => {
                const days = daysUntil(lead.recurringNextDate)
                const uc   = urgencyColor(days)
                const isLast = i === recurringLeads.length - 1
                return (
                  <div key={lead.id}
                    style={{ padding:'14px 22px', borderBottom: isLast ? 'none' : '1px solid #f8fafc', borderRight: (i % 2 === 0 && i < recurringLeads.length - 1) ? '1px solid #f8fafc' : 'none', display:'flex', alignItems:'center', justifyContent:'space-between', gap:12 }}
                    onMouseEnter={e=>e.currentTarget.style.background='#fdf8ff'}
                    onMouseLeave={e=>e.currentTarget.style.background='transparent'}>
                    <div style={{ display:'flex', alignItems:'center', gap:11 }}>
                      <div style={{ width:38, height:38, borderRadius:'50%', background:'linear-gradient(135deg,#7c3aed,#a78bfa)', display:'flex', alignItems:'center', justifyContent:'center', color:'#fff', fontSize:14, fontWeight:700, flexShrink:0 }}>
                        {lead.name?.charAt(0)}
                      </div>
                      <div>
                        <p style={{ fontSize:13, fontWeight:600, color:'#0f172a', lineHeight:1.3 }}>{lead.name}</p>
                        <p style={{ fontSize:11, color:'#94a3b8', marginTop:2 }}>{lead.service || 'Service'}</p>
                        {lead.recurringNextDate && (
                          <div style={{ display:'flex', alignItems:'center', gap:4, marginTop:4 }}>
                            <Calendar size={10} color={uc}/>
                            <span style={{ fontSize:10, color:uc, fontWeight:600 }}>
                              {new Date(lead.recurringNextDate).toLocaleDateString('en-AU', { day:'numeric', month:'short' })}
                              {days !== null && <span style={{ marginLeft:4, opacity:0.85 }}>({days === 0 ? 'today' : days < 0 ? `${Math.abs(days)}d overdue` : `in ${days}d`})</span>}
                            </span>
                          </div>
                        )}
                      </div>
                    </div>
                    <div style={{ textAlign:'right', flexShrink:0 }}>
                      <p style={{ fontSize:16, fontWeight:800, color:'#7c3aed', letterSpacing:'-0.3px' }}>${(lead.recurringAmount||0).toLocaleString('en-AU',{minimumFractionDigits:2})}</p>
                      <p style={{ fontSize:10, color:'#a78bfa', fontWeight:600 }}>/month</p>
                    </div>
                  </div>
                )
              })}
            </div>
          )}

          {recurringLeads.length > 0 && (
            <div style={{ padding:'12px 22px', background:'linear-gradient(90deg,#faf5ff,#f5f3ff)', borderTop:'1px solid #ede9fe', display:'flex', alignItems:'center', justifyContent:'space-between' }}>
              <p style={{ fontSize:12, color:'#7c3aed', fontWeight:600 }}>
                {recurringLeads.length} active client{recurringLeads.length !== 1 ? 's' : ''} · {fmt(annualRecurring)} projected annually
              </p>
              <p style={{ fontSize:12, color:'#a78bfa' }}>Avg {fmt(recurringLeads.length > 0 ? monthlyRecurring / recurringLeads.length : 0)}/client</p>
            </div>
          )}
        </div>

        {/* ── Bottom tables ── */}
        <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:18 }}>

          {/* Recent Leads */}
          <div style={{ background:'#fff', borderRadius:16, boxShadow:'0 1px 3px rgba(0,0,0,0.06)', border:'1px solid #eaecf0', overflow:'hidden' }}>
            <div style={{ padding:'18px 22px 14px', display:'flex', alignItems:'center', justifyContent:'space-between', borderBottom:'1px solid #f1f5f9' }}>
              <div>
                <p style={{ fontWeight:700, color:'#0f172a', fontSize:14 }}>Recent Leads</p>
                <p style={{ color:'#94a3b8', fontSize:12, marginTop:1 }}>Latest activity</p>
              </div>
              <a href="/leads" style={{ display:'flex', alignItems:'center', gap:4, fontSize:12, fontWeight:600, color:'#0ea5e9', textDecoration:'none' }}>View all <ArrowRight size={12}/></a>
            </div>
            {recent.length === 0
              ? <p style={{ textAlign:'center', padding:'32px', color:'#94a3b8', fontSize:13 }}>No leads yet</p>
              : recent.map(lead => (
                <div key={lead.id} style={{ display:'flex', alignItems:'center', justifyContent:'space-between', padding:'12px 22px', borderBottom:'1px solid #f8fafc' }}
                  onMouseEnter={e=>e.currentTarget.style.background='#fafbfc'}
                  onMouseLeave={e=>e.currentTarget.style.background='transparent'}>
                  <div style={{ display:'flex', alignItems:'center', gap:12 }}>
                    <div style={{ width:34, height:34, borderRadius:'50%', background:'linear-gradient(135deg,#0ea5e9,#0284c7)', display:'flex', alignItems:'center', justifyContent:'center', color:'#fff', fontSize:12, fontWeight:700, flexShrink:0 }}>
                      {lead.name.charAt(0)}
                    </div>
                    <div>
                      <p style={{ fontSize:13, fontWeight:600, color:'#0f172a', lineHeight:1.3 }}>{lead.name}</p>
                      <p style={{ fontSize:11, color:'#94a3b8', marginTop:2 }}>{lead.service} · {lead.dateSubmitted}</p>
                    </div>
                  </div>
                  <div style={{ display:'flex', alignItems:'center', gap:10 }}>
                    {lead.jobValue > 0 && <span style={{ fontSize:13, fontWeight:700, color:'#0f172a' }}>${Number(lead.jobValue).toLocaleString()}</span>}
                    <Chip label={lead.status}/>
                  </div>
                </div>
              ))
            }
          </div>

          {/* Upcoming Bookings */}
          <div style={{ background:'#fff', borderRadius:16, boxShadow:'0 1px 3px rgba(0,0,0,0.06)', border:'1px solid #eaecf0', overflow:'hidden' }}>
            <div style={{ padding:'18px 22px 14px', display:'flex', alignItems:'center', justifyContent:'space-between', borderBottom:'1px solid #f1f5f9' }}>
              <div>
                <p style={{ fontWeight:700, color:'#0f172a', fontSize:14 }}>Upcoming Bookings</p>
                <p style={{ color:'#94a3b8', fontSize:12, marginTop:1 }}>{upcoming.length} scheduled</p>
              </div>
              <a href="/bookings" style={{ display:'flex', alignItems:'center', gap:4, fontSize:12, fontWeight:600, color:'#0ea5e9', textDecoration:'none' }}>View all <ArrowRight size={12}/></a>
            </div>
            {upcoming.length === 0
              ? <p style={{ textAlign:'center', padding:'32px', color:'#94a3b8', fontSize:13 }}>No upcoming bookings</p>
              : upcoming.map(b => {
                  const d   = new Date(b.date + 'T00:00:00')
                  const mon = d.toLocaleDateString('en-AU',{month:'short'}).toUpperCase()
                  const day = d.getDate()
                  return (
                    <div key={b.id} style={{ display:'flex', alignItems:'center', gap:14, padding:'13px 22px', borderBottom:'1px solid #f8fafc' }}
                      onMouseEnter={e=>e.currentTarget.style.background='#fafbfc'}
                      onMouseLeave={e=>e.currentTarget.style.background='transparent'}>
                      <div style={{ width:44, height:44, borderRadius:12, background:'#0284c7', display:'flex', flexDirection:'column', alignItems:'center', justifyContent:'center', flexShrink:0, boxShadow:'0 4px 12px rgba(2,132,199,0.3)' }}>
                        <span style={{ color:'rgba(255,255,255,0.7)', fontSize:9, fontWeight:700, letterSpacing:'0.05em' }}>{mon}</span>
                        <span style={{ color:'#fff', fontSize:17, fontWeight:800, lineHeight:1.1 }}>{day}</span>
                      </div>
                      <div style={{ flex:1, minWidth:0 }}>
                        <p style={{ fontSize:13, fontWeight:600, color:'#0f172a', lineHeight:1.3, overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap' }}>{b.customerName}</p>
                        <p style={{ fontSize:11, color:'#94a3b8', marginTop:2 }}>{b.service} · {b.phone}</p>
                      </div>
                      <div style={{ background:'#eff6ff', color:'#0284c7', fontSize:12, fontWeight:700, padding:'4px 10px', borderRadius:8, flexShrink:0 }}>{b.time}</div>
                    </div>
                  )
                })
            }
          </div>
        </div>
      </div>
    </div>
  )
}
