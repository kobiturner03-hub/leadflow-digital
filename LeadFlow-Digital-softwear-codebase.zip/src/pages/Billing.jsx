import { useState } from 'react'
import { useApp } from '../context/AppContext'
import { Check, CreditCard, Zap, Shield, AlertTriangle, ExternalLink, ChevronRight, Star } from 'lucide-react'

const PLANS = [
  {
    id:      'starter',
    name:    'Starter',
    price:   49,
    color:   '#64748b',
    popular: false,
    features: [
      'Up to 50 leads/month',
      'Email automations',
      'Booking calendar',
      'Basic analytics',
      'Email support',
    ],
  },
  {
    id:      'growth',
    name:    'Growth',
    price:   99,
    color:   '#0ea5e9',
    popular: true,
    features: [
      'Unlimited leads',
      'Email + SMS automations',
      'Full pipeline & kanban',
      'Advanced analytics',
      'User management',
      'Priority support',
      'Twilio SMS integration',
    ],
  },
  {
    id:      'agency',
    name:    'Agency',
    price:   249,
    color:   '#7c3aed',
    popular: false,
    features: [
      'Everything in Growth',
      'White-label branding',
      'Up to 20 client accounts',
      'Admin dashboard',
      'Custom domain',
      'Dedicated account manager',
    ],
  },
]

function PlanCard({ plan, current, onSelect }) {
  const isCurrent  = current === plan.id
  const isDowngrade = current === 'growth' && plan.id === 'starter'
                   || current === 'agency' && (plan.id === 'starter' || plan.id === 'growth')

  return (
    <div style={{
      background: plan.popular ? 'linear-gradient(160deg,#0c1628,#0e2044)' : '#fff',
      border:     `2px solid ${isCurrent ? '#10b981' : plan.popular ? '#0ea5e9' : '#eaecf0'}`,
      borderRadius: 18, padding: '28px 24px', position: 'relative',
      boxShadow: plan.popular ? '0 12px 40px rgba(14,165,233,0.2)' : '0 1px 4px rgba(0,0,0,0.05)',
    }}>
      {plan.popular && !isCurrent && (
        <div style={{ position:'absolute', top:-13, left:'50%', transform:'translateX(-50%)', background:'linear-gradient(90deg,#1d4ed8,#2563eb)', color:'#fff', fontSize:11, fontWeight:800, padding:'4px 14px', borderRadius:20, whiteSpace:'nowrap', letterSpacing:'0.06em' }}>
          MOST POPULAR
        </div>
      )}
      {isCurrent && (
        <div style={{ position:'absolute', top:-13, left:'50%', transform:'translateX(-50%)', background:'linear-gradient(90deg,#059669,#10b981)', color:'#fff', fontSize:11, fontWeight:800, padding:'4px 14px', borderRadius:20, whiteSpace:'nowrap', letterSpacing:'0.06em' }}>
          ✓ CURRENT PLAN
        </div>
      )}

      <h3 style={{ fontSize:16, fontWeight:800, color: plan.popular ? '#fff' : '#0f172a', marginBottom:6 }}>{plan.name}</h3>
      <div style={{ display:'flex', alignItems:'flex-end', gap:3, marginBottom:20 }}>
        <span style={{ fontSize:36, fontWeight:900, color: plan.popular ? '#fff' : '#0f172a', letterSpacing:'-1px', lineHeight:1 }}>${plan.price}</span>
        <span style={{ fontSize:13, color: plan.popular ? 'rgba(255,255,255,0.4)' : '#94a3b8', marginBottom:4 }}>/mo AUD</span>
      </div>

      <div style={{ display:'flex', flexDirection:'column', gap:9, marginBottom:24 }}>
        {plan.features.map(f => (
          <div key={f} style={{ display:'flex', alignItems:'flex-start', gap:9 }}>
            <div style={{ width:18, height:18, borderRadius:5, background: plan.popular ? 'rgba(14,165,233,0.4)' : 'rgba(14,165,233,0.1)', display:'flex', alignItems:'center', justifyContent:'center', flexShrink:0, marginTop:1 }}>
              <Check size={10} color={plan.popular ? '#93c5fd' : '#0ea5e9'}/>
            </div>
            <span style={{ fontSize:13, color: plan.popular ? 'rgba(255,255,255,0.7)' : '#475569', lineHeight:1.5 }}>{f}</span>
          </div>
        ))}
      </div>

      <button
        onClick={() => !isCurrent && onSelect(plan)}
        disabled={isCurrent}
        style={{
          width:'100%', padding:'11px', borderRadius:11, border: isCurrent ? 'none' : plan.popular ? 'none' : '1px solid #e2e8f0',
          background: isCurrent ? 'rgba(16,185,129,0.15)' : plan.popular ? 'linear-gradient(135deg,#0284c7,#0ea5e9)' : '#fff',
          color: isCurrent ? '#059669' : plan.popular ? '#fff' : '#0f172a',
          fontSize: 13, fontWeight: 700, cursor: isCurrent ? 'default' : 'pointer',
          display:'flex', alignItems:'center', justifyContent:'center', gap:7,
          boxShadow: plan.popular && !isCurrent ? '0 4px 16px rgba(14,165,233,0.4)' : 'none',
        }}
      >
        {isCurrent
          ? <><Check size={14}/> Active Plan</>
          : isDowngrade
          ? 'Downgrade'
          : <><ChevronRight size={14}/> {current ? 'Switch to ' + plan.name : 'Get Started'}</>
        }
      </button>
    </div>
  )
}

export default function Billing() {
  const { currentUser } = useApp()
  // In production this comes from Stripe subscription data stored in businesses table
  const [currentPlan, setCurrentPlan] = useState(null) // null = no active plan
  const [showStripeSetup, setShowStripeSetup] = useState(false)
  const [selectedPlan, setSelectedPlan] = useState(null)

  const handleSelectPlan = (plan) => {
    setSelectedPlan(plan)
    setShowStripeSetup(true)
  }

  return (
    <div style={{ padding:28, minHeight:'100%' }}>

      <div style={{ marginBottom:28 }}>
        <h1 style={{ fontSize:20, fontWeight:800, color:'#0f172a', letterSpacing:'-0.3px' }}>Billing & Subscription</h1>
        <p style={{ fontSize:13, color:'#94a3b8', marginTop:3 }}>Manage your plan and payment details</p>
      </div>

      {/* Current status banner */}
      {!currentPlan ? (
        <div style={{ background:'linear-gradient(135deg,#fffbeb,#fef3c7)', border:'1px solid #fde68a', borderRadius:14, padding:'16px 20px', marginBottom:28, display:'flex', alignItems:'flex-start', gap:12 }}>
          <AlertTriangle size={18} color="#d97706" style={{ flexShrink:0, marginTop:1 }}/>
          <div>
            <p style={{ fontSize:14, fontWeight:700, color:'#92400e', marginBottom:3 }}>No active subscription</p>
            <p style={{ fontSize:13, color:'#b45309', lineHeight:1.6 }}>You're currently on a free trial. Choose a plan below to unlock all features and continue after your trial ends.</p>
          </div>
        </div>
      ) : (
        <div style={{ background:'linear-gradient(135deg,#f0fdf4,#dcfce7)', border:'1px solid #bbf7d0', borderRadius:14, padding:'16px 20px', marginBottom:28, display:'flex', alignItems:'center', gap:12, justifyContent:'space-between' }}>
          <div style={{ display:'flex', alignItems:'center', gap:12 }}>
            <div style={{ width:40, height:40, borderRadius:12, background:'rgba(16,185,129,0.15)', display:'flex', alignItems:'center', justifyContent:'center' }}>
              <Zap size={18} color="#059669"/>
            </div>
            <div>
              <p style={{ fontSize:14, fontWeight:700, color:'#065f46' }}>
                {PLANS.find(p => p.id === currentPlan)?.name} Plan — Active
              </p>
              <p style={{ fontSize:12, color:'#059669' }}>Next billing date: 23 April 2026</p>
            </div>
          </div>
          <button style={{ display:'flex', alignItems:'center', gap:6, padding:'8px 14px', borderRadius:9, border:'1px solid #bbf7d0', background:'#fff', fontSize:12, fontWeight:700, color:'#065f46', cursor:'pointer' }}>
            <CreditCard size={13}/> Manage Payment
          </button>
        </div>
      )}

      {/* Plan cards */}
      <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fit,minmax(260px,1fr))', gap:20, marginBottom:32 }}>
        {PLANS.map(plan => (
          <PlanCard key={plan.id} plan={plan} current={currentPlan} onSelect={handleSelectPlan}/>
        ))}
      </div>

      {/* Stripe setup info */}
      <div style={{ background:'#fff', border:'1px solid #eaecf0', borderRadius:16, padding:'22px 24px', boxShadow:'0 1px 3px rgba(0,0,0,0.05)', marginBottom:20 }}>
        <div style={{ display:'flex', alignItems:'flex-start', gap:14 }}>
          <div style={{ width:42, height:42, borderRadius:12, background:'rgba(99,102,241,0.1)', display:'flex', alignItems:'center', justifyContent:'center', flexShrink:0 }}>
            <CreditCard size={19} color="#6366f1"/>
          </div>
          <div style={{ flex:1 }}>
            <p style={{ fontSize:14, fontWeight:700, color:'#0f172a', marginBottom:4 }}>Payments powered by Stripe</p>
            <p style={{ fontSize:13, color:'#64748b', lineHeight:1.6, marginBottom:14 }}>
              All subscriptions are processed securely through Stripe. Your payment details are never stored on our servers.
              To activate billing, connect your Stripe account in the admin panel.
            </p>
            <div style={{ display:'flex', gap:10, flexWrap:'wrap' }}>
              {[['256-bit SSL encryption'],['PCI DSS compliant'],['Cancel anytime'],['AUD billing']].map(([label]) => (
                <div key={label} style={{ display:'flex', alignItems:'center', gap:5, background:'#f8fafc', border:'1px solid #eaecf0', borderRadius:7, padding:'4px 10px' }}>
                  <Shield size={10} color="#10b981"/>
                  <span style={{ fontSize:11, color:'#64748b', fontWeight:500 }}>{label}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Admin: Stripe connect panel */}
      {currentUser?.role === 'admin' && (
        <div style={{ background:'linear-gradient(135deg,#0c1628,#0e2044)', border:'1px solid rgba(255,255,255,0.08)', borderRadius:16, padding:'22px 24px' }}>
          <div style={{ display:'flex', alignItems:'flex-start', justifyContent:'space-between', flexWrap:'wrap', gap:14 }}>
            <div>
              <p style={{ fontSize:14, fontWeight:700, color:'#fff', marginBottom:4 }}>Stripe Integration (Admin)</p>
              <p style={{ fontSize:13, color:'rgba(255,255,255,0.45)', lineHeight:1.6, maxWidth:480 }}>
                Connect your Stripe account to start accepting subscription payments from clients.
                You'll need your Stripe publishable key, secret key, and webhook secret.
              </p>
            </div>
            <a
              href="https://dashboard.stripe.com/apikeys"
              target="_blank"
              rel="noopener noreferrer"
              style={{ display:'inline-flex', alignItems:'center', gap:7, padding:'9px 18px', borderRadius:10, border:'none', background:'#0ea5e9', color:'#fff', fontSize:13, fontWeight:700, cursor:'pointer', textDecoration:'none', flexShrink:0, boxShadow:'0 4px 16px rgba(14,165,233,0.4)' }}>
              <ExternalLink size={13}/> Open Stripe Dashboard
            </a>
          </div>
          <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fit,minmax(200px,1fr))', gap:12, marginTop:20 }}>
            {[
              ['Step 1', 'Create a Stripe account at stripe.com'],
              ['Step 2', 'Copy your Publishable & Secret keys'],
              ['Step 3', 'Set up a webhook endpoint for /api/stripe/webhook'],
              ['Step 4', 'Add keys to your Supabase environment variables'],
            ].map(([step, desc]) => (
              <div key={step} style={{ background:'rgba(255,255,255,0.05)', borderRadius:10, padding:'12px 14px' }}>
                <p style={{ fontSize:11, fontWeight:700, color:'#60a5fa', marginBottom:4, letterSpacing:'0.04em' }}>{step}</p>
                <p style={{ fontSize:12, color:'rgba(255,255,255,0.45)', lineHeight:1.5 }}>{desc}</p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Checkout modal */}
      {showStripeSetup && selectedPlan && (
        <div style={{ position:'fixed', inset:0, background:'rgba(0,0,0,0.5)', display:'flex', alignItems:'center', justifyContent:'center', zIndex:1000, padding:16 }}>
          <div style={{ background:'#fff', borderRadius:20, padding:'28px', width:'100%', maxWidth:420, boxShadow:'0 24px 80px rgba(0,0,0,0.3)' }}>
            <div style={{ textAlign:'center', marginBottom:22 }}>
              <div style={{ width:52, height:52, borderRadius:16, background:'linear-gradient(135deg,#0284c7,#0ea5e9)', display:'flex', alignItems:'center', justifyContent:'center', margin:'0 auto 14px', boxShadow:'0 8px 24px rgba(14,165,233,0.35)' }}>
                <CreditCard size={22} color="#fff"/>
              </div>
              <h2 style={{ fontSize:18, fontWeight:800, color:'#0f172a', marginBottom:6 }}>Subscribe to {selectedPlan.name}</h2>
              <p style={{ fontSize:28, fontWeight:900, color:'#0ea5e9', letterSpacing:'-0.5px' }}>${selectedPlan.price}<span style={{ fontSize:14, fontWeight:500, color:'#94a3b8' }}>/mo</span></p>
            </div>
            <div style={{ background:'#f0f9ff', border:'1px solid #bae6fd', borderRadius:12, padding:'14px 16px', marginBottom:20 }}>
              <p style={{ fontSize:13, color:'#0284c7', lineHeight:1.6, textAlign:'center' }}>
                🔐 Stripe checkout coming soon — contact <strong>admin@leadflowdigital.com.au</strong> to activate your subscription.
              </p>
            </div>
            <div style={{ display:'flex', gap:10 }}>
              <button onClick={() => setShowStripeSetup(false)} style={{ flex:1, padding:'11px', borderRadius:11, border:'1px solid #e2e8f0', background:'#fff', fontSize:13, fontWeight:600, color:'#374151', cursor:'pointer' }}>
                Cancel
              </button>
              <a href="mailto:admin@leadflowdigital.com.au?subject=Subscription%20Request%20-%20{selectedPlan.name}%20Plan"
                style={{ flex:2, padding:'11px', borderRadius:11, border:'none', background:'linear-gradient(135deg,#0284c7,#0ea5e9)', color:'#fff', fontSize:13, fontWeight:700, cursor:'pointer', textDecoration:'none', display:'flex', alignItems:'center', justifyContent:'center', gap:7, boxShadow:'0 4px 14px rgba(14,165,233,0.35)' }}>
                Contact to Subscribe
              </a>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
