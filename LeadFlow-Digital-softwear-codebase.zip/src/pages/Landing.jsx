import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import {
  Check, ChevronRight, Star, Users, TrendingUp, Zap, Bell, BarChart2,
  Calendar, MessageSquare, ArrowRight, Phone, Mail, Globe, Menu, X,
  ShieldCheck, Clock, DollarSign
} from 'lucide-react'

// ── Helpers ──────────────────────────────────────────────────────────────────
const FEATURES = [
  { icon: Users,        color:'#0ea5e9', bg:'rgba(14,165,233,0.1)',   title:'Lead Management',       desc:'Capture, organise and track every enquiry from first contact to completed job. Never lose a lead again.' },
  { icon: BarChart2,    color:'#0ea5e9', bg:'rgba(124,58,237,0.1)',  title:'Pipeline & Kanban',      desc:'Drag-and-drop sales pipeline. Move leads through your workflow in seconds and see exactly where every job stands.' },
  { icon: Calendar,     color:'#059669', bg:'rgba(5,150,105,0.1)',   title:'Booking Calendar',       desc:'Full booking calendar with month view, upcoming jobs list, and one-click appointment creation.' },
  { icon: Zap,          color:'#d97706', bg:'rgba(217,119,6,0.1)',   title:'Email & SMS Automation', desc:'Automated follow-up emails and SMS messages triggered by lead events — confirm bookings, chase enquiries, and more.' },
  { icon: TrendingUp,   color:'#dc2626', bg:'rgba(220,38,38,0.1)',   title:'Live Analytics',         desc:'Real-time revenue charts, conversion rates, cash collected, and pipeline breakdowns — all from your actual data.' },
  { icon: Bell,         color:'#0891b2', bg:'rgba(8,145,178,0.1)',   title:'Instant Notifications',  desc:'Get notified the moment a lead comes in. No more missed enquiries or forgotten follow-ups.' },
]

const TESTIMONIALS = [
  { name:'Ryan T.',  biz:'RT Plumbing',          stars:5, text:'"Doubled our bookings in 3 months. The pipeline view alone is worth every cent — I can see exactly where every job is up to."' },
  { name:'Sarah M.', biz:'Mack\'s Electrical',   stars:5, text:'"The automated follow-up emails save us hours every week. Clients love the quick response and our conversion rate has jumped."' },
  { name:'Jake W.',  biz:'Westside Landscaping',  stars:5, text:'"Switched from spreadsheets and haven\'t looked back. The dashboard shows me exactly how the business is performing."' },
]

const PLANS = [
  {
    name:'Starter',
    price:'$49',
    period:'/mo',
    desc:'Perfect for sole traders and small teams just getting started.',
    color:'#0ea5e9',
    popular:false,
    features:['Up to 50 leads/month','Email automations','Booking calendar','Basic analytics','Email support'],
  },
  {
    name:'Growth',
    price:'$99',
    period:'/mo',
    desc:'The complete toolkit for growing trade and service businesses.',
    color:'#0ea5e9',
    popular:true,
    features:['Unlimited leads','Email + SMS automations','Full pipeline & kanban','Advanced analytics & reports','User management','Priority support','Twilio SMS integration'],
  },
  {
    name:'Agency',
    price:'$249',
    period:'/mo',
    desc:'White-label the platform and manage clients under your own brand.',
    color:'#0ea5e9',
    popular:false,
    features:['Everything in Growth','White-label branding','Up to 20 client accounts','Admin dashboard','Custom domain','Dedicated account manager'],
  },
]

const FAQS = [
  { q:'Is there a free trial?',                    a:'Yes — all plans come with a 14-day free trial. No credit card required to start.' },
  { q:'Can I import my existing leads?',            a:'Absolutely. You can import leads via CSV or add them manually. Our team can also help with data migration.' },
  { q:'Does it work for any trade or service?',    a:'Yes. LeadFlow Digital is used by plumbers, electricians, landscapers, cleaners, builders, and dozens of other service-based businesses.' },
  { q:'What happens if I need help?',               a:'Starter plans get email support within 24 hours. Growth and Agency plans get priority support with faster response times.' },
  { q:'Can I cancel at any time?',                  a:'Yes. No lock-in contracts. Cancel any time and you keep access until the end of your billing period.' },
  { q:'Is my data secure?',                         a:'All data is encrypted in transit and at rest. We use enterprise-grade infrastructure (Supabase) with Australian data residency.' },
]

function StarRow({ n = 5 }) {
  return (
    <div style={{ display:'flex', gap:3 }}>
      {Array.from({ length: n }).map((_,i) => <Star key={i} size={13} color="#f59e0b" fill="#f59e0b"/>)}
    </div>
  )
}

function FaqItem({ q, a }) {
  const [open, setOpen] = useState(false)
  return (
    <div style={{ borderBottom:'1px solid #e2e8f0' }}>
      <button onClick={() => setOpen(o => !o)} style={{ width:'100%', textAlign:'left', padding:'18px 0', background:'none', border:'none', cursor:'pointer', display:'flex', alignItems:'center', justifyContent:'space-between', gap:16 }}>
        <span style={{ fontSize:15, fontWeight:600, color:'#0f172a', lineHeight:1.4 }}>{q}</span>
        <span style={{ width:28, height:28, borderRadius:8, background: open ? '#0ea5e9' : '#f1f5f9', display:'flex', alignItems:'center', justifyContent:'center', flexShrink:0, transition:'background 0.2s' }}>
          {open ? <X size={14} color="#fff"/> : <ChevronRight size={14} color="#64748b" style={{ transform:'rotate(90deg)' }}/>}
        </span>
      </button>
      {open && <p style={{ fontSize:14, color:'#475569', lineHeight:1.7, paddingBottom:18, marginTop:-4 }}>{a}</p>}
    </div>
  )
}

// ── Main component ────────────────────────────────────────────────────────────
export default function Landing() {
  const navigate = useNavigate()
  const [navOpen, setNavOpen] = useState(false)

  return (
    <div style={{ fontFamily:'Inter,-apple-system,sans-serif', background:'#fff', color:'#0f172a', overflowX:'hidden' }}>

      {/* ── Nav ── */}
      <nav style={{ position:'sticky', top:0, zIndex:100, background:'rgba(255,255,255,0.92)', backdropFilter:'blur(12px)', borderBottom:'1px solid #eaecf0' }}>
        <div style={{ maxWidth:1160, margin:'0 auto', padding:'0 24px', height:64, display:'flex', alignItems:'center', justifyContent:'space-between', overflow:'hidden' }}>
          <div style={{ display:'flex', alignItems:'center', height:'100%', overflow:'hidden' }}>
            <img src="/leadflow-logo.png" alt="LeadFlow Digital" style={{ height:90, width:'auto', objectFit:'contain', flexShrink:0 }} />
          </div>

          {/* Desktop nav */}
          <div style={{ display:'flex', alignItems:'center', gap:28 }} className="desktop-nav">
            {['Features','Pricing','FAQs'].map(label => (
              <a key={label} href={`#${label.toLowerCase()}`} style={{ fontSize:14, fontWeight:500, color:'#475569', textDecoration:'none', transition:'color 0.15s' }}
                onMouseEnter={e=>e.target.style.color='#0f172a'} onMouseLeave={e=>e.target.style.color='#475569'}>
                {label}
              </a>
            ))}
          </div>

          <div style={{ display:'flex', alignItems:'center', gap:10 }}>
            <button onClick={() => navigate('/login')} style={{ padding:'7px 16px', borderRadius:9, border:'1px solid #e2e8f0', background:'#fff', fontSize:13, fontWeight:600, color:'#374151', cursor:'pointer' }}>Log in</button>
            <button onClick={() => navigate('/signup')} style={{ padding:'8px 18px', borderRadius:9, border:'none', background:'linear-gradient(135deg,#0284c7,#0ea5e9)', color:'#fff', fontSize:13, fontWeight:700, cursor:'pointer', boxShadow:'0 4px 14px rgba(14,165,233,0.35)' }}>
              Start Free Trial
            </button>
            <button onClick={() => setNavOpen(o=>!o)} style={{ display:'none', width:36, height:36, borderRadius:8, border:'1px solid #e2e8f0', background:'#fff', alignItems:'center', justifyContent:'center', cursor:'pointer', color:'#374151' }} className="mobile-menu-btn">
              {navOpen ? <X size={16}/> : <Menu size={16}/>}
            </button>
          </div>
        </div>
      </nav>

      {/* ── Hero ── */}
      <section style={{ background:'linear-gradient(160deg,#0d1f3c 0%,#0a3a5c 55%,#062a44 100%)', padding:'100px 24px 80px', textAlign:'center', position:'relative', overflow:'hidden' }}>
        {/* Background circles */}
        <div style={{ position:'absolute', top:-120, left:'50%', transform:'translateX(-50%)', width:700, height:700, borderRadius:'50%', background:'radial-gradient(circle,rgba(14,165,233,0.2) 0%,transparent 70%)', pointerEvents:'none' }}/>
        <div style={{ position:'absolute', bottom:-80, right:'-10%', width:400, height:400, borderRadius:'50%', background:'radial-gradient(circle,rgba(34,197,94,0.08) 0%,transparent 70%)', pointerEvents:'none' }}/>

        <div style={{ position:'relative', maxWidth:780, margin:'0 auto' }}>
          <div style={{ display:'inline-flex', alignItems:'center', gap:7, background:'rgba(14,165,233,0.15)', border:'1px solid rgba(14,165,233,0.3)', borderRadius:20, padding:'6px 14px', marginBottom:28 }}>
            <Zap size={12} color="#60a5fa" fill="#60a5fa"/>
            <span style={{ fontSize:12, color:'#93c5fd', fontWeight:600 }}>Built for Australian trade &amp; service businesses</span>
          </div>

          <h1 style={{ fontSize:54, fontWeight:900, color:'#fff', lineHeight:1.1, letterSpacing:'-1.5px', marginBottom:24 }}>
            The CRM that{' '}
            <span style={{ background:'linear-gradient(90deg,#60a5fa,#818cf8)', WebkitBackgroundClip:'text', WebkitTextFillColor:'transparent', backgroundClip:'text' }}>
              wins more jobs
            </span>
          </h1>

          <p style={{ fontSize:19, color:'rgba(255,255,255,0.55)', lineHeight:1.7, marginBottom:42, maxWidth:580, margin:'0 auto 42px' }}>
            Manage leads, automate follow-ups, track revenue, and book jobs — all from one platform designed for tradies and service businesses.
          </p>

          <div style={{ display:'flex', gap:12, justifyContent:'center', flexWrap:'wrap' }}>
            <button onClick={() => navigate('/signup')} style={{ display:'inline-flex', alignItems:'center', gap:8, padding:'14px 28px', borderRadius:12, border:'none', background:'linear-gradient(135deg,#0284c7,#0ea5e9)', color:'#fff', fontSize:15, fontWeight:700, cursor:'pointer', boxShadow:'0 8px 32px rgba(14,165,233,0.45)' }}>
              Start Free Trial <ArrowRight size={16}/>
            </button>
            <button onClick={() => navigate('/login')} style={{ display:'inline-flex', alignItems:'center', gap:8, padding:'14px 28px', borderRadius:12, border:'1px solid rgba(255,255,255,0.15)', background:'rgba(255,255,255,0.07)', color:'#fff', fontSize:15, fontWeight:600, cursor:'pointer', backdropFilter:'blur(4px)' }}>
              View Demo
            </button>
          </div>

          <p style={{ fontSize:12, color:'rgba(255,255,255,0.3)', marginTop:18 }}>14-day free trial · No credit card required · Cancel anytime</p>

          {/* Hero stats */}
          <div style={{ display:'flex', justifyContent:'center', gap:40, marginTop:56, flexWrap:'wrap' }}>
            {[['500+','Businesses'],['$12M+','Revenue tracked'],['98%','Satisfaction']].map(([v,l]) => (
              <div key={l} style={{ textAlign:'center' }}>
                <p style={{ fontSize:30, fontWeight:800, color:'#fff', letterSpacing:'-0.5px' }}>{v}</p>
                <p style={{ fontSize:12, color:'rgba(255,255,255,0.4)', marginTop:2, fontWeight:500 }}>{l}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── Trust bar ── */}
      <div style={{ background:'#f8fafc', borderTop:'1px solid #eaecf0', borderBottom:'1px solid #eaecf0', padding:'20px 24px' }}>
        <div style={{ maxWidth:1160, margin:'0 auto', display:'flex', alignItems:'center', justifyContent:'center', gap:36, flexWrap:'wrap' }}>
          {[
            [ShieldCheck,'#10b981','Bank-grade security'],
            [Globe,      '#0ea5e9','Australian data hosting'],
            [Clock,      '#8b5cf6','99.9% uptime'],
            [DollarSign, '#f59e0b','No lock-in contracts'],
          ].map(([Icon,c,t]) => (
            <div key={t} style={{ display:'flex', alignItems:'center', gap:8 }}>
              <Icon size={15} color={c}/>
              <span style={{ fontSize:13, color:'#64748b', fontWeight:500 }}>{t}</span>
            </div>
          ))}
        </div>
      </div>

      {/* ── Features ── */}
      <section id="features" style={{ padding:'96px 24px', maxWidth:1160, margin:'0 auto' }}>
        <div style={{ textAlign:'center', marginBottom:64 }}>
          <p style={{ fontSize:13, fontWeight:700, color:'#0ea5e9', textTransform:'uppercase', letterSpacing:'0.1em', marginBottom:12 }}>Features</p>
          <h2 style={{ fontSize:40, fontWeight:900, letterSpacing:'-0.8px', color:'#0f172a', marginBottom:16 }}>Everything you need to grow</h2>
          <p style={{ fontSize:17, color:'#64748b', maxWidth:520, margin:'0 auto', lineHeight:1.7 }}>One platform. No spreadsheets. No missed leads. No wasted time.</p>
        </div>

        <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fill,minmax(320px,1fr))', gap:22 }}>
          {FEATURES.map(({ icon:Icon, color, bg, title, desc }) => (
            <div key={title} style={{ background:'#fff', border:'1px solid #eaecf0', borderRadius:18, padding:'26px 26px', boxShadow:'0 1px 4px rgba(0,0,0,0.05)', transition:'box-shadow 0.2s, transform 0.2s' }}
              onMouseEnter={e=>{ e.currentTarget.style.boxShadow='0 8px 32px rgba(0,0,0,0.1)'; e.currentTarget.style.transform='translateY(-2px)' }}
              onMouseLeave={e=>{ e.currentTarget.style.boxShadow='0 1px 4px rgba(0,0,0,0.05)'; e.currentTarget.style.transform='translateY(0)' }}>
              <div style={{ width:44, height:44, borderRadius:13, background:bg, display:'flex', alignItems:'center', justifyContent:'center', marginBottom:18 }}>
                <Icon size={20} color={color}/>
              </div>
              <h3 style={{ fontSize:16, fontWeight:700, color:'#0f172a', marginBottom:8 }}>{title}</h3>
              <p style={{ fontSize:14, color:'#64748b', lineHeight:1.7 }}>{desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* ── How it works ── */}
      <section style={{ background:'linear-gradient(160deg,#060d1a,#0c1628)', padding:'96px 24px' }}>
        <div style={{ maxWidth:960, margin:'0 auto', textAlign:'center' }}>
          <p style={{ fontSize:13, fontWeight:700, color:'#60a5fa', textTransform:'uppercase', letterSpacing:'0.1em', marginBottom:12 }}>How it works</p>
          <h2 style={{ fontSize:38, fontWeight:900, color:'#fff', letterSpacing:'-0.7px', marginBottom:56 }}>Up and running in minutes</h2>
          <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fit,minmax(220px,1fr))', gap:32 }}>
            {[
              { n:'1', title:'Sign up',         desc:'Create your account and set up your business profile in under 2 minutes.' },
              { n:'2', title:'Add your leads',  desc:'Import from CSV or start adding leads manually. The pipeline view is instant.' },
              { n:'3', title:'Automate',        desc:'Turn on email and SMS automations so every lead gets a fast, professional response.' },
              { n:'4', title:'Win more jobs',   desc:'Track revenue, follow up efficiently, and watch your conversion rate climb.' },
            ].map(({ n, title, desc }) => (
              <div key={n} style={{ textAlign:'center' }}>
                <div style={{ width:52, height:52, borderRadius:16, background:'linear-gradient(135deg,#0284c7,#0ea5e9)', display:'flex', alignItems:'center', justifyContent:'center', margin:'0 auto 18px', boxShadow:'0 8px 28px rgba(14,165,233,0.4)' }}>
                  <span style={{ color:'#fff', fontSize:20, fontWeight:800 }}>{n}</span>
                </div>
                <h3 style={{ fontSize:16, fontWeight:700, color:'#fff', marginBottom:8 }}>{title}</h3>
                <p style={{ fontSize:14, color:'rgba(255,255,255,0.45)', lineHeight:1.7 }}>{desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── Testimonials ── */}
      <section style={{ padding:'96px 24px', background:'#f8fafc' }}>
        <div style={{ maxWidth:1060, margin:'0 auto' }}>
          <div style={{ textAlign:'center', marginBottom:56 }}>
            <p style={{ fontSize:13, fontWeight:700, color:'#0ea5e9', textTransform:'uppercase', letterSpacing:'0.1em', marginBottom:12 }}>Testimonials</p>
            <h2 style={{ fontSize:38, fontWeight:900, letterSpacing:'-0.7px', color:'#0f172a' }}>Businesses like yours are winning</h2>
          </div>
          <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fit,minmax(280px,1fr))', gap:20 }}>
            {TESTIMONIALS.map(({ name, biz, stars, text }) => (
              <div key={name} style={{ background:'#fff', border:'1px solid #eaecf0', borderRadius:18, padding:'26px 26px', boxShadow:'0 1px 4px rgba(0,0,0,0.05)' }}>
                <StarRow n={stars}/>
                <p style={{ fontSize:14, color:'#475569', lineHeight:1.8, margin:'14px 0 18px', fontStyle:'italic' }}>{text}</p>
                <div style={{ display:'flex', alignItems:'center', gap:10 }}>
                  <div style={{ width:38, height:38, borderRadius:'50%', background:'linear-gradient(135deg,#1d4ed8,#7c3aed)', display:'flex', alignItems:'center', justifyContent:'center', color:'#fff', fontSize:13, fontWeight:700 }}>
                    {name[0]}
                  </div>
                  <div>
                    <p style={{ fontSize:13, fontWeight:700, color:'#0f172a' }}>{name}</p>
                    <p style={{ fontSize:11, color:'#94a3b8' }}>{biz}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── Pricing ── */}
      <section id="pricing" style={{ padding:'96px 24px', maxWidth:1100, margin:'0 auto' }}>
        <div style={{ textAlign:'center', marginBottom:60 }}>
          <p style={{ fontSize:13, fontWeight:700, color:'#0ea5e9', textTransform:'uppercase', letterSpacing:'0.1em', marginBottom:12 }}>Pricing</p>
          <h2 style={{ fontSize:40, fontWeight:900, letterSpacing:'-0.8px', color:'#0f172a', marginBottom:14 }}>Simple, transparent pricing</h2>
          <p style={{ fontSize:16, color:'#64748b', maxWidth:440, margin:'0 auto' }}>Start free. Upgrade when you're ready. No lock-in contracts.</p>
        </div>

        <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fit,minmax(280px,1fr))', gap:20, alignItems:'start' }}>
          {PLANS.map(plan => (
            <div key={plan.name} style={{
              background: plan.popular ? 'linear-gradient(160deg,#0c1628,#0e2044)' : '#fff',
              border: plan.popular ? '2px solid #2563eb' : '1px solid #eaecf0',
              borderRadius:20, padding:'32px 28px',
              boxShadow: plan.popular ? '0 20px 60px rgba(14,165,233,0.25)' : '0 1px 4px rgba(0,0,0,0.05)',
              position:'relative',
            }}>
              {plan.popular && (
                <div style={{ position:'absolute', top:-14, left:'50%', transform:'translateX(-50%)', background:'linear-gradient(90deg,#1d4ed8,#2563eb)', color:'#fff', fontSize:11, fontWeight:800, padding:'5px 16px', borderRadius:20, letterSpacing:'0.06em', textTransform:'uppercase', whiteSpace:'nowrap', boxShadow:'0 4px 14px rgba(14,165,233,0.4)' }}>
                  Most Popular
                </div>
              )}
              <h3 style={{ fontSize:17, fontWeight:800, color: plan.popular ? '#fff' : '#0f172a', marginBottom:6 }}>{plan.name}</h3>
              <p style={{ fontSize:13, color: plan.popular ? 'rgba(255,255,255,0.45)' : '#64748b', marginBottom:22, lineHeight:1.6 }}>{plan.desc}</p>
              <div style={{ display:'flex', alignItems:'flex-end', gap:4, marginBottom:28 }}>
                <span style={{ fontSize:42, fontWeight:900, color: plan.popular ? '#fff' : '#0f172a', letterSpacing:'-1px', lineHeight:1 }}>{plan.price}</span>
                <span style={{ fontSize:14, color: plan.popular ? 'rgba(255,255,255,0.45)' : '#64748b', marginBottom:5 }}>{plan.period}</span>
              </div>
              <div style={{ display:'flex', flexDirection:'column', gap:10, marginBottom:28 }}>
                {plan.features.map(f => (
                  <div key={f} style={{ display:'flex', alignItems:'flex-start', gap:10 }}>
                    <div style={{ width:20, height:20, borderRadius:6, background: plan.popular ? 'rgba(14,165,233,0.4)' : 'rgba(14,165,233,0.1)', display:'flex', alignItems:'center', justifyContent:'center', flexShrink:0, marginTop:1 }}>
                      <Check size={11} color={plan.popular ? '#93c5fd' : '#0ea5e9'}/>
                    </div>
                    <span style={{ fontSize:13, color: plan.popular ? 'rgba(255,255,255,0.75)' : '#475569', lineHeight:1.5 }}>{f}</span>
                  </div>
                ))}
              </div>
              <button onClick={() => navigate('/signup')} style={{
                width:'100%', padding:'12px', borderRadius:11, border: plan.popular ? 'none' : '1px solid #e2e8f0',
                background: plan.popular ? 'linear-gradient(135deg,#0284c7,#0ea5e9)' : '#fff',
                color: plan.popular ? '#fff' : '#0f172a',
                fontSize:14, fontWeight:700, cursor:'pointer',
                boxShadow: plan.popular ? '0 6px 20px rgba(14,165,233,0.4)' : 'none',
                display:'flex', alignItems:'center', justifyContent:'center', gap:8,
              }}>
                Get started <ChevronRight size={15}/>
              </button>
            </div>
          ))}
        </div>

        <p style={{ textAlign:'center', fontSize:13, color:'#94a3b8', marginTop:28 }}>
          All plans include a 14-day free trial. No credit card required.
        </p>
      </section>

      {/* ── FAQs ── */}
      <section id="faqs" style={{ padding:'80px 24px', background:'#f8fafc' }}>
        <div style={{ maxWidth:720, margin:'0 auto' }}>
          <div style={{ textAlign:'center', marginBottom:52 }}>
            <p style={{ fontSize:13, fontWeight:700, color:'#0ea5e9', textTransform:'uppercase', letterSpacing:'0.1em', marginBottom:12 }}>FAQs</p>
            <h2 style={{ fontSize:38, fontWeight:900, letterSpacing:'-0.7px', color:'#0f172a' }}>Common questions</h2>
          </div>
          <div style={{ background:'#fff', border:'1px solid #eaecf0', borderRadius:18, padding:'8px 28px', boxShadow:'0 1px 4px rgba(0,0,0,0.05)' }}>
            {FAQS.map(item => <FaqItem key={item.q} {...item}/>)}
          </div>
        </div>
      </section>

      {/* ── CTA ── */}
      <section style={{ background:'linear-gradient(160deg,#0d1f3c,#0a3a5c)', padding:'96px 24px', textAlign:'center', position:'relative', overflow:'hidden' }}>
        <div style={{ position:'absolute', top:'-60px', left:'50%', transform:'translateX(-50%)', width:600, height:300, borderRadius:'50%', background:'radial-gradient(circle,rgba(14,165,233,0.12) 0%,transparent 70%)', pointerEvents:'none' }}/>
        <div style={{ maxWidth:640, margin:'0 auto', position:'relative', zIndex:1 }}>
          <div style={{ display:'inline-block', background:'rgba(255,255,255,0.97)', borderRadius:20, padding:'14px 32px', marginBottom:28, boxShadow:'0 8px 32px rgba(0,0,0,0.2)' }}>
            <img src="/leadflow-logo.png" alt="LeadFlow Digital" style={{ height:100, width:'auto', objectFit:'contain', display:'block' }} />
          </div>
          <h2 style={{ fontSize:42, fontWeight:900, color:'#fff', letterSpacing:'-1px', marginBottom:18, lineHeight:1.1 }}>
            Ready to win more jobs?
          </h2>
          <p style={{ fontSize:17, color:'rgba(255,255,255,0.5)', marginBottom:40, lineHeight:1.7 }}>
            Join hundreds of Australian businesses using LeadFlow Digital to grow faster and work smarter.
          </p>
          <button onClick={() => navigate('/signup')} style={{ display:'inline-flex', alignItems:'center', gap:10, padding:'16px 36px', borderRadius:14, border:'none', background:'linear-gradient(135deg,#0284c7,#0ea5e9)', color:'#fff', fontSize:16, fontWeight:800, cursor:'pointer', boxShadow:'0 10px 36px rgba(14,165,233,0.5)' }}>
            Start Your Free Trial <ArrowRight size={18}/>
          </button>
          <p style={{ fontSize:12, color:'rgba(255,255,255,0.25)', marginTop:16 }}>14-day free trial · No credit card · Cancel anytime</p>
        </div>
      </section>

      {/* ── Footer ── */}
      <footer style={{ background:'#0d1f3c', padding:'48px 24px 32px', borderTop:'1px solid rgba(255,255,255,0.06)' }}>
        <div style={{ maxWidth:1100, margin:'0 auto' }}>
          <div style={{ display:'grid', gridTemplateColumns:'2fr 1fr 1fr 1fr', gap:40, marginBottom:48, flexWrap:'wrap' }}>
            <div>
              <div style={{ display:'flex', alignItems:'center', gap:10, marginBottom:14 }}>
                <img src="/leadflow-logo.png" alt="LeadFlow Digital" style={{ height:56, width:'auto', objectFit:'contain', background:'rgba(255,255,255,0.92)', borderRadius:12, padding:'8px 14px' }} />
              </div>
              <p style={{ fontSize:13, color:'rgba(255,255,255,0.35)', lineHeight:1.8, maxWidth:260 }}>
                The complete CRM for Australian trade and service businesses. Manage leads, automate follow-ups, win more jobs.
              </p>
              <div style={{ display:'flex', gap:14, marginTop:18 }}>
                {[[Mail,'hello@leadflowdigital.com.au'],[Phone,'1800 000 000']].map(([Icon,label]) => (
                  <div key={label} style={{ display:'flex', alignItems:'center', gap:6 }}>
                    <Icon size={12} color="rgba(255,255,255,0.3)"/>
                    <span style={{ fontSize:12, color:'rgba(255,255,255,0.35)' }}>{label}</span>
                  </div>
                ))}
              </div>
            </div>
            {[
              ['Product',   ['Features','Pricing','Changelog','Roadmap']],
              ['Company',   ['About','Blog','Careers','Contact']],
              ['Legal',     ['Privacy Policy','Terms of Service','Security']],
            ].map(([heading, links]) => (
              <div key={heading}>
                <p style={{ fontSize:12, fontWeight:700, color:'rgba(255,255,255,0.5)', textTransform:'uppercase', letterSpacing:'0.08em', marginBottom:14 }}>{heading}</p>
                {links.map(link => (
                  <p key={link} style={{ marginBottom:10 }}>
                    <a href="#" style={{ fontSize:13, color:'rgba(255,255,255,0.35)', textDecoration:'none', transition:'color 0.15s' }}
                      onMouseEnter={e=>e.target.style.color='rgba(255,255,255,0.75)'}
                      onMouseLeave={e=>e.target.style.color='rgba(255,255,255,0.35)'}>
                      {link}
                    </a>
                  </p>
                ))}
              </div>
            ))}
          </div>
          <div style={{ borderTop:'1px solid rgba(255,255,255,0.06)', paddingTop:24, display:'flex', alignItems:'center', justifyContent:'space-between', flexWrap:'wrap', gap:12 }}>
            <p style={{ fontSize:12, color:'rgba(255,255,255,0.2)' }}>© {new Date().getFullYear()} LeadFlow Digital Pty Ltd. All rights reserved.</p>
            <p style={{ fontSize:12, color:'rgba(255,255,255,0.2)' }}>Made in Australia 🇦🇺</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
