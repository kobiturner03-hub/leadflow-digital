import { useState } from 'react'
import { useApp } from '../context/AppContext'
import { Users, Search, Trash2, Eye, Power, PowerOff, X, Calendar, Mail, Phone, Briefcase, BarChart2, TrendingUp } from 'lucide-react'

const INDUSTRY_COLORS = {
  'Trades & Construction':   { bg:'#f0f9ff', color:'#0284c7' },
  'Beauty & Wellness':       { bg:'#fdf2f8', color:'#9d174d' },
  'Automotive & Mechanical': { bg:'#fff7ed', color:'#c2410c' },
  'Cleaning Services':       { bg:'#f0fdf4', color:'#166534' },
  'Landscaping & Gardening': { bg:'#f0fdf4', color:'#15803d' },
  'Health & Fitness':        { bg:'#fef3c7', color:'#b45309' },
  'Real Estate':             { bg:'#f5f3ff', color:'#6d28d9' },
  'Hospitality & Food':      { bg:'#fff1f2', color:'#be123c' },
  'Education & Tutoring':    { bg:'#ecfeff', color:'#0e7490' },
  'Retail':                  { bg:'#fefce8', color:'#a16207' },
  'Technology & IT':         { bg:'#f0fdf4', color:'#065f46' },
  'Marketing Agency':        { bg:'#f0f9ff', color:'#0284c7' },
  'Other':                   { bg:'#f8fafc', color:'#475569' },
}

function industryBadge(ind) {
  const c = INDUSTRY_COLORS[ind] || INDUSTRY_COLORS['Other']
  return (
    <span style={{ ...c, fontSize:11, fontWeight:600, padding:'3px 8px', borderRadius:6, whiteSpace:'nowrap' }}>{ind || '—'}</span>
  )
}

function avatarInitials(name = '') {
  return name.split(' ').map(w => w[0]).join('').toUpperCase().slice(0,2)
}

const AVATAR_GRADIENTS = [
  'linear-gradient(135deg,#2563eb,#7c3aed)',
  'linear-gradient(135deg,#0891b2,#2563eb)',
  'linear-gradient(135deg,#059669,#0891b2)',
  'linear-gradient(135deg,#d97706,#dc2626)',
  'linear-gradient(135deg,#7c3aed,#db2777)',
]

export default function UserManagement() {
  const { users, leads, bookings, deleteUser, toggleUserActive } = useApp()
  const [search,      setSearch]      = useState('')
  const [viewUser,    setViewUser]    = useState(null)
  const [confirmDel,  setConfirmDel]  = useState(null)

  const businessUsers = users.filter(u => u.role !== 'admin')
  const filtered = businessUsers.filter(u =>
    [u.name, u.businessName, u.email, u.phone, u.industry].some(v => (v||'').toLowerCase().includes(search.toLowerCase()))
  )

  const getUserLeads    = (bId) => leads.filter(l => l.businessId === bId)
  const getUserBookings = (bId) => bookings.filter(b => b.businessId === bId)

  const cardStyle = { background:'#fff', borderRadius:16, border:'1px solid #eaecf0', boxShadow:'0 1px 3px rgba(0,0,0,0.06)' }

  return (
    <div style={{ padding:'28px 32px', minHeight:'100vh', background:'#f4f6f9' }}>
      {/* Header */}
      <div style={{ marginBottom:24 }}>
        <h1 style={{ fontSize:22, fontWeight:800, color:'#0f172a', letterSpacing:'-0.4px' }}>User Management</h1>
        <p style={{ fontSize:13, color:'#64748b', marginTop:4 }}>Manage all registered business accounts on the platform.</p>
      </div>

      {/* Stats row */}
      <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fit,minmax(160px,1fr))', gap:14, marginBottom:24 }}>
        {[
          { label:'Total Businesses', value: businessUsers.length, color:'#0ea5e9', bg:'#f0f9ff' },
          { label:'Active Accounts',  value: businessUsers.filter(u => u.active).length,  color:'#10b981', bg:'#f0fdf4' },
          { label:'Disabled Accounts',value: businessUsers.filter(u => !u.active).length, color:'#f59e0b', bg:'#fffbeb' },
          { label:'Total Leads',      value: leads.length,    color:'#7c3aed', bg:'#f5f3ff' },
        ].map(s => (
          <div key={s.label} style={{ ...cardStyle, padding:'16px 18px' }}>
            <p style={{ fontSize:11, fontWeight:600, color:'#94a3b8', textTransform:'uppercase', letterSpacing:'0.05em', marginBottom:6 }}>{s.label}</p>
            <p style={{ fontSize:26, fontWeight:800, color:s.color }}>{s.value}</p>
          </div>
        ))}
      </div>

      {/* Table card */}
      <div style={{ ...cardStyle, overflow:'hidden' }}>
        {/* Toolbar */}
        <div style={{ padding:'16px 20px', borderBottom:'1px solid #f1f5f9', display:'flex', alignItems:'center', gap:12 }}>
          <div style={{ position:'relative', flex:1, maxWidth:340 }}>
            <Search size={14} style={{ position:'absolute', left:12, top:'50%', transform:'translateY(-50%)', color:'#94a3b8' }} />
            <input
              value={search} onChange={e => setSearch(e.target.value)}
              placeholder="Search by name, email, industry…"
              style={{ width:'100%', padding:'8px 12px 8px 34px', borderRadius:10, border:'1px solid #e2e8f0', fontSize:13, outline:'none', fontFamily:'Inter,sans-serif', color:'#0f172a', boxSizing:'border-box' }}
              onFocus={e => e.target.style.borderColor='#0ea5e9'} onBlur={e => e.target.style.borderColor='#e2e8f0'}
            />
          </div>
          <div style={{ marginLeft:'auto', display:'flex', alignItems:'center', gap:6, background:'#f8fafc', border:'1px solid #e2e8f0', borderRadius:8, padding:'6px 12px' }}>
            <Users size={13} color="#64748b" />
            <span style={{ fontSize:12, fontWeight:600, color:'#374151' }}>{filtered.length} account{filtered.length !== 1 ? 's' : ''}</span>
          </div>
        </div>

        {/* Table */}
        <div style={{ overflowX:'auto' }}>
          <table style={{ width:'100%', borderCollapse:'collapse' }}>
            <thead>
              <tr style={{ background:'#f8fafc' }}>
                {['Business','Email','Phone','Industry','Joined','Status','Actions'].map(h => (
                  <th key={h} style={{ padding:'10px 16px', fontSize:11, fontWeight:600, color:'#94a3b8', textAlign:'left', textTransform:'uppercase', letterSpacing:'0.05em', whiteSpace:'nowrap' }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filtered.length === 0 && (
                <tr><td colSpan={7} style={{ padding:'40px', textAlign:'center', color:'#94a3b8', fontSize:13 }}>No users found.</td></tr>
              )}
              {filtered.map((u, idx) => {
                const grad = AVATAR_GRADIENTS[u.id % AVATAR_GRADIENTS.length]
                const joined = u.createdAt ? new Date(u.createdAt).toLocaleDateString('en-AU',{day:'numeric',month:'short',year:'numeric'}) : '—'
                return (
                  <tr key={u.id} style={{ borderTop:'1px solid #f1f5f9' }}
                    onMouseEnter={e => e.currentTarget.style.background='#fafbfc'}
                    onMouseLeave={e => e.currentTarget.style.background='#fff'}
                  >
                    {/* Business */}
                    <td style={{ padding:'12px 16px' }}>
                      <div style={{ display:'flex', alignItems:'center', gap:10 }}>
                        <div style={{ width:36, height:36, borderRadius:10, background:grad, display:'flex', alignItems:'center', justifyContent:'center', color:'#fff', fontSize:12, fontWeight:700, flexShrink:0 }}>
                          {avatarInitials(u.name)}
                        </div>
                        <div>
                          <p style={{ fontSize:13, fontWeight:700, color:'#0f172a', lineHeight:1.2 }}>{u.name}</p>
                          <p style={{ fontSize:11, color:'#94a3b8', marginTop:1 }}>{u.businessName}</p>
                        </div>
                      </div>
                    </td>
                    {/* Email */}
                    <td style={{ padding:'12px 16px', fontSize:12, color:'#374151' }}>{u.email}</td>
                    {/* Phone */}
                    <td style={{ padding:'12px 16px', fontSize:12, color:'#374151', whiteSpace:'nowrap' }}>{u.phone || '—'}</td>
                    {/* Industry */}
                    <td style={{ padding:'12px 16px' }}>{industryBadge(u.industry)}</td>
                    {/* Joined */}
                    <td style={{ padding:'12px 16px', fontSize:12, color:'#64748b', whiteSpace:'nowrap' }}>{joined}</td>
                    {/* Status */}
                    <td style={{ padding:'12px 16px' }}>
                      <span style={{
                        fontSize:11, fontWeight:600, padding:'3px 9px', borderRadius:20,
                        background: u.active ? '#f0fdf4' : '#fff7ed',
                        color:      u.active ? '#059669' : '#d97706',
                      }}>
                        {u.active ? 'Active' : 'Disabled'}
                      </span>
                    </td>
                    {/* Actions */}
                    <td style={{ padding:'12px 16px' }}>
                      <div style={{ display:'flex', alignItems:'center', gap:6 }}>
                        <button onClick={() => setViewUser(u)} title="View details"
                          style={{ width:30, height:30, borderRadius:8, border:'1px solid #e2e8f0', background:'#fff', cursor:'pointer', display:'flex', alignItems:'center', justifyContent:'center', color:'#0ea5e9' }}
                          onMouseEnter={e => e.currentTarget.style.background='#f0f9ff'}
                          onMouseLeave={e => e.currentTarget.style.background='#fff'}
                        ><Eye size={13}/></button>
                        <button onClick={() => toggleUserActive(u.id)} title={u.active ? 'Disable account' : 'Enable account'}
                          style={{ width:30, height:30, borderRadius:8, border:'1px solid #e2e8f0', background:'#fff', cursor:'pointer', display:'flex', alignItems:'center', justifyContent:'center', color: u.active ? '#f59e0b' : '#10b981' }}
                          onMouseEnter={e => e.currentTarget.style.background='#f8fafc'}
                          onMouseLeave={e => e.currentTarget.style.background='#fff'}
                        >{u.active ? <PowerOff size={13}/> : <Power size={13}/>}</button>
                        <button onClick={() => setConfirmDel(u)} title="Delete user"
                          style={{ width:30, height:30, borderRadius:8, border:'1px solid #fecaca', background:'#fff', cursor:'pointer', display:'flex', alignItems:'center', justifyContent:'center', color:'#ef4444' }}
                          onMouseEnter={e => e.currentTarget.style.background='#fef2f2'}
                          onMouseLeave={e => e.currentTarget.style.background='#fff'}
                        ><Trash2 size={13}/></button>
                      </div>
                    </td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* ── View Details Modal ── */}
      {viewUser && (() => {
        const userLeads    = getUserLeads(viewUser.businessId)
        const userBookings = getUserBookings(viewUser.businessId)
        const revenue      = userLeads.filter(l => l.paymentStatus === 'Paid').reduce((s, l) => s + (l.jobValue||0), 0)
        const joined       = viewUser.createdAt ? new Date(viewUser.createdAt).toLocaleDateString('en-AU',{day:'numeric',month:'long',year:'numeric'}) : '—'
        const grad         = AVATAR_GRADIENTS[viewUser.id % AVATAR_GRADIENTS.length]
        return (
          <div style={{ position:'fixed', inset:0, background:'rgba(0,0,0,0.45)', display:'flex', alignItems:'center', justifyContent:'center', zIndex:1000, padding:16 }}>
            <div style={{ background:'#fff', borderRadius:20, width:'100%', maxWidth:520, boxShadow:'0 24px 80px rgba(0,0,0,0.25)', overflow:'hidden' }}>
              {/* Hero */}
              <div style={{ background:'linear-gradient(135deg,#0c1628,#0e2044)', padding:'24px 24px 20px', position:'relative' }}>
                <button onClick={() => setViewUser(null)} style={{ position:'absolute', top:16, right:16, width:30, height:30, borderRadius:8, border:'1px solid rgba(255,255,255,0.12)', background:'rgba(255,255,255,0.08)', cursor:'pointer', display:'flex', alignItems:'center', justifyContent:'center', color:'rgba(255,255,255,0.6)' }}><X size={15}/></button>
                <div style={{ display:'flex', alignItems:'center', gap:14 }}>
                  <div style={{ width:52, height:52, borderRadius:14, background:grad, display:'flex', alignItems:'center', justifyContent:'center', color:'#fff', fontSize:18, fontWeight:800 }}>
                    {avatarInitials(viewUser.name)}
                  </div>
                  <div>
                    <p style={{ color:'#fff', fontSize:16, fontWeight:800, letterSpacing:'-0.3px' }}>{viewUser.name}</p>
                    <p style={{ color:'rgba(255,255,255,0.5)', fontSize:12, marginTop:2 }}>{viewUser.businessName}</p>
                    <div style={{ marginTop:6 }}>{industryBadge(viewUser.industry)}</div>
                  </div>
                </div>
                {/* Mini stats */}
                <div style={{ display:'grid', gridTemplateColumns:'repeat(3,1fr)', gap:10, marginTop:18 }}>
                  {[
                    { label:'Leads',    value: userLeads.length },
                    { label:'Bookings', value: userBookings.length },
                    { label:'Revenue',  value: `$${revenue.toLocaleString()}` },
                  ].map(s => (
                    <div key={s.label} style={{ background:'rgba(255,255,255,0.07)', borderRadius:10, padding:'10px 12px', textAlign:'center' }}>
                      <p style={{ color:'#fff', fontSize:18, fontWeight:800 }}>{s.value}</p>
                      <p style={{ color:'rgba(255,255,255,0.4)', fontSize:11, marginTop:2 }}>{s.label}</p>
                    </div>
                  ))}
                </div>
              </div>

              {/* Details */}
              <div style={{ padding:'20px 24px 24px' }}>
                <p style={{ fontSize:11, fontWeight:700, color:'#94a3b8', textTransform:'uppercase', letterSpacing:'0.06em', marginBottom:12 }}>Account Details</p>
                <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:12 }}>
                  {[
                    { icon:Mail,     label:'Email',   val: viewUser.email },
                    { icon:Phone,    label:'Phone',   val: viewUser.phone || '—' },
                    { icon:Calendar, label:'Joined',  val: joined },
                    { icon:Briefcase,label:'Status',  val: viewUser.active ? 'Active' : 'Disabled' },
                  ].map(({ icon:Icon, label, val }) => (
                    <div key={label} style={{ background:'#f8fafc', border:'1px solid #f1f5f9', borderRadius:10, padding:'10px 12px', display:'flex', alignItems:'flex-start', gap:10 }}>
                      <div style={{ width:28, height:28, borderRadius:8, background:'#f0f9ff', display:'flex', alignItems:'center', justifyContent:'center', flexShrink:0 }}>
                        <Icon size={13} color="#2563eb"/>
                      </div>
                      <div>
                        <p style={{ fontSize:10, color:'#94a3b8', fontWeight:600, textTransform:'uppercase', letterSpacing:'0.04em' }}>{label}</p>
                        <p style={{ fontSize:12, color:'#0f172a', fontWeight:600, marginTop:2 }}>{val}</p>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Action buttons */}
                <div style={{ display:'flex', gap:8, marginTop:16 }}>
                  <button onClick={() => { toggleUserActive(viewUser.id); setViewUser(v => ({ ...v, active: !v.active })) }}
                    style={{ flex:1, padding:'9px', borderRadius:10, border:`1px solid ${viewUser.active ? '#fbbf24' : '#34d399'}`, background: viewUser.active ? '#fffbeb' : '#f0fdf4', color: viewUser.active ? '#d97706' : '#059669', fontSize:12, fontWeight:700, cursor:'pointer', display:'flex', alignItems:'center', justifyContent:'center', gap:6 }}>
                    {viewUser.active ? <><PowerOff size={13}/> Disable Account</> : <><Power size={13}/> Enable Account</>}
                  </button>
                  <button onClick={() => { setViewUser(null); setConfirmDel(viewUser) }}
                    style={{ flex:1, padding:'9px', borderRadius:10, border:'1px solid #fecaca', background:'#fef2f2', color:'#ef4444', fontSize:12, fontWeight:700, cursor:'pointer', display:'flex', alignItems:'center', justifyContent:'center', gap:6 }}>
                    <Trash2 size={13}/> Delete User
                  </button>
                </div>
              </div>
            </div>
          </div>
        )
      })()}

      {/* ── Confirm Delete Modal ── */}
      {confirmDel && (
        <div style={{ position:'fixed', inset:0, background:'rgba(0,0,0,0.45)', display:'flex', alignItems:'center', justifyContent:'center', zIndex:1001, padding:16 }}>
          <div style={{ background:'#fff', borderRadius:18, width:'100%', maxWidth:380, boxShadow:'0 24px 80px rgba(0,0,0,0.25)', padding:'28px 28px 24px' }}>
            <div style={{ width:48, height:48, borderRadius:14, background:'#fef2f2', display:'flex', alignItems:'center', justifyContent:'center', marginBottom:16 }}>
              <Trash2 size={20} color="#ef4444"/>
            </div>
            <h3 style={{ fontSize:16, fontWeight:800, color:'#0f172a', marginBottom:8 }}>Delete Account?</h3>
            <p style={{ fontSize:13, color:'#64748b', lineHeight:1.6 }}>
              This will permanently delete <strong>{confirmDel.name}</strong> ({confirmDel.businessName}) and all their data. This action cannot be undone.
            </p>
            <div style={{ display:'flex', gap:10, marginTop:20 }}>
              <button onClick={() => setConfirmDel(null)}
                style={{ flex:1, padding:'10px', borderRadius:10, border:'1px solid #e2e8f0', background:'#fff', fontSize:13, fontWeight:600, color:'#374151', cursor:'pointer' }}>
                Cancel
              </button>
              <button onClick={() => { deleteUser(confirmDel.id); setConfirmDel(null) }}
                style={{ flex:1, padding:'10px', borderRadius:10, border:'none', background:'linear-gradient(135deg,#dc2626,#ef4444)', fontSize:13, fontWeight:700, color:'#fff', cursor:'pointer' }}>
                Delete Account
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
