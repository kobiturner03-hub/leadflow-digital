import { useState } from 'react'
import { useApp } from '../context/AppContext'
import { Building2, Bell, Shield, Check, Save, Copy, ExternalLink, Globe, Phone, Mail, Key, Link2 } from 'lucide-react'

const inputStyle = { width:'100%', padding:'9px 12px', borderRadius:10, border:'1px solid #e2e8f0', fontSize:13, outline:'none', fontFamily:'inherit', color:'#0f172a', background:'#fff' }
const labelStyle = { display:'block', fontSize:12, fontWeight:600, color:'#374151', marginBottom:5 }

function Toggle({ on, onChange }) {
  return (
    <button onClick={() => onChange(!on)} style={{ width:40, height:22, borderRadius:11, border:'none', cursor:'pointer', padding:3, display:'flex', alignItems:'center', background: on ? '#0ea5e9' : '#e2e8f0', transition:'background 0.2s', flexShrink:0 }}>
      <span style={{ width:16, height:16, borderRadius:'50%', background:'#fff', display:'block', transform: on ? 'translateX(18px)' : 'translateX(0)', transition:'transform 0.2s', boxShadow:'0 1px 4px rgba(0,0,0,0.2)' }}/>
    </button>
  )
}

function Section({ icon:Icon, accent, bg, title, children }) {
  return (
    <div style={{ background:'#fff', border:'1px solid #eaecf0', borderRadius:16, overflow:'hidden', boxShadow:'0 1px 3px rgba(0,0,0,0.05)' }}>
      <div style={{ display:'flex', alignItems:'center', gap:12, padding:'16px 22px', borderBottom:'1px solid #f1f5f9' }}>
        <div style={{ width:34, height:34, borderRadius:10, background:bg, display:'flex', alignItems:'center', justifyContent:'center', flexShrink:0 }}>
          <Icon size={16} color={accent}/>
        </div>
        <p style={{ fontSize:14, fontWeight:700, color:'#0f172a' }}>{title}</p>
      </div>
      <div style={{ padding:'18px 22px' }}>{children}</div>
    </div>
  )
}

function ToggleRow({ label, description, on, onChange }) {
  return (
    <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', padding:'11px 0', borderBottom:'1px solid #f8fafc' }}>
      <div>
        <p style={{ fontSize:13, fontWeight:600, color:'#0f172a' }}>{label}</p>
        {description && <p style={{ fontSize:11, color:'#94a3b8', marginTop:2 }}>{description}</p>}
      </div>
      <Toggle on={on} onChange={onChange}/>
    </div>
  )
}

function LeadCaptureSection({ businessId }) {
  const WEBHOOK_URL = 'https://hyubxsdrjjmljsroildz.supabase.co/functions/v1/capture-lead'

  const snippet = `<!-- LeadFlow Digital — Lead Capture Integration -->
<!-- Paste this just before </body> on your website -->
<!-- This URL is permanent and never needs updating -->
<script>
(function() {
  // Map these to the name="" attributes of YOUR existing form fields
  var FIELD_MAP = {
    name:    'your-name-field',     // name="" of your name input
    phone:   'your-phone-field',    // name="" of your phone input
    email:   'your-email-field',    // name="" of your email input
    service: 'your-service-field',  // name="" of your service/dropdown input
    message: 'your-message-field',  // name="" of your message/textarea
  };

  document.addEventListener('submit', function(e) {
    var form = e.target;
    function val(key) {
      var el = form.elements[FIELD_MAP[key]];
      return el ? el.value.trim() : '';
    }
    var name  = val('name');
    var phone = val('phone');
    var email = val('email');
    if (!name && !phone && !email) return;
    fetch('${WEBHOOK_URL}', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        name: name, phone: phone, email: email,
        service: val('service'), message: val('message'),
        business_id: ${businessId},
      }),
    });
  });
})();
</script>`

  const [copied, setCopied] = useState(false)
  const copy = () => {
    navigator.clipboard.writeText(snippet)
    setCopied(true); setTimeout(() => setCopied(false), 2000)
  }

  const steps = [
    { n: '1', text: 'Copy the snippet below' },
    { n: '2', text: 'Paste it before </body> on your website' },
    { n: '3', text: 'Update the FIELD_MAP values to match the name="" attributes on your existing form inputs' },
    { n: '4', text: 'Submit a test lead — it will appear in your Leads page instantly' },
  ]

  return (
    <Section icon={Globe} accent="#2563eb" bg="rgba(14,165,233,0.1)" title="Connect Your Existing Lead Form">
      <div style={{ display:'flex', flexDirection:'column', gap:16 }}>

        <p style={{ fontSize:13, color:'#64748b', lineHeight:1.6 }}>
          Keep your current website form exactly as it is. Paste the snippet below and every submission will automatically appear as a new lead in this CRM — no changes to your form needed.
        </p>

        {/* Steps */}
        <div style={{ display:'flex', flexDirection:'column', gap:8 }}>
          {steps.map(({ n, text }) => (
            <div key={n} style={{ display:'flex', alignItems:'flex-start', gap:10 }}>
              <div style={{ width:22, height:22, borderRadius:'50%', background:'#0ea5e9', color:'#fff', fontSize:11, fontWeight:700, display:'flex', alignItems:'center', justifyContent:'center', flexShrink:0, marginTop:1 }}>{n}</div>
              <p style={{ fontSize:13, color:'#374151', lineHeight:1.5 }}>{text}</p>
            </div>
          ))}
        </div>

        {/* Code block */}
        <div>
          <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', marginBottom:8 }}>
            <label style={{ ...labelStyle, marginBottom:0 }}>Integration Snippet</label>
            <button onClick={copy} style={{ display:'flex', alignItems:'center', gap:5, padding:'5px 14px', borderRadius:8, border:'none', background: copied ? '#059669' : '#0ea5e9', color:'#fff', fontSize:11, fontWeight:700, cursor:'pointer', transition:'background 0.2s' }}>
              {copied ? <><Check size={11}/> Copied!</> : <><Copy size={11}/> Copy Snippet</>}
            </button>
          </div>
          <pre style={{ margin:0, padding:'14px 16px', background:'#0f172a', borderRadius:12, fontSize:11, color:'#94a3b8', lineHeight:1.8, overflowX:'auto', fontFamily:'monospace', whiteSpace:'pre', maxHeight:320, overflowY:'auto' }}>
{snippet.split('\n').map((line, i) => {
  // Colour comments grey, strings yellow, keywords blue
  if (line.trim().startsWith('//') || line.trim().startsWith('<!--')) {
    return <span key={i} style={{ color:'#4b5563' }}>{line}{'\n'}</span>
  }
  if (line.includes('FIELD_MAP') || line.includes('var ') || line.includes('function') || line.includes('return')) {
    return <span key={i} style={{ color:'#7dd3fc' }}>{line}{'\n'}</span>
  }
  if (line.includes("'") || line.includes('"')) {
    return <span key={i} style={{ color:'#86efac' }}>{line}{'\n'}</span>
  }
  return <span key={i} style={{ color:'#cbd5e1' }}>{line}{'\n'}</span>
})}
          </pre>
        </div>

        <div style={{ background:'#f0f9ff', border:'1px solid #bae6fd', borderRadius:10, padding:'10px 14px', display:'flex', gap:8, alignItems:'flex-start' }}>
          <Globe size={14} color="#2563eb" style={{ flexShrink:0, marginTop:1 }}/>
          <p style={{ fontSize:12, color:'#1e40af', lineHeight:1.6 }}>
            Your existing form stays completely unchanged. The snippet silently sends a copy of each submission to your CRM — your visitors won't notice anything different.
          </p>
        </div>

      </div>
    </Section>
  )
}

function IntegrationsSection({ settings, updateSettings }) {
  const [intForm, setIntForm] = useState({
    twilioSid:   settings.twilioSid   || '',
    twilioToken: settings.twilioToken || '',
    twilioFrom:  settings.twilioFrom  || '',
    resendKey:   settings.resendKey   || '',
  })
  const [intSaved, setIntSaved] = useState(false)
  const si = (k, v) => setIntForm(p => ({ ...p, [k]: v }))
  const saveInt = async () => {
    await updateSettings(intForm)
    setIntSaved(true); setTimeout(() => setIntSaved(false), 3000)
  }

  return (
    <Section icon={Link2} accent="#f59e0b" bg="rgba(245,158,11,0.1)" title="Integrations">
      <div style={{ display:'flex', flexDirection:'column', gap:20 }}>

        {/* Resend */}
        <div>
          <div style={{ display:'flex', alignItems:'center', gap:8, marginBottom:12 }}>
            <div style={{ width:28, height:28, borderRadius:8, background:'rgba(14,165,233,0.1)', display:'flex', alignItems:'center', justifyContent:'center' }}>
              <Mail size={13} color="#2563eb"/>
            </div>
            <p style={{ fontSize:13, fontWeight:700, color:'#0f172a' }}>Email — Resend</p>
            <a href="https://resend.com" target="_blank" rel="noopener noreferrer" style={{ fontSize:11, color:'#0ea5e9', textDecoration:'none', display:'flex', alignItems:'center', gap:3 }}>
              <ExternalLink size={10}/> Get API key
            </a>
          </div>
          <div>
            <label style={labelStyle}>Resend API Key</label>
            <div style={{ position:'relative' }}>
              <Key size={13} style={{ position:'absolute', left:12, top:'50%', transform:'translateY(-50%)', color:'#94a3b8' }}/>
              <input type="password" value={intForm.resendKey} onChange={e => si('resendKey', e.target.value)}
                placeholder="re_••••••••••••••••" style={{ ...inputStyle, paddingLeft:34 }}/>
            </div>
          </div>
        </div>

        <div style={{ borderTop:'1px solid #f1f5f9', paddingTop:20 }}>
          <div style={{ display:'flex', alignItems:'center', gap:8, marginBottom:12 }}>
            <div style={{ width:28, height:28, borderRadius:8, background:'rgba(16,185,129,0.1)', display:'flex', alignItems:'center', justifyContent:'center' }}>
              <Phone size={13} color="#10b981"/>
            </div>
            <p style={{ fontSize:13, fontWeight:700, color:'#0f172a' }}>SMS — Twilio</p>
            <a href="https://console.twilio.com" target="_blank" rel="noopener noreferrer" style={{ fontSize:11, color:'#0ea5e9', textDecoration:'none', display:'flex', alignItems:'center', gap:3 }}>
              <ExternalLink size={10}/> Twilio console
            </a>
          </div>
          <div style={{ display:'flex', flexDirection:'column', gap:10 }}>
            <div>
              <label style={labelStyle}>Account SID</label>
              <div style={{ position:'relative' }}>
                <Key size={13} style={{ position:'absolute', left:12, top:'50%', transform:'translateY(-50%)', color:'#94a3b8' }}/>
                <input value={intForm.twilioSid} onChange={e => si('twilioSid', e.target.value)}
                  placeholder="ACxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx" style={{ ...inputStyle, paddingLeft:34 }}/>
              </div>
            </div>
            <div>
              <label style={labelStyle}>Auth Token</label>
              <div style={{ position:'relative' }}>
                <Key size={13} style={{ position:'absolute', left:12, top:'50%', transform:'translateY(-50%)', color:'#94a3b8' }}/>
                <input type="password" value={intForm.twilioToken} onChange={e => si('twilioToken', e.target.value)}
                  placeholder="••••••••••••••••••••••••••••••••" style={{ ...inputStyle, paddingLeft:34 }}/>
              </div>
            </div>
            <div>
              <label style={labelStyle}>From Phone Number</label>
              <div style={{ position:'relative' }}>
                <Phone size={13} style={{ position:'absolute', left:12, top:'50%', transform:'translateY(-50%)', color:'#94a3b8' }}/>
                <input value={intForm.twilioFrom} onChange={e => si('twilioFrom', e.target.value)}
                  placeholder="+61400000000" style={{ ...inputStyle, paddingLeft:34 }}/>
              </div>
            </div>
          </div>
        </div>

        <button onClick={saveInt} style={{ display:'inline-flex', alignItems:'center', gap:7, padding:'9px 18px', borderRadius:10, border:'none', fontSize:13, fontWeight:700, cursor:'pointer', width:'fit-content', background: intSaved ? '#059669' : '#0ea5e9', color:'#fff', transition:'background 0.2s' }}>
          {intSaved ? <><Check size={14}/> Saved!</> : <><Save size={14}/> Save Integrations</>}
        </button>
      </div>
    </Section>
  )
}

export default function Settings() {
  const { settings, updateSettings, currentUser } = useApp()
  const [saved, setSaved] = useState(false)
  const [form, setForm] = useState({ name: settings.name, phone: settings.phone, email: settings.email })
  const s = (k,v) => setForm(p => ({...p,[k]:v}))

  const handleSave = async () => {
    await updateSettings(form)
    setSaved(true)
    setTimeout(() => setSaved(false), 3000)
  }

  return (
    <div style={{ padding:28, maxWidth:680, minHeight:'100%' }}>
      <div style={{ marginBottom:24 }}>
        <h1 style={{ fontSize:20, fontWeight:800, color:'#0f172a', letterSpacing:'-0.3px' }}>Settings</h1>
        <p style={{ fontSize:13, color:'#94a3b8', marginTop:3 }}>Manage your account and preferences</p>
      </div>

      <div style={{ display:'flex', flexDirection:'column', gap:16 }}>

        {/* Business details */}
        <Section icon={Building2} accent="#2563eb" bg="rgba(14,165,233,0.1)" title="Business Details">
          <div style={{ display:'flex', flexDirection:'column', gap:14 }}>
            <div>
              <label style={labelStyle}>Business Name</label>
              <input value={form.name} onChange={e=>s('name',e.target.value)} style={inputStyle}/>
            </div>
            <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:14 }}>
              <div>
                <label style={labelStyle}>Phone</label>
                <input value={form.phone} onChange={e=>s('phone',e.target.value)} style={inputStyle}/>
              </div>
              <div>
                <label style={labelStyle}>Email</label>
                <input type="email" value={form.email} onChange={e=>s('email',e.target.value)} style={inputStyle}/>
              </div>
            </div>
            <button onClick={handleSave}
              style={{ display:'inline-flex', alignItems:'center', gap:7, padding:'9px 18px', borderRadius:10, border:'none', fontSize:13, fontWeight:700, cursor:'pointer', width:'fit-content', background: saved ? '#059669' : '#0ea5e9', color:'#fff', transition:'background 0.2s' }}>
              {saved ? <><Check size={14}/> Saved!</> : <><Save size={14}/> Save Changes</>}
            </button>
          </div>
        </Section>

        {/* Notifications */}
        <Section icon={Bell} accent="#f59e0b" bg="rgba(245,158,11,0.1)" title="Notification Preferences">
          <div>
            <ToggleRow label="Email Notifications" description="Receive alerts via email" on={settings.notifications?.email} onChange={v=>updateSettings({notifications:{...settings.notifications,email:v}})}/>
            <ToggleRow label="SMS Notifications" description="Receive SMS for important events" on={settings.notifications?.sms} onChange={v=>updateSettings({notifications:{...settings.notifications,sms:v}})}/>
            <ToggleRow label="New Lead Alerts" description="Notify when a new lead is submitted" on={settings.notifications?.newLead} onChange={v=>updateSettings({notifications:{...settings.notifications,newLead:v}})}/>
            <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', paddingTop:11 }}>
              <div>
                <p style={{ fontSize:13, fontWeight:600, color:'#0f172a' }}>Booking Alerts</p>
                <p style={{ fontSize:11, color:'#94a3b8', marginTop:2 }}>Notify when a booking is made</p>
              </div>
              <Toggle on={settings.notifications?.booking} onChange={v=>updateSettings({notifications:{...settings.notifications,booking:v}})}/>
            </div>
          </div>
        </Section>


        {/* Lead Capture Form — only for business users */}
        {currentUser?.role !== 'admin' && currentUser?.businessId && (
          <LeadCaptureSection businessId={currentUser.businessId} />
        )}

        {/* Integrations — only for business users */}
        {currentUser?.role !== 'admin' && (
          <IntegrationsSection settings={settings} updateSettings={updateSettings} />
        )}

        {/* Account */}
        <Section icon={Shield} accent="#64748b" bg="rgba(100,116,139,0.1)" title="Account">
          <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:12 }}>
            {[
              ['Logged in as', currentUser?.name],
              ['Role', currentUser?.role?.charAt(0).toUpperCase() + currentUser?.role?.slice(1)],
              ['Email', currentUser?.email],
              ['Platform', 'LeadFlow Digital'],
            ].map(([label, val]) => (
              <div key={label} style={{ background:'#f8fafc', borderRadius:10, padding:'10px 14px' }}>
                <p style={{ fontSize:11, color:'#94a3b8', fontWeight:600, marginBottom:3 }}>{label}</p>
                <p style={{ fontSize:13, fontWeight:600, color:'#0f172a' }}>{val}</p>
              </div>
            ))}
          </div>
        </Section>

      </div>
    </div>
  )
}
