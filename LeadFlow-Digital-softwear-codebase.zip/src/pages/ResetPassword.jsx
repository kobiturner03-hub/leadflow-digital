import { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { supabase } from '../lib/supabase'
import { Eye, EyeOff, CheckCircle, KeyRound, AlertTriangle } from 'lucide-react'

export default function ResetPassword() {
  const navigate = useNavigate()
  const [ready,   setReady]   = useState(false)   // session established
  const [expired, setExpired] = useState(false)   // bad/expired link
  const [pw,      setPw]      = useState('')
  const [pwC,     setPwC]     = useState('')
  const [showPw,  setShowPw]  = useState(false)
  const [saving,  setSaving]  = useState(false)
  const [saved,   setSaved]   = useState(false)
  const [error,   setError]   = useState('')

  useEffect(() => {
    const hash = window.location.hash

    // Check for error in URL (expired/invalid link)
    if (hash) {
      const params = new URLSearchParams(hash.replace(/^#/, ''))
      const errCode = params.get('error_code') || params.get('error')
      if (errCode) { setExpired(true); return }
    }

    // Primary: listen for PASSWORD_RECOVERY event
    const { data: { subscription } } = supabase.auth.onAuthStateChange((event, session) => {
      if (event === 'PASSWORD_RECOVERY') { setReady(true); return }
      // Fallback: SIGNED_IN also fires after recovery token exchange
      if (event === 'SIGNED_IN' && session) { setReady(true); return }
    })

    // Secondary: if Supabase already processed the hash before we subscribed,
    // getSession() will return the active recovery session
    supabase.auth.getSession().then(({ data: { session } }) => {
      if (session) setReady(true)
    })

    return () => subscription.unsubscribe()
  }, [])

  const handleSubmit = async (e) => {
    e.preventDefault()
    setError('')
    if (pw.length < 8) { setError('Password must be at least 8 characters.'); return }
    if (pw !== pwC)    { setError('Passwords do not match.'); return }
    setSaving(true)
    const { error: err } = await supabase.auth.updateUser({ password: pw })
    if (err) { setError(err.message); setSaving(false); return }
    setSaved(true)
    setSaving(false)
    // Sign out the recovery session, then send to login
    setTimeout(async () => {
      await supabase.auth.signOut()
      navigate('/login', { replace: true })
    }, 2000)
  }

  const inputStyle = {
    width: '100%', padding: '11px 14px', borderRadius: 11,
    border: '1px solid #e2e8f0', fontSize: 14, outline: 'none',
    fontFamily: 'Inter,sans-serif', color: '#0f172a', background: '#fff',
    boxSizing: 'border-box',
  }

  return (
    <div style={{
      minHeight: '100vh',
      background: 'linear-gradient(160deg,#0d1f3c 0%,#0a3a5c 55%,#062a44 100%)',
      display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '24px 16px',
    }}>
      {/* Glow effects */}
      <div style={{ position:'fixed', top:'-120px', right:'-120px', width:450, height:450, borderRadius:'50%', background:'radial-gradient(circle,rgba(14,165,233,0.12) 0%,transparent 70%)', pointerEvents:'none' }}/>
      <div style={{ position:'fixed', bottom:'-100px', left:'-100px', width:380, height:380, borderRadius:'50%', background:'radial-gradient(circle,rgba(34,197,94,0.08) 0%,transparent 70%)', pointerEvents:'none' }}/>

      <div style={{ width:'100%', maxWidth:420, position:'relative', zIndex:1 }}>
        {/* Logo */}
        <div style={{ textAlign:'center', marginBottom:32 }}>
          <div style={{ display:'inline-block', background:'rgba(255,255,255,0.97)', borderRadius:20, padding:'14px 28px', marginBottom:16, boxShadow:'0 8px 32px rgba(0,0,0,0.18)' }}>
            <img src="/leadflow-logo.png" alt="LeadFlow Digital" style={{ height:96, width:'auto', objectFit:'contain', display:'block' }} />
          </div>
        </div>

        {/* Card */}
        <div style={{ background:'#fff', borderRadius:20, padding:'32px', boxShadow:'0 24px 80px rgba(0,0,0,0.35)' }}>

          {/* Expired link */}
          {expired && (
            <div style={{ textAlign:'center' }}>
              <div style={{ width:52, height:52, borderRadius:14, background:'rgba(239,68,68,0.1)', display:'flex', alignItems:'center', justifyContent:'center', margin:'0 auto 16px' }}>
                <AlertTriangle size={24} color="#dc2626"/>
              </div>
              <h2 style={{ fontSize:17, fontWeight:800, color:'#0f172a', marginBottom:8 }}>Link expired</h2>
              <p style={{ fontSize:13, color:'#64748b', marginBottom:20, lineHeight:1.6 }}>This reset link has expired or already been used. Request a new one from the login page.</p>
              <button onClick={() => navigate('/login')} style={{ padding:'10px 24px', borderRadius:10, border:'none', background:'#0ea5e9', color:'#fff', fontSize:13, fontWeight:700, cursor:'pointer' }}>
                Back to Login
              </button>
            </div>
          )}

          {/* Waiting for Supabase to fire PASSWORD_RECOVERY */}
          {!expired && !ready && (
            <div style={{ textAlign:'center', padding:'16px 0' }}>
              <div style={{ width:32, height:32, border:'3px solid rgba(14,165,233,0.15)', borderTopColor:'#0ea5e9', borderRadius:'50%', animation:'spin 0.8s linear infinite', margin:'0 auto 16px' }}/>
              <p style={{ fontSize:14, color:'#64748b' }}>Verifying reset link…</p>
            </div>
          )}

          {/* Success */}
          {!expired && saved && (
            <div style={{ textAlign:'center', padding:'8px 0' }}>
              <CheckCircle size={44} color="#10b981" style={{ margin:'0 auto 16px', display:'block' }}/>
              <h2 style={{ fontSize:17, fontWeight:800, color:'#0f172a', marginBottom:6 }}>Password updated!</h2>
              <p style={{ fontSize:13, color:'#64748b' }}>Redirecting you to sign in…</p>
            </div>
          )}

          {/* Reset form */}
          {!expired && ready && !saved && (
            <>
              <div style={{ marginBottom:24 }}>
                <div style={{ width:44, height:44, borderRadius:12, background:'rgba(14,165,233,0.1)', display:'flex', alignItems:'center', justifyContent:'center', marginBottom:14 }}>
                  <KeyRound size={20} color="#2563eb"/>
                </div>
                <h2 style={{ fontSize:17, fontWeight:800, color:'#0f172a', letterSpacing:'-0.3px', marginBottom:4 }}>Set a new password</h2>
                <p style={{ fontSize:12, color:'#94a3b8' }}>Choose a strong password for your account</p>
              </div>

              <form onSubmit={handleSubmit} style={{ display:'flex', flexDirection:'column', gap:16 }}>
                <div>
                  <label style={{ display:'block', fontSize:12, fontWeight:600, color:'#374151', marginBottom:6 }}>New password</label>
                  <div style={{ position:'relative' }}>
                    <input
                      type={showPw ? 'text' : 'password'}
                      value={pw} onChange={e => setPw(e.target.value)}
                      required placeholder="Min. 8 characters"
                      style={{ ...inputStyle, paddingRight:44 }}
                      onFocus={e => e.target.style.borderColor='#0ea5e9'}
                      onBlur={e  => e.target.style.borderColor='#e2e8f0'}
                    />
                    <button type="button" onClick={() => setShowPw(!showPw)}
                      style={{ position:'absolute', right:12, top:'50%', transform:'translateY(-50%)', background:'none', border:'none', cursor:'pointer', color:'#94a3b8', display:'flex', alignItems:'center', padding:0 }}>
                      {showPw ? <EyeOff size={15}/> : <Eye size={15}/>}
                    </button>
                  </div>
                </div>

                <div>
                  <label style={{ display:'block', fontSize:12, fontWeight:600, color:'#374151', marginBottom:6 }}>Confirm new password</label>
                  <input
                    type="password" value={pwC} onChange={e => setPwC(e.target.value)}
                    required placeholder="Re-enter password"
                    style={inputStyle}
                    onFocus={e => e.target.style.borderColor='#0ea5e9'}
                    onBlur={e  => e.target.style.borderColor='#e2e8f0'}
                  />
                </div>

                {error && (
                  <div style={{ background:'#fef2f2', border:'1px solid #fecaca', borderRadius:10, padding:'10px 14px', display:'flex', gap:8, alignItems:'center' }}>
                    <div style={{ width:6, height:6, borderRadius:'50%', background:'#ef4444', flexShrink:0 }}/>
                    <p style={{ fontSize:12, color:'#dc2626', fontWeight:500 }}>{error}</p>
                  </div>
                )}

                <button type="submit" disabled={saving}
                  style={{ width:'100%', padding:'12px', borderRadius:11, border:'none', background: saving ? 'rgba(14,165,233,0.7)' : 'linear-gradient(135deg,#0284c7,#0ea5e9)', color:'#fff', fontSize:14, fontWeight:700, cursor: saving ? 'not-allowed' : 'pointer', display:'flex', alignItems:'center', justifyContent:'center', gap:8, boxShadow:'0 4px 16px rgba(14,165,233,0.35)', fontFamily:'Inter,sans-serif' }}>
                  {saving
                    ? <div style={{ width:16, height:16, border:'2px solid rgba(255,255,255,0.3)', borderTopColor:'#fff', borderRadius:'50%', animation:'spin 0.7s linear infinite' }}/>
                    : 'Update Password'
                  }
                </button>

                <button type="button" onClick={() => navigate('/login')}
                  style={{ fontSize:12, fontWeight:600, color:'#94a3b8', background:'none', border:'none', cursor:'pointer', textAlign:'center', padding:0 }}>
                  Back to sign in
                </button>
              </form>
            </>
          )}
        </div>
      </div>

      <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
    </div>
  )
}
