import { useMemo } from 'react'
import { useApp } from '../context/AppContext'
import { AreaChart, Area, BarChart, Bar, Cell, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie } from 'recharts'
import { TrendingUp, Users, DollarSign, CalendarCheck, Target, Activity, ArrowUp, ArrowDown } from 'lucide-react'

const fmt  = n => new Intl.NumberFormat('en-AU',{style:'currency',currency:'AUD',maximumFractionDigits:0}).format(n)
const fmtK = n => n >= 1000 ? `$${(n/1000).toFixed(0)}k` : `$${n}`

// ── Real data helpers ──────────────────────────────────────────────────────────
function buildMonthlyLeads(leads) {
  const now = new Date()
  return Array.from({ length: 6 }, (_, i) => {
    const monthsAgo = 5 - i
    const d     = new Date(now.getFullYear(), now.getMonth() - monthsAgo, 1)
    const start = new Date(d.getFullYear(), d.getMonth(), 1)
    const end   = new Date(d.getFullYear(), d.getMonth() + 1, 0, 23, 59, 59)
    const slice = leads.filter(l => { const ld = new Date(l.dateSubmitted); return ld >= start && ld <= end })
    const rev   = slice.filter(l => l.paymentStatus === 'Paid').reduce((s, l) => s + (l.jobValue || 0), 0)
    const won   = slice.filter(l => l.status === 'Won (Booked)' || l.status === 'Completed').length
    const m     = d.toLocaleDateString('en-AU', { month: 'short' })
    return { m, leads: slice.length, won, rev }
  })
}

function buildWeeklyRevenue(leads) {
  const now = new Date()
  return Array.from({ length: 8 }, (_, i) => {
    const weeksAgo = 7 - i
    const end   = new Date(now); end.setDate(now.getDate() - weeksAgo * 7)
    const start = new Date(end); start.setDate(end.getDate() - 7)
    const slice = leads.filter(l => { const d = new Date(l.dateSubmitted); return d >= start && d < end })
    const rev   = slice.reduce((s, l) => s + (l.jobValue || 0), 0)
    const col   = slice.filter(l => l.paymentStatus === 'Paid').reduce((s, l) => s + (l.jobValue || 0), 0)
    return { w: `W${i + 1}`, rev, col }
  })
}

function buildStatusBreakdown(leads) {
  const statuses = ['New Lead','Contacted','Qualified','Quoted','Won (Booked)','Completed']
  const colors   = ['#0ea5e9','#f59e0b','#8b5cf6','#f97316','#10b981','#059669']
  const total    = leads.length || 1
  return statuses.map((s, i) => {
    const count = leads.filter(l => l.status === s).length
    return { name: s, value: count, pct: Math.round(count / total * 100), color: colors[i] }
  }).filter(s => s.value > 0)
}

function getPctChange(leads, days = 30) {
  const now     = new Date()
  const cutThis = new Date(now); cutThis.setDate(now.getDate() - days)
  const cutPrev = new Date(now); cutPrev.setDate(now.getDate() - days * 2)
  const thisP   = leads.filter(l => new Date(l.dateSubmitted) >= cutThis).length
  const prevP   = leads.filter(l => { const d = new Date(l.dateSubmitted); return d >= cutPrev && d < cutThis }).length
  if (prevP === 0) return thisP > 0 ? 100 : 0
  return Math.round(((thisP - prevP) / prevP) * 100)
}

function getRevPctChange(leads, days = 30) {
  const now     = new Date()
  const cutThis = new Date(now); cutThis.setDate(now.getDate() - days)
  const cutPrev = new Date(now); cutPrev.setDate(now.getDate() - days * 2)
  const thisV   = leads.filter(l => new Date(l.dateSubmitted) >= cutThis && l.paymentStatus === 'Paid').reduce((s,l)=>s+(l.jobValue||0),0)
  const prevV   = leads.filter(l => { const d = new Date(l.dateSubmitted); return d >= cutPrev && d < cutThis && l.paymentStatus === 'Paid' }).reduce((s,l)=>s+(l.jobValue||0),0)
  if (prevV === 0) return thisV > 0 ? 100 : 0
  return Math.round(((thisV - prevV) / prevV) * 100)
}

// ── Tooltip ────────────────────────────────────────────────────────────────────
const DarkTip = ({ active, payload, label }) => {
  if (!active || !payload?.length) return null
  return (
    <div style={{ background:'#0c1628', border:'1px solid rgba(255,255,255,0.1)', borderRadius:12, padding:'10px 14px', boxShadow:'0 8px 32px rgba(0,0,0,0.35)' }}>
      <p style={{ color:'rgba(255,255,255,0.45)', fontSize:11, marginBottom:6 }}>{label}</p>
      {payload.map((p,i) => (
        <p key={i} style={{ color:p.color, fontSize:12, fontWeight:600 }}>{p.name}: {typeof p.value === 'number' && p.value > 100 ? fmt(p.value) : p.value}</p>
      ))}
    </div>
  )
}

function PctBadge({ pct }) {
  const up = pct >= 0
  return (
    <span style={{ display:'inline-flex', alignItems:'center', gap:3, fontSize:11, fontWeight:700, color: up ? '#059669' : '#dc2626' }}>
      {up ? <ArrowUp size={10}/> : <ArrowDown size={10}/>} {Math.abs(pct)}%
    </span>
  )
}

export default function Analytics() {
  const { getLeads, getMetrics, getBookings } = useApp()
  const leads  = getLeads()
  const bkgs   = getBookings()
  const m      = getMetrics()

  const monthlyLeads   = useMemo(() => buildMonthlyLeads(leads),   [leads])
  const weeklyRevenue  = useMemo(() => buildWeeklyRevenue(leads),  [leads])
  const statusBreakdown = useMemo(() => buildStatusBreakdown(leads), [leads])
  const leadPctChange  = useMemo(() => getPctChange(leads, 30),    [leads])
  const revPctChange   = useMemo(() => getRevPctChange(leads, 30), [leads])

  const thisMonthLeads = useMemo(() => {
    const now   = new Date()
    const start = new Date(now.getFullYear(), now.getMonth(), 1)
    return leads.filter(l => new Date(l.dateSubmitted) >= start).length
  }, [leads])

  const avgLeadsPerMonth = useMemo(() => {
    const total = monthlyLeads.reduce((s, d) => s + d.leads, 0)
    const nonEmpty = monthlyLeads.filter(d => d.leads > 0).length
    return nonEmpty ? Math.round(total / nonEmpty) : 0
  }, [monthlyLeads])

  const topStats = [
    { icon:Users,        label:'Total Leads',      value: m.totalLeads,              sub: leadPctChange, accent:'#0ea5e9', bg:'rgba(14,165,233,0.1)' },
    { icon:TrendingUp,   label:'Conversion Rate',  value: `${m.conversionRate}%`,    sub: null,          accent:'#10b981', bg:'rgba(16,185,129,0.1)' },
    { icon:DollarSign,   label:'Revenue Generated',value: fmt(m.revenueGenerated),   sub: revPctChange,  accent:'#8b5cf6', bg:'rgba(139,92,246,0.1)' },
    { icon:CalendarCheck,label:'Completed Jobs',   value: m.completedJobs,           sub: null,          accent:'#f59e0b', bg:'rgba(245,158,11,0.1)' },
  ]

  return (
    <div style={{ padding:28, minHeight:'100%' }}>
      <div style={{ marginBottom:24 }}>
        <h1 style={{ fontSize:20, fontWeight:800, color:'#0f172a', letterSpacing:'-0.3px' }}>Analytics</h1>
        <p style={{ fontSize:13, color:'#94a3b8', marginTop:3 }}>Live performance metrics from your CRM data</p>
      </div>

      {/* Top stats */}
      <div style={{ display:'grid', gridTemplateColumns:'repeat(4,1fr)', gap:12, marginBottom:22 }}>
        {topStats.map(({ icon:Icon, label, value, sub, accent, bg }) => (
          <div key={label} style={{ background:'#fff', border:'1px solid #eaecf0', borderRadius:14, padding:'16px 18px', boxShadow:'0 1px 3px rgba(0,0,0,0.05)' }}>
            <div style={{ width:36, height:36, borderRadius:10, background:bg, display:'flex', alignItems:'center', justifyContent:'center', marginBottom:12 }}>
              <Icon size={17} color={accent}/>
            </div>
            <p style={{ fontSize:22, fontWeight:800, color:'#0f172a', letterSpacing:'-0.4px', lineHeight:1 }}>{value}</p>
            <p style={{ fontSize:12, color:'#64748b', marginTop:3 }}>{label}</p>
            {sub !== null && (
              <div style={{ marginTop:5 }}>
                {sub !== undefined ? <PctBadge pct={sub}/> : null}
                <span style={{ fontSize:11, color:'#94a3b8', marginLeft:4 }}>vs last 30d</span>
              </div>
            )}
          </div>
        ))}
      </div>

      {/* Monthly leads chart + status breakdown pie */}
      <div style={{ display:'grid', gridTemplateColumns:'1fr 300px', gap:18, marginBottom:22 }}>
        <div style={{ background:'#fff', border:'1px solid #eaecf0', borderRadius:16, padding:'22px 24px', boxShadow:'0 1px 3px rgba(0,0,0,0.05)' }}>
          <div style={{ display:'flex', alignItems:'flex-start', justifyContent:'space-between', marginBottom:20 }}>
            <div>
              <p style={{ fontWeight:700, color:'#0f172a', fontSize:14 }}>Monthly Lead Volume</p>
              <p style={{ fontSize:12, color:'#94a3b8', marginTop:2 }}>New leads received per month — last 6 months</p>
            </div>
            <div style={{ display:'flex', gap:14 }}>
              {[['#0ea5e9','Leads'],['#10b981','Won']].map(([c,l]) => (
                <div key={l} style={{ display:'flex', alignItems:'center', gap:5 }}>
                  <span style={{ width:8, height:8, borderRadius:'50%', background:c, display:'inline-block' }}/>
                  <span style={{ fontSize:11, color:'#64748b', fontWeight:500 }}>{l}</span>
                </div>
              ))}
            </div>
          </div>
          <ResponsiveContainer width="100%" height={200}>
            <BarChart data={monthlyLeads} margin={{ top:4, right:4, left:-20, bottom:0 }} barSize={20} barGap={4}>
              <CartesianGrid strokeDasharray="5 5" stroke="#f1f5f9" vertical={false}/>
              <XAxis dataKey="m" tick={{ fontSize:11, fill:'#94a3b8' }} axisLine={false} tickLine={false}/>
              <YAxis tick={{ fontSize:11, fill:'#94a3b8' }} axisLine={false} tickLine={false} width={28} allowDecimals={false}/>
              <Tooltip content={<DarkTip/>}/>
              <Bar dataKey="leads" name="Leads" fill="#bae6fd" radius={[4,4,0,0]}/>
              <Bar dataKey="won"   name="Won"   fill="#10b981" radius={[4,4,0,0]}/>
            </BarChart>
          </ResponsiveContainer>
        </div>

        <div style={{ background:'#fff', border:'1px solid #eaecf0', borderRadius:16, padding:'22px 20px', boxShadow:'0 1px 3px rgba(0,0,0,0.05)' }}>
          <p style={{ fontWeight:700, color:'#0f172a', fontSize:14, marginBottom:4 }}>Pipeline Status</p>
          <p style={{ fontSize:12, color:'#94a3b8', marginBottom:12 }}>Lead distribution by stage</p>
          {statusBreakdown.length > 0 ? (
            <>
              <ResponsiveContainer width="100%" height={140}>
                <PieChart>
                  <Pie data={statusBreakdown} cx="50%" cy="50%" innerRadius={40} outerRadius={65} paddingAngle={3} dataKey="value">
                    {statusBreakdown.map((e,i) => <Cell key={i} fill={e.color}/>)}
                  </Pie>
                  <Tooltip formatter={(v, n) => [`${v} leads`, n]}/>
                </PieChart>
              </ResponsiveContainer>
              <div style={{ display:'flex', flexDirection:'column', gap:5, marginTop:8 }}>
                {statusBreakdown.map(item => (
                  <div key={item.name} style={{ display:'flex', alignItems:'center', justifyContent:'space-between' }}>
                    <div style={{ display:'flex', alignItems:'center', gap:7 }}>
                      <span style={{ width:8, height:8, borderRadius:'50%', background:item.color, display:'inline-block', flexShrink:0 }}/>
                      <span style={{ fontSize:11, color:'#475569' }}>{item.name}</span>
                    </div>
                    <span style={{ fontSize:11, fontWeight:700, color:'#0f172a' }}>{item.value} ({item.pct}%)</span>
                  </div>
                ))}
              </div>
            </>
          ) : (
            <p style={{ textAlign:'center', color:'#94a3b8', fontSize:13, padding:'32px 0' }}>No leads yet</p>
          )}
        </div>
      </div>

      {/* Weekly revenue trend */}
      <div style={{ background:'#fff', border:'1px solid #eaecf0', borderRadius:16, padding:'22px 24px', boxShadow:'0 1px 3px rgba(0,0,0,0.05)', marginBottom:22 }}>
        <div style={{ display:'flex', alignItems:'flex-start', justifyContent:'space-between', marginBottom:20 }}>
          <div>
            <p style={{ fontWeight:700, color:'#0f172a', fontSize:14 }}>Weekly Revenue Trend</p>
            <p style={{ fontSize:12, color:'#94a3b8', marginTop:2 }}>Revenue generated vs cash collected — last 8 weeks</p>
          </div>
          <div style={{ display:'flex', gap:14 }}>
            {[['#0ea5e9','Generated'],['#10b981','Collected']].map(([c,l]) => (
              <div key={l} style={{ display:'flex', alignItems:'center', gap:5 }}>
                <span style={{ width:8, height:8, borderRadius:'50%', background:c, display:'inline-block' }}/>
                <span style={{ fontSize:11, color:'#64748b', fontWeight:500 }}>{l}</span>
              </div>
            ))}
          </div>
        </div>
        <ResponsiveContainer width="100%" height={200}>
          <AreaChart data={weeklyRevenue} margin={{ top:4, right:4, left:-10, bottom:0 }}>
            <defs>
              <linearGradient id="gRev2" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%"   stopColor="#2563eb" stopOpacity={0.15}/>
                <stop offset="100%" stopColor="#2563eb" stopOpacity={0}/>
              </linearGradient>
              <linearGradient id="gCol2" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%"   stopColor="#10b981" stopOpacity={0.15}/>
                <stop offset="100%" stopColor="#10b981" stopOpacity={0}/>
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="5 5" stroke="#f1f5f9" vertical={false}/>
            <XAxis dataKey="w"  tick={{ fontSize:11, fill:'#94a3b8' }} axisLine={false} tickLine={false}/>
            <YAxis tickFormatter={fmtK} tick={{ fontSize:11, fill:'#94a3b8' }} axisLine={false} tickLine={false} width={42}/>
            <Tooltip content={<DarkTip/>} cursor={{ stroke:'#e2e8f0', strokeWidth:1, strokeDasharray:'4 4' }}/>
            <Area type="monotone" dataKey="rev" name="Generated" stroke="#2563eb" strokeWidth={2.5} fill="url(#gRev2)" dot={false} activeDot={{ r:5, fill:'#0ea5e9', stroke:'#fff', strokeWidth:2 }}/>
            <Area type="monotone" dataKey="col" name="Collected"  stroke="#10b981" strokeWidth={2.5} fill="url(#gCol2)" dot={false} activeDot={{ r:5, fill:'#10b981', stroke:'#fff', strokeWidth:2 }}/>
          </AreaChart>
        </ResponsiveContainer>
      </div>

      {/* Summary stats table */}
      <div style={{ background:'#fff', border:'1px solid #eaecf0', borderRadius:16, boxShadow:'0 1px 3px rgba(0,0,0,0.05)', overflow:'hidden' }}>
        <div style={{ padding:'18px 22px 14px', borderBottom:'1px solid #f1f5f9' }}>
          <p style={{ fontWeight:700, color:'#0f172a', fontSize:14 }}>Performance Summary</p>
          <p style={{ fontSize:12, color:'#94a3b8', marginTop:2 }}>Key metrics at a glance</p>
        </div>
        <div style={{ display:'grid', gridTemplateColumns:'repeat(3,1fr)', gap:0 }}>
          {[
            { label:'Total Leads',          value: m.totalLeads,                  sub:'All time' },
            { label:'This Month',           value: thisMonthLeads,                sub:'New leads' },
            { label:'Avg Leads / Month',    value: avgLeadsPerMonth,              sub:'Last 6 months' },
            { label:'Revenue Generated',    value: fmt(m.revenueGenerated),       sub:'Completed jobs' },
            { label:'Cash Collected',       value: fmt(m.cashCollected),          sub:'Paid invoices' },
            { label:'Outstanding',          value: fmt(m.outstanding),            sub:'Awaiting payment' },
            { label:'Avg Job Value',        value: fmt(m.avgJobValue),            sub:'Per completed job' },
            { label:'Jobs Completed',       value: m.completedJobs,              sub:'All time' },
            { label:'Upcoming Bookings',    value: bkgs.filter(b => new Date(b.date+'T00:00:00') >= new Date(new Date().toDateString())).length, sub:'Scheduled' },
          ].map(({ label, value, sub }, i) => (
            <div key={label} style={{ padding:'16px 22px', borderRight: (i+1) % 3 !== 0 ? '1px solid #f1f5f9' : 'none', borderBottom: i < 6 ? '1px solid #f1f5f9' : 'none' }}>
              <p style={{ fontSize:18, fontWeight:800, color:'#0f172a', letterSpacing:'-0.3px' }}>{value}</p>
              <p style={{ fontSize:12, color:'#64748b', marginTop:2 }}>{label}</p>
              <p style={{ fontSize:11, color:'#94a3b8', marginTop:1 }}>{sub}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
