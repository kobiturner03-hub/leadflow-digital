import { useState } from 'react'
import { createPortal } from 'react-dom'
import { useApp } from '../context/AppContext'
import { Plus, ChevronLeft, ChevronRight, Trash2, X, Clock, CalendarDays } from 'lucide-react'
import { format, startOfMonth, endOfMonth, eachDayOfInterval, startOfWeek, endOfWeek,
         isSameMonth, isSameDay, isToday, addMonths, subMonths, parseISO } from 'date-fns'

const HOURS = ['08:00','09:00','10:00','10:30','11:00','12:00','13:00','14:00','14:30','15:00','16:00','17:00']
const SERVICES = ['Plumbing','Electrical','Landscaping','Carpentry','Painting','Cleaning','Tiling','Roofing','HVAC','Pest Control','Other']

const inputStyle = { width:'100%', padding:'10px 13px', borderRadius:10, border:'1.5px solid #e2e8f0', fontSize:14, outline:'none', fontFamily:'inherit', color:'#0f172a', background:'#fff', boxSizing:'border-box' }
const labelStyle = { display:'block', fontSize:12, fontWeight:700, color:'#374151', marginBottom:6, letterSpacing:'0.02em' }

function Modal({ title, onClose, children }) {
  return createPortal(
    <div style={{ position:'fixed', top:0, left:0, width:'100vw', height:'100vh', zIndex:9999, display:'flex', alignItems:'center', justifyContent:'center', padding:'20px', background:'rgba(15,23,42,0.6)', backdropFilter:'blur(6px)' }}>
      <div style={{
        background:'#fff', borderRadius:20,
        boxShadow:'0 32px 96px rgba(0,0,0,0.28)',
        width:'100%', maxWidth:560,
        maxHeight:'calc(100vh - 40px)',
        display:'flex', flexDirection:'column',
        overflow:'hidden',
      }}>
        <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', padding:'20px 28px', borderBottom:'1px solid #f1f5f9', flexShrink:0 }}>
          <p style={{ fontWeight:800, color:'#0f172a', fontSize:16, letterSpacing:'-0.2px' }}>{title}</p>
          <button onClick={onClose} style={{ background:'#f1f5f9', border:'none', borderRadius:9, width:32, height:32, display:'flex', alignItems:'center', justifyContent:'center', cursor:'pointer', color:'#64748b' }}><X size={15} /></button>
        </div>
        <div style={{ padding:'24px 28px 28px', overflowY:'auto', flex:1 }}>{children}</div>
      </div>
    </div>,
    document.body
  )
}

export default function Bookings() {
  const { getBookings, addBooking, deleteBooking } = useApp()
  const bookings = getBookings()
  const [month, setMonth] = useState(new Date())
  const [selected, setSelected] = useState(null)
  const [showAdd, setShowAdd] = useState(false)
  const [form, setForm] = useState({ customerName:'', phone:'', service:'', date:'', time:'09:00' })

  const s = (k,v) => setForm(p => ({...p,[k]:v}))

  const days = eachDayOfInterval({
    start: startOfWeek(startOfMonth(month), { weekStartsOn:1 }),
    end:   endOfWeek(endOfMonth(month),   { weekStartsOn:1 }),
  })

  const booksForDay = d => bookings.filter(b => isSameDay(parseISO(b.date), d))
  const upcoming = bookings.filter(b => new Date(b.date) >= new Date()).sort((a,b) => new Date(a.date)-new Date(b.date))

  const handleAdd = e => {
    e.preventDefault()
    addBooking(form)
    setForm({ customerName:'', phone:'', service:'', date:'', time:'09:00' })
    setShowAdd(false)
  }

  return (
    <div style={{ padding:28, minHeight:'100%' }}>
      {/* Header */}
      <div style={{ display:'flex', alignItems:'flex-start', justifyContent:'space-between', marginBottom:24 }}>
        <div>
          <h1 style={{ fontSize:20, fontWeight:800, color:'#0f172a', letterSpacing:'-0.3px' }}>Bookings</h1>
          <p style={{ fontSize:13, color:'#94a3b8', marginTop:3 }}>{upcoming.length} upcoming appointments</p>
        </div>
        <button onClick={() => setShowAdd(true)} style={{ display:'flex', alignItems:'center', gap:7, background:'#0ea5e9', color:'#fff', border:'none', borderRadius:11, padding:'9px 16px', fontSize:13, fontWeight:700, cursor:'pointer', boxShadow:'0 4px 12px rgba(14,165,233,0.3)' }}>
          <Plus size={15}/> New Booking
        </button>
      </div>

      <div style={{ display:'grid', gridTemplateColumns:'1fr 340px', gap:20 }}>

        {/* ── Calendar ───────────────────────────── */}
        <div style={{ background:'#fff', borderRadius:16, border:'1px solid #eaecf0', boxShadow:'0 1px 3px rgba(0,0,0,0.06)', overflow:'hidden' }}>
          {/* Month nav */}
          <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', padding:'18px 22px', borderBottom:'1px solid #f1f5f9' }}>
            <button onClick={() => setMonth(subMonths(month,1))}
              style={{ width:32, height:32, borderRadius:8, border:'1px solid #e2e8f0', background:'#fff', display:'flex', alignItems:'center', justifyContent:'center', cursor:'pointer', color:'#64748b' }}>
              <ChevronLeft size={15}/>
            </button>
            <p style={{ fontWeight:700, color:'#0f172a', fontSize:15 }}>{format(month,'MMMM yyyy')}</p>
            <button onClick={() => setMonth(addMonths(month,1))}
              style={{ width:32, height:32, borderRadius:8, border:'1px solid #e2e8f0', background:'#fff', display:'flex', alignItems:'center', justifyContent:'center', cursor:'pointer', color:'#64748b' }}>
              <ChevronRight size={15}/>
            </button>
          </div>

          <div style={{ padding:'16px 18px' }}>
            {/* Day labels */}
            <div style={{ display:'grid', gridTemplateColumns:'repeat(7,1fr)', marginBottom:8 }}>
              {['Mon','Tue','Wed','Thu','Fri','Sat','Sun'].map(d => (
                <div key={d} style={{ textAlign:'center', fontSize:11, fontWeight:700, color:'#94a3b8', padding:'4px 0' }}>{d}</div>
              ))}
            </div>
            {/* Day grid */}
            <div style={{ display:'grid', gridTemplateColumns:'repeat(7,1fr)', gap:3 }}>
              {days.map(day => {
                const dayBooks = booksForDay(day)
                const inMonth  = isSameMonth(day, month)
                const isSelDay = selected && isSameDay(day, selected)
                const todayDay = isToday(day)
                return (
                  <button
                    key={day.toISOString()}
                    onClick={() => setSelected(day)}
                    style={{
                      aspectRatio:'1', display:'flex', flexDirection:'column', alignItems:'center', justifyContent:'center',
                      borderRadius:10, border:'none', cursor:'pointer', position:'relative',
                      background: isSelDay ? '#0ea5e9' : todayDay ? '#f0f9ff' : 'transparent',
                      opacity: inMonth ? 1 : 0.3,
                      transition:'background 0.12s',
                    }}
                  >
                    <span style={{ fontSize:13, fontWeight: todayDay || isSelDay ? 700 : 500, color: isSelDay ? '#fff' : todayDay ? '#0ea5e9' : '#374151', lineHeight:1 }}>
                      {format(day,'d')}
                    </span>
                    {dayBooks.length > 0 && (
                      <span style={{ width:5, height:5, borderRadius:'50%', background: isSelDay ? 'rgba(255,255,255,0.8)' : '#0ea5e9', marginTop:3, display:'block' }} />
                    )}
                  </button>
                )
              })}
            </div>
          </div>

          {/* Selected day bookings */}
          {selected && (
            <div style={{ borderTop:'1px solid #f1f5f9', padding:'16px 22px' }}>
              <p style={{ fontSize:13, fontWeight:700, color:'#0f172a', marginBottom:12 }}>
                {format(selected,'EEEE, d MMMM yyyy')}
              </p>
              {booksForDay(selected).length === 0 ? (
                <p style={{ fontSize:12, color:'#94a3b8' }}>No bookings on this day</p>
              ) : booksForDay(selected).map(b => (
                <div key={b.id} style={{ display:'flex', alignItems:'center', justifyContent:'space-between', background:'#f8fafc', borderRadius:10, padding:'10px 14px', marginBottom:8 }}>
                  <div>
                    <p style={{ fontSize:13, fontWeight:600, color:'#0f172a' }}>{b.customerName}</p>
                    <p style={{ fontSize:11, color:'#94a3b8', marginTop:2 }}>{b.service} · {b.time}</p>
                  </div>
                  <button onClick={() => deleteBooking(b.id)}
                    style={{ width:28, height:28, borderRadius:8, border:'none', background:'#fee2e2', color:'#dc2626', display:'flex', alignItems:'center', justifyContent:'center', cursor:'pointer' }}>
                    <Trash2 size={13}/>
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* ── Upcoming list ──────────────────────── */}
        <div style={{ background:'#fff', borderRadius:16, border:'1px solid #eaecf0', boxShadow:'0 1px 3px rgba(0,0,0,0.06)', overflow:'hidden', display:'flex', flexDirection:'column' }}>
          <div style={{ padding:'18px 20px 14px', borderBottom:'1px solid #f1f5f9' }}>
            <p style={{ fontWeight:700, color:'#0f172a', fontSize:14 }}>Upcoming</p>
            <p style={{ fontSize:12, color:'#94a3b8', marginTop:1 }}>{upcoming.length} scheduled</p>
          </div>
          <div style={{ flex:1, overflowY:'auto', scrollbarWidth:'thin', scrollbarColor:'#e2e8f0 transparent' }}>
            {upcoming.length === 0 ? (
              <p style={{ textAlign:'center', padding:32, color:'#94a3b8', fontSize:13 }}>No upcoming bookings</p>
            ) : upcoming.map(b => {
              const d = new Date(b.date)
              return (
                <div key={b.id} style={{ display:'flex', alignItems:'center', gap:12, padding:'12px 20px', borderBottom:'1px solid #f8fafc' }}
                  onMouseEnter={e=>e.currentTarget.style.background='#fafbfc'}
                  onMouseLeave={e=>e.currentTarget.style.background='transparent'}>
                  <div style={{ width:42, height:42, borderRadius:11, background:'#0284c7', display:'flex', flexDirection:'column', alignItems:'center', justifyContent:'center', flexShrink:0, boxShadow:'0 4px 10px rgba(29,78,216,0.28)' }}>
                    <span style={{ color:'rgba(255,255,255,0.65)', fontSize:8, fontWeight:700, letterSpacing:'0.06em', textTransform:'uppercase' }}>
                      {d.toLocaleDateString('en-AU',{month:'short'})}
                    </span>
                    <span style={{ color:'#fff', fontSize:16, fontWeight:800, lineHeight:1.1 }}>{d.getDate()}</span>
                  </div>
                  <div style={{ flex:1, minWidth:0 }}>
                    <p style={{ fontSize:13, fontWeight:600, color:'#0f172a', overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap' }}>{b.customerName}</p>
                    <p style={{ fontSize:11, color:'#94a3b8', marginTop:2 }}>{b.service}</p>
                    <div style={{ display:'flex', alignItems:'center', gap:4, marginTop:4 }}>
                      <Clock size={10} color="#94a3b8" />
                      <span style={{ fontSize:11, color:'#64748b', fontWeight:600 }}>{b.time}</span>
                    </div>
                  </div>
                  <button onClick={() => deleteBooking(b.id)}
                    style={{ width:26, height:26, borderRadius:7, border:'1px solid #fee2e2', background:'#fff', color:'#fca5a5', display:'flex', alignItems:'center', justifyContent:'center', cursor:'pointer', flexShrink:0 }}
                    onMouseEnter={e=>{ e.currentTarget.style.background='#fee2e2'; e.currentTarget.style.color='#dc2626' }}
                    onMouseLeave={e=>{ e.currentTarget.style.background='#fff'; e.currentTarget.style.color='#fca5a5' }}>
                    <Trash2 size={11}/>
                  </button>
                </div>
              )
            })}
          </div>
        </div>
      </div>

      {showAdd && (
        <Modal title="New Booking" onClose={() => setShowAdd(false)}>
          <form onSubmit={handleAdd} style={{ display:'flex', flexDirection:'column', gap:0 }}>

            {/* Customer */}
            <p style={{ fontSize:11, fontWeight:700, color:'#94a3b8', textTransform:'uppercase', letterSpacing:'0.08em', marginBottom:10 }}>Customer</p>
            <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:14, marginBottom:18 }}>
              <div>
                <label style={labelStyle}>Full Name <span style={{ color:'#ef4444' }}>*</span></label>
                <input required value={form.customerName} onChange={e=>s('customerName',e.target.value)} style={inputStyle} placeholder="e.g. Jane Smith" />
              </div>
              <div>
                <label style={labelStyle}>Phone <span style={{ color:'#ef4444' }}>*</span></label>
                <input required value={form.phone} onChange={e=>s('phone',e.target.value)} style={inputStyle} placeholder="e.g. 0400 000 000" />
              </div>
            </div>

            {/* Service */}
            <p style={{ fontSize:11, fontWeight:700, color:'#94a3b8', textTransform:'uppercase', letterSpacing:'0.08em', marginBottom:10 }}>Service</p>
            <div style={{ marginBottom:18 }}>
              <label style={labelStyle}>Service Type</label>
              <select value={form.service} onChange={e=>s('service',e.target.value)} style={{ ...inputStyle, cursor:'pointer', appearance:'auto' }}>
                <option value="">Select a service…</option>
                {SERVICES.map(sv => <option key={sv}>{sv}</option>)}
              </select>
            </div>

            {/* Date & Time */}
            <p style={{ fontSize:11, fontWeight:700, color:'#94a3b8', textTransform:'uppercase', letterSpacing:'0.08em', marginBottom:10 }}>Schedule</p>
            <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:14, marginBottom:24 }}>
              <div>
                <label style={labelStyle}>Date <span style={{ color:'#ef4444' }}>*</span></label>
                <input required type="date" value={form.date} onChange={e=>s('date',e.target.value)} style={inputStyle} />
              </div>
              <div>
                <label style={labelStyle}>Time</label>
                <select value={form.time} onChange={e=>s('time',e.target.value)} style={{ ...inputStyle, cursor:'pointer', appearance:'auto' }}>
                  {HOURS.map(h => <option key={h}>{h}</option>)}
                </select>
              </div>
            </div>

            <div style={{ display:'flex', gap:10, paddingTop:4, borderTop:'1px solid #f1f5f9' }}>
              <button type="button" onClick={() => setShowAdd(false)} style={{ flex:1, padding:'11px', borderRadius:11, border:'1.5px solid #e2e8f0', background:'#fff', fontSize:13, fontWeight:700, color:'#64748b', cursor:'pointer' }}>Cancel</button>
              <button type="submit" style={{ flex:2, padding:'11px', borderRadius:11, border:'none', background:'linear-gradient(135deg,#0ea5e9,#0284c7)', fontSize:14, fontWeight:800, color:'#fff', cursor:'pointer', boxShadow:'0 4px 14px rgba(14,165,233,0.35)' }}>
                <span style={{ display:'flex', alignItems:'center', justifyContent:'center', gap:7 }}><CalendarDays size={15}/>Book Appointment</span>
              </button>
            </div>
          </form>
        </Modal>
      )}
    </div>
  )
}
