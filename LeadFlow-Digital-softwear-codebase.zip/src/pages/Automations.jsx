import { useState } from 'react'
import { useApp } from '../context/AppContext'
import { Mail, MessageSquare, Edit2, Save, X, Zap, Bell, Phone, Key, Settings } from 'lucide-react'

const TRIGGER_LABELS = {
  new_lead:             'New Lead Submitted',
  booking_confirmed:    'Booking Confirmed',
  follow_up:            'Follow-up Reminder',
  appointment_reminder: 'Appointment Reminder',
}

const inputStyle = { width:'100%', padding:'9px 12px', borderRadius:10, border:'1px solid #e2e8f0', fontSize:13, outline:'none', fontFamily:'inherit', color:'#0f172a', background:'#fff', boxSizing:'border-box' }
const labelStyle = { display:'block', fontSize:11, fontWeight:600, color:'#64748b', marginBottom:5, textTransform:'uppercase', letterSpacing:'0.04em' }

function Toggle({ on, onChange }) {
  return (
    <button onClick={() => onChange(!on)} style={{ width:36, height:20, borderRadius:10, border:'none', cursor:'pointer', padding:3, display:'flex', alignItems:'center', background: on ? '#0ea5e9' : '#e2e8f0', transition:'background 0.2s', flexShrink:0 }}>
      <span style={{ width:14, height:14, borderRadius:'50%', background:'#fff', display:'block', transform: on ? 'translateX(16px)' : 'translateX(0)', transition:'transform 0.2s', boxShadow:'0 1px 3px rgba(0,0,0,0.2)' }} />
    </button>
  )
}

function EmailCard({ t, onUpdate }) {
  const [editing, setEditing] = useState(false)
  const [form, setForm] = useState({...t})
  const save = () => { onUpdate(t.id, form); setEditing(false) }

  return (
    <div style={{ background:'#fff', border:'1px solid #eaecf0', borderRadius:16, padding:'18px 20px', boxShadow:'0 1px 3px rgba(0,0,0,0.05)' }}>
      <div style={{ display:'flex', alignItems:'flex-start', justifyContent:'space-between', marginBottom:14 }}>
        <div style={{ display:'flex', alignItems:'flex-start', gap:12 }}>
          <div style={{ width:36, height:36, borderRadius:10, background:'rgba(14,165,233,0.1)', display:'flex', alignItems:'center', justifyContent:'center', flexShrink:0, marginTop:1 }}>
            <Mail size={16} color="#2563eb" />
          </div>
          <div>
            <p style={{ fontSize:13, fontWeight:700, color:'#0f172a' }}>{t.name}</p>
            <span style={{ display:'inline-flex', alignItems:'center', gap:4, background:'#f8fafc', border:'1px solid #e2e8f0', borderRadius:20, padding:'2px 9px', fontSize:11, color:'#64748b', marginTop:5 }}>
              <Zap size={9} color="#94a3b8" /> {TRIGGER_LABELS[t.trigger] || t.trigger}
            </span>
          </div>
        </div>
        <div style={{ display:'flex', alignItems:'center', gap:10 }}>
          <Toggle on={t.active} onChange={v => onUpdate(t.id, {active:v})} />
          <button onClick={() => { setForm({...t}); setEditing(!editing) }}
            style={{ width:28, height:28, borderRadius:8, border:'1px solid #e2e8f0', background: editing ? '#f1f5f9' : '#fff', display:'flex', alignItems:'center', justifyContent:'center', cursor:'pointer', color:'#64748b' }}>
            {editing ? <X size={13}/> : <Edit2 size={13}/>}
          </button>
        </div>
      </div>

      {!editing ? (
        <div style={{ background:'#f8fafc', borderRadius:10, padding:'12px 14px' }}>
          <p style={{ fontSize:11, fontWeight:600, color:'#94a3b8', marginBottom:3 }}>SUBJECT</p>
          <p style={{ fontSize:13, color:'#374151', fontWeight:500, marginBottom:10 }}>{t.subject}</p>
          <p style={{ fontSize:11, fontWeight:600, color:'#94a3b8', marginBottom:3 }}>BODY</p>
          <p style={{ fontSize:12, color:'#64748b', whiteSpace:'pre-line', lineHeight:1.6 }}>{t.body}</p>
        </div>
      ) : (
        <div style={{ display:'flex', flexDirection:'column', gap:12 }}>
          <div>
            <label style={labelStyle}>Subject</label>
            <input value={form.subject} onChange={e=>setForm(p=>({...p,subject:e.target.value}))} style={inputStyle}/>
          </div>
          <div>
            <label style={labelStyle}>Body</label>
            <textarea rows={5} value={form.body} onChange={e=>setForm(p=>({...p,body:e.target.value}))} style={{ ...inputStyle, resize:'none', fontFamily:'monospace', fontSize:12, lineHeight:1.6 }}/>
            <p style={{ fontSize:11, color:'#94a3b8', marginTop:4 }}>Variables: {'{{name}}'} {'{{service}}'} {'{{date}}'} {'{{time}}'}</p>
          </div>
          <div style={{ display:'flex', gap:8 }}>
            <button onClick={() => setEditing(false)} style={{ flex:1, padding:'8px', borderRadius:9, border:'1px solid #e2e8f0', background:'#fff', fontSize:13, fontWeight:600, color:'#64748b', cursor:'pointer' }}>Cancel</button>
            <button onClick={save} style={{ flex:1, padding:'8px', borderRadius:9, border:'none', background:'#0ea5e9', fontSize:13, fontWeight:700, color:'#fff', cursor:'pointer', display:'flex', alignItems:'center', justifyContent:'center', gap:6 }}>
              <Save size={13}/> Save
            </button>
          </div>
        </div>
      )}
    </div>
  )
}

function SmsCard({ t, onUpdate }) {
  const [editing, setEditing] = useState(false)
  const [form, setForm] = useState({...t})
  const save = () => { onUpdate(t.id, form); setEditing(false) }

  return (
    <div style={{ background:'#fff', border:'1px solid #eaecf0', borderRadius:16, padding:'18px 20px', boxShadow:'0 1px 3px rgba(0,0,0,0.05)' }}>
      <div style={{ display:'flex', alignItems:'flex-start', justifyContent:'space-between', marginBottom:14 }}>
        <div style={{ display:'flex', alignItems:'flex-start', gap:12 }}>
          <div style={{ width:36, height:36, borderRadius:10, background:'rgba(16,185,129,0.1)', display:'flex', alignItems:'center', justifyContent:'center', flexShrink:0, marginTop:1 }}>
            <MessageSquare size={16} color="#10b981" />
          </div>
          <div>
            <p style={{ fontSize:13, fontWeight:700, color:'#0f172a' }}>{t.name}</p>
            <span style={{ display:'inline-flex', alignItems:'center', gap:4, background:'#f8fafc', border:'1px solid #e2e8f0', borderRadius:20, padding:'2px 9px', fontSize:11, color:'#64748b', marginTop:5 }}>
              <Zap size={9} color="#94a3b8" /> {TRIGGER_LABELS[t.trigger] || t.trigger}
            </span>
          </div>
        </div>
        <div style={{ display:'flex', alignItems:'center', gap:10 }}>
          <Toggle on={t.active} onChange={v => onUpdate(t.id, {active:v})} />
          <button onClick={() => { setForm({...t}); setEditing(!editing) }}
            style={{ width:28, height:28, borderRadius:8, border:'1px solid #e2e8f0', background: editing ? '#f1f5f9' : '#fff', display:'flex', alignItems:'center', justifyContent:'center', cursor:'pointer', color:'#64748b' }}>
            {editing ? <X size={13}/> : <Edit2 size={13}/>}
          </button>
        </div>
      </div>

      {!editing ? (
        <>
          <div style={{ background:'#f8fafc', borderRadius:10, padding:'12px 14px' }}>
            <p style={{ fontSize:12, color:'#64748b', lineHeight:1.6 }}>{t.message}</p>
          </div>
          <div style={{ display:'flex', alignItems:'center', gap:6, marginTop:10, background:'#fffbeb', border:'1px solid #fde68a', borderRadius:8, padding:'7px 12px' }}>
            <Bell size={11} color="#b45309"/>
            <p style={{ fontSize:11, color:'#92400e', fontWeight:500 }}>Simulated — configure Twilio below to send real SMS</p>
          </div>
        </>
      ) : (
        <div style={{ display:'flex', flexDirection:'column', gap:12 }}>
          <div>
            <label style={labelStyle}>Message</label>
            <textarea rows={4} value={form.message} onChange={e=>setForm(p=>({...p,message:e.target.value}))} style={{ ...inputStyle, resize:'none' }}/>
            <p style={{ fontSize:11, color:'#94a3b8', marginTop:4 }}>Variables: {'{{name}}'} {'{{phone}}'} {'{{time}}'}</p>
          </div>
          <div style={{ display:'flex', gap:8 }}>
            <button onClick={() => setEditing(false)} style={{ flex:1, padding:'8px', borderRadius:9, border:'1px solid #e2e8f0', background:'#fff', fontSize:13, fontWeight:600, color:'#64748b', cursor:'pointer' }}>Cancel</button>
            <button onClick={save} style={{ flex:1, padding:'8px', borderRadius:9, border:'none', background:'#0ea5e9', fontSize:13, fontWeight:700, color:'#fff', cursor:'pointer', display:'flex', alignItems:'center', justifyContent:'center', gap:6 }}>
              <Save size={13}/> Save
            </button>
          </div>
        </div>
      )}
    </div>
  )
}

function TwilioModal({ onClose }) {
  const [form, setForm] = useState({ accountSid:'', authToken:'', fromNumber:'' })
  const [saved, setSaved] = useState(false)

  const handleSave = (e) => {
    e.preventDefault()
    // In a real implementation this would be saved to business settings in Supabase
    setSaved(true)
    setTimeout(() => { setSaved(false); onClose() }, 1500)
  }

  return (
    <div style={{ position:'fixed', inset:0, background:'rgba(0,0,0,0.5)', display:'flex', alignItems:'center', justifyContent:'center', zIndex:1000, padding:16 }}>
      <div style={{ background:'#fff', borderRadius:20, padding:'28px 28px 24px', width:'100%', maxWidth:440, boxShadow:'0 24px 80px rgba(0,0,0,0.25)' }}>
        <div style={{ display:'flex', alignItems:'flex-start', justifyContent:'space-between', marginBottom:20 }}>
          <div style={{ display:'flex', alignItems:'center', gap:12 }}>
            <div style={{ width:40, height:40, borderRadius:12, background:'linear-gradient(135deg,#0c1628,#0e2044)', display:'flex', alignItems:'center', justifyContent:'center' }}>
              <Phone size={18} color="#fff"/>
            </div>
            <div>
              <h2 style={{ fontSize:16, fontWeight:800, color:'#0f172a', letterSpacing:'-0.2px' }}>Twilio Configuration</h2>
              <p style={{ fontSize:12, color:'#94a3b8', marginTop:1 }}>Connect to send real SMS messages</p>
            </div>
          </div>
          <button onClick={onClose} style={{ width:30, height:30, borderRadius:8, border:'1px solid #e2e8f0', background:'#fff', display:'flex', alignItems:'center', justifyContent:'center', cursor:'pointer', color:'#64748b' }}>
            <X size={14}/>
          </button>
        </div>

        <div style={{ background:'#f0f9ff', border:'1px solid #bae6fd', borderRadius:10, padding:'10px 14px', marginBottom:20 }}>
          <p style={{ fontSize:12, color:'#0284c7', lineHeight:1.5 }}>
            Get your credentials from <strong>console.twilio.com</strong> → Account Info. You'll also need a Twilio phone number to send from.
          </p>
        </div>

        <form onSubmit={handleSave} style={{ display:'flex', flexDirection:'column', gap:14 }}>
          <div>
            <label style={labelStyle}>Account SID</label>
            <div style={{ position:'relative' }}>
              <Key size={13} style={{ position:'absolute', left:12, top:'50%', transform:'translateY(-50%)', color:'#94a3b8' }}/>
              <input value={form.accountSid} onChange={e=>setForm(p=>({...p,accountSid:e.target.value}))}
                placeholder="ACxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx" required
                style={{ ...inputStyle, paddingLeft:34 }}
                onFocus={e=>e.target.style.borderColor='#0ea5e9'} onBlur={e=>e.target.style.borderColor='#e2e8f0'}/>
            </div>
          </div>
          <div>
            <label style={labelStyle}>Auth Token</label>
            <div style={{ position:'relative' }}>
              <Key size={13} style={{ position:'absolute', left:12, top:'50%', transform:'translateY(-50%)', color:'#94a3b8' }}/>
              <input type="password" value={form.authToken} onChange={e=>setForm(p=>({...p,authToken:e.target.value}))}
                placeholder="••••••••••••••••••••••••••••••••" required
                style={{ ...inputStyle, paddingLeft:34 }}
                onFocus={e=>e.target.style.borderColor='#0ea5e9'} onBlur={e=>e.target.style.borderColor='#e2e8f0'}/>
            </div>
          </div>
          <div>
            <label style={labelStyle}>From Phone Number</label>
            <div style={{ position:'relative' }}>
              <Phone size={13} style={{ position:'absolute', left:12, top:'50%', transform:'translateY(-50%)', color:'#94a3b8' }}/>
              <input value={form.fromNumber} onChange={e=>setForm(p=>({...p,fromNumber:e.target.value}))}
                placeholder="+61400000000" required
                style={{ ...inputStyle, paddingLeft:34 }}
                onFocus={e=>e.target.style.borderColor='#0ea5e9'} onBlur={e=>e.target.style.borderColor='#e2e8f0'}/>
            </div>
          </div>
          <div style={{ display:'flex', gap:8, marginTop:4 }}>
            <button type="button" onClick={onClose} style={{ flex:1, padding:'10px', borderRadius:10, border:'1px solid #e2e8f0', background:'#fff', fontSize:13, fontWeight:600, color:'#64748b', cursor:'pointer' }}>
              Cancel
            </button>
            <button type="submit" style={{ flex:2, padding:'10px', borderRadius:10, border:'none', background: saved ? '#10b981' : 'linear-gradient(135deg,#0284c7,#0ea5e9)', color:'#fff', fontSize:13, fontWeight:700, cursor:'pointer', display:'flex', alignItems:'center', justifyContent:'center', gap:7, transition:'background 0.2s' }}>
              {saved ? '✓ Saved!' : <><Settings size={13}/> Save Configuration</>}
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}

export default function Automations() {
  const { emailTemplates, updateEmailTemplate, smsTemplates, updateSmsTemplate, getLeads, getBookings } = useApp()
  const [tab, setTab] = useState('email')
  const [showTwilio, setShowTwilio] = useState(false)

  const leads   = getLeads()
  const bkgs    = getBookings()

  const activeEmail = emailTemplates.filter(t=>t.active).length
  const activeSms   = smsTemplates.filter(t=>t.active).length

  // Estimate emails sent: new_lead template fires per lead, booking_confirmed per booking
  const emailsSent = Math.max(0,
    (emailTemplates.find(t=>t.trigger==='new_lead'           && t.active) ? leads.length  : 0) +
    (emailTemplates.find(t=>t.trigger==='booking_confirmed'  && t.active) ? bkgs.length   : 0)
  )
  // Estimate SMS sent: new_lead alert per lead, appointment_reminder per booking
  const smsSent = Math.max(0,
    (smsTemplates.find(t=>t.trigger==='new_lead'             && t.active) ? leads.length  : 0) +
    (smsTemplates.find(t=>t.trigger==='appointment_reminder' && t.active) ? bkgs.length   : 0)
  )

  const stats = [
    { label:'Active Emails', value: activeEmail, color:'#0ea5e9', bg:'rgba(14,165,233,0.1)', max: emailTemplates.length || 1 },
    { label:'Active SMS',    value: activeSms,   color:'#10b981', bg:'rgba(16,185,129,0.1)', max: smsTemplates.length || 1 },
    { label:'Emails Sent',   value: emailsSent,  color:'#8b5cf6', bg:'rgba(139,92,246,0.1)', max: Math.max(emailsSent, 1) },
    { label:'SMS Sent',      value: smsSent,     color:'#f59e0b', bg:'rgba(245,158,11,0.1)', max: Math.max(smsSent, 1) },
  ]

  return (
    <div style={{ padding:28, minHeight:'100%' }}>
      {showTwilio && <TwilioModal onClose={() => setShowTwilio(false)} />}

      <div style={{ marginBottom:24 }}>
        <h1 style={{ fontSize:20, fontWeight:800, color:'#0f172a', letterSpacing:'-0.3px' }}>Automations</h1>
        <p style={{ fontSize:13, color:'#94a3b8', marginTop:3 }}>Manage automated email and SMS sequences</p>
      </div>

      {/* Stats */}
      <div style={{ display:'grid', gridTemplateColumns:'repeat(4,1fr)', gap:12, marginBottom:24 }}>
        {stats.map(({ label, value, color, bg, max }) => (
          <div key={label} style={{ background:'#fff', border:'1px solid #eaecf0', borderRadius:14, padding:'14px 18px', boxShadow:'0 1px 3px rgba(0,0,0,0.05)' }}>
            <p style={{ fontSize:24, fontWeight:800, color:'#0f172a', letterSpacing:'-0.4px', lineHeight:1 }}>{value}</p>
            <p style={{ fontSize:12, color:'#94a3b8', marginTop:4, fontWeight:500 }}>{label}</p>
            <div style={{ height:3, borderRadius:2, background:bg, marginTop:10 }}>
              <div style={{ height:'100%', width:`${Math.min(100, Math.round((value/max)*100))}%`, borderRadius:2, background:color }} />
            </div>
          </div>
        ))}
      </div>

      {/* Tab switcher */}
      <div style={{ display:'inline-flex', background:'#f1f5f9', borderRadius:11, padding:4, marginBottom:20, gap:4 }}>
        {[['email','📧 Email'],['sms','💬 SMS']].map(([key,label]) => (
          <button key={key} onClick={() => setTab(key)}
            style={{ padding:'7px 20px', borderRadius:8, border:'none', fontSize:13, fontWeight:600, cursor:'pointer', transition:'all 0.15s', background: tab===key ? '#fff' : 'transparent', color: tab===key ? '#0f172a' : '#64748b', boxShadow: tab===key ? '0 1px 3px rgba(0,0,0,0.1)' : 'none' }}>
            {label}
          </button>
        ))}
      </div>

      {tab === 'email' && (
        <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fill,minmax(340px,1fr))', gap:14 }}>
          {emailTemplates.map(t => <EmailCard key={t.id} t={t} onUpdate={updateEmailTemplate} />)}
        </div>
      )}

      {tab === 'sms' && (
        <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fill,minmax(340px,1fr))', gap:14 }}>
          {smsTemplates.map(t => <SmsCard key={t.id} t={t} onUpdate={updateSmsTemplate} />)}
          <div style={{ background:'linear-gradient(135deg,#0c1628,#0e2044)', border:'1px solid rgba(255,255,255,0.08)', borderRadius:16, padding:'22px 22px', display:'flex', flexDirection:'column', justifyContent:'center' }}>
            <div style={{ width:38, height:38, borderRadius:10, background:'rgba(14,165,233,0.3)', display:'flex', alignItems:'center', justifyContent:'center', marginBottom:14 }}>
              <Phone size={18} color="#60a5fa" />
            </div>
            <p style={{ fontSize:14, fontWeight:700, color:'#fff', marginBottom:6 }}>Twilio Integration</p>
            <p style={{ fontSize:12, color:'rgba(255,255,255,0.45)', lineHeight:1.6, marginBottom:16 }}>Connect your Twilio account to start sending real SMS messages to leads and customers automatically.</p>
            <button onClick={() => setShowTwilio(true)} style={{ display:'inline-flex', alignItems:'center', gap:6, background:'#0ea5e9', color:'#fff', border:'none', borderRadius:9, padding:'9px 16px', fontSize:13, fontWeight:700, cursor:'pointer', width:'fit-content' }}>
              <Settings size={13}/> Configure Twilio
            </button>
          </div>
        </div>
      )}
    </div>
  )
}
