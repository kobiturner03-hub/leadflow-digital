import { useState } from 'react'
import { useNavigate, Link } from 'react-router-dom'
import { useApp } from '../context/AppContext'
import { Eye, EyeOff, ArrowRight, Check, Building2, Mail, Phone, User, Lock, MailCheck } from 'lucide-react'

const INDUSTRIES = [
  'Trades & Construction','Beauty & Wellness','Automotive & Mechanical',
  'Cleaning Services','Landscaping & Gardening','Health & Fitness',
  'Real Estate','Hospitality & Food','Education & Tutoring',
  'Retail','Technology & IT','Other',
]

const inputStyle = {
  width:'100%', padding:'10px 14px 10px 38px', borderRadius:11,
  border:'1px solid #e2e8f0', fontSize:13, outline:'none',
  fontFamily:'Inter,sans-serif', color:'#0f172a', background:'#fff', boxSizing:'border-box',
}
const labelStyle = { display:'block', fontSize:12, fontWeight:600, color:'#374151', marginBottom:6 }
const iconStyle  = { position:'absolute', left:12, top:'50%', transform:'translateY(-50%)', pointerEvents:'none', color:'#94a3b8' }

function Field({ label, icon:Icon, error, children }) {
  return (
    <div>
      <label style={labelStyle}>{label}</label>
      <div style={{ position:'relative' }}>
        {Icon && <Icon size={14} style={iconStyle}/>}
        {children}
      </div>
      {error && <p style={{ fontSize:11, color:'#ef4444', marginTop:4 }}>{error}</p>}
    </div>
  )
}

export default function SignUp() {
  const { register } = useApp()
  const navigate     = useNavigate()

  const [form, setForm] = useState({ fullName:'', businessName:'', email:'', phone:'', industry:'', password:'', confirmPassword:'' })
  const [showPw,       setShowPw]       = useState(false)
  const [showCpw,      setShowCpw]      = useState(false)
  const [errors,       setErrors]       = useState({})
  const [apiError,     setApiError]     = useState('')
  const [loading,      setLoading]      = useState(false)
  const [confirmEmail, setConfirmEmail] = useState(false)

  const set = (k, v) => { setForm(f => ({ ...f, [k]:v })); setErrors(e => ({ ...e, [k]:'' })) }

  const validate = () => {
    const e = {}
    if (!form.fullName.trim())                            e.fullName     = 'Full name is required.'
    if (!form.businessName.trim())                        e.businessName = 'Business name is required.'
    if (!form.email.match(/^[^\s@]+@[^\s@]+\.[^\s@]+$/)) e.email        = 'Enter a valid email address.'
    if (!form.phone.trim())                               e.phone        = 'Phone number is required.'
    if (!form.industry)                                   e.industry     = 'Please select an industry.'
    if (form.password.length < 8)                         e.password     = 'Password must be at least 8 characters.'
    if (form.password !== form.confirmPassword)           e.confirmPassword = 'Passwords do not match.'
    return e
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    const errs = validate()
    if (Object.keys(errs).length) { setErrors(errs); return }
    setLoading(true); setApiError('')
    const result = await register({
      fullName:     form.fullName.trim(),
      businessName: form.businessName.trim(),
      email:        form.email.trim().toLowerCase(),
      phone:        form.phone.trim(),
      industry:     form.industry,
      password:     form.password,
    })
    if (result?.ok) {
      navigate('/dashboard')
    } else if (result?.needsConfirmation) {
      setConfirmEmail(true)
      setLoading(false)
    } else {
      setApiError(result?.error || 'Something went wrong. Please try again.')
      setLoading(false)
    }
  }

  return (
    <div style={{
      minHeight:'100vh',
      background:'linear-gradient(160deg,#0d1f3c 0%,#0a3a5c 55%,#062a44 100%)',
      display:'flex', alignItems:'center', justifyContent:'center',
      padding:'32px 16px', position:'relative', overflow:'hidden',
    }}>
      <div style={{ position:'absolute', top:'-120px', right:'-120px', width:450, height:450, borderRadius:'50%', background:'radial-gradient(circle,rgba(14,165,233,0.12) 0%,transparent 70%)', pointerEvents:'none' }}/>
      <div style={{ position:'absolute', bottom:'-100px', left:'-100px', width:380, height:380, borderRadius:'50%', background:'radial-gradient(circle,rgba(34,197,94,0.08) 0%,transparent 70%)', pointerEvents:'none' }}/>

      <div style={{ width:'100%', maxWidth:480, position:'relative', zIndex:1 }}>

        {/* Logo */}
        <div style={{ textAlign:'center', marginBottom:28 }}>
          <div style={{ display:'inline-flex', alignItems:'center', background:'rgba(255,255,255,0.97)', borderRadius:16, padding:'0 28px', height:64, overflow:'hidden', marginBottom:16, boxShadow:'0 8px 32px rgba(0,0,0,0.18)' }}>
            <img src="/leadflow-logo.png" alt="LeadFlow Digital" style={{ height:82, width:'auto', objectFit:'contain', display:'block', flexShrink:0 }} />
          </div>
          <h1 style={{ color:'#fff', fontSize:21, fontWeight:800, letterSpacing:'-0.4px', marginBottom:4 }}>Create your account</h1>
          <p style={{ color:'rgba(255,255,255,0.38)', fontSize:13 }}>Start managing your business with LeadFlow Digital</p>
        </div>

        {/* Card */}
        <div style={{ background:'#fff', borderRadius:20, padding:'28px 28px 24px', boxShadow:'0 24px 80px rgba(0,0,0,0.35)' }}>

          {confirmEmail ? (
            /* ── Email confirmation screen ── */
            <div style={{ textAlign:'center', padding:'12px 0 8px' }}>
              <div style={{ width:56, height:56, borderRadius:16, background:'rgba(14,165,233,0.1)', display:'flex', alignItems:'center', justifyContent:'center', margin:'0 auto 16px' }}>
                <MailCheck size={26} color="#2563eb"/>
              </div>
              <h2 style={{ fontSize:18, fontWeight:800, color:'#0f172a', marginBottom:8 }}>Check your email</h2>
              <p style={{ fontSize:13, color:'#64748b', lineHeight:1.6, marginBottom:4 }}>We've sent a confirmation link to</p>
              <p style={{ fontSize:14, fontWeight:700, color:'#0f172a', marginBottom:16 }}>{form.email}</p>
              <p style={{ fontSize:12, color:'#94a3b8', lineHeight:1.6, marginBottom:20 }}>
                Click the link in that email to activate your account. Check your spam folder if you don't see it within a minute.
              </p>
              <Link to="/login" style={{ display:'inline-flex', alignItems:'center', gap:6, fontSize:13, fontWeight:700, color:'#0ea5e9', textDecoration:'none' }}>
                Back to sign in
              </Link>
            </div>
          ) : (
            /* ── Sign up form ── */
            <>
              {apiError && (
                <div style={{ background:'#fef2f2', border:'1px solid #fecaca', borderRadius:10, padding:'10px 14px', display:'flex', alignItems:'center', gap:8, marginBottom:18 }}>
                  <div style={{ width:6, height:6, borderRadius:'50%', background:'#ef4444', flexShrink:0 }}/>
                  <p style={{ fontSize:12, color:'#dc2626', fontWeight:500 }}>{apiError}</p>
                </div>
              )}

              <form onSubmit={handleSubmit} style={{ display:'flex', flexDirection:'column', gap:14 }}>

                <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:12 }}>
                  <Field label="Full Name" icon={User} error={errors.fullName}>
                    <input value={form.fullName} onChange={e => set('fullName', e.target.value)} placeholder="Jane Smith"
                      style={{ ...inputStyle, borderColor: errors.fullName ? '#fca5a5' : '#e2e8f0' }}
                      onFocus={e => e.target.style.borderColor='#0ea5e9'} onBlur={e => e.target.style.borderColor=errors.fullName?'#fca5a5':'#e2e8f0'}/>
                  </Field>
                  <Field label="Business Name" icon={Building2} error={errors.businessName}>
                    <input value={form.businessName} onChange={e => set('businessName', e.target.value)} placeholder="My Business Pty Ltd"
                      style={{ ...inputStyle, borderColor: errors.businessName ? '#fca5a5' : '#e2e8f0' }}
                      onFocus={e => e.target.style.borderColor='#0ea5e9'} onBlur={e => e.target.style.borderColor=errors.businessName?'#fca5a5':'#e2e8f0'}/>
                  </Field>
                </div>

                <Field label="Email Address" icon={Mail} error={errors.email}>
                  <input type="email" value={form.email} onChange={e => set('email', e.target.value)} placeholder="you@yourbusiness.com.au"
                    style={{ ...inputStyle, borderColor: errors.email ? '#fca5a5' : '#e2e8f0' }}
                    onFocus={e => e.target.style.borderColor='#0ea5e9'} onBlur={e => e.target.style.borderColor=errors.email?'#fca5a5':'#e2e8f0'}/>
                </Field>

                <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:12 }}>
                  <Field label="Phone Number" icon={Phone} error={errors.phone}>
                    <input type="tel" value={form.phone} onChange={e => set('phone', e.target.value)} placeholder="04XX XXX XXX"
                      style={{ ...inputStyle, borderColor: errors.phone ? '#fca5a5' : '#e2e8f0' }}
                      onFocus={e => e.target.style.borderColor='#0ea5e9'} onBlur={e => e.target.style.borderColor=errors.phone?'#fca5a5':'#e2e8f0'}/>
                  </Field>
                  <div>
                    <label style={labelStyle}>Industry</label>
                    <select value={form.industry} onChange={e => set('industry', e.target.value)}
                      style={{ ...inputStyle, paddingLeft:14, paddingRight:8, borderColor: errors.industry ? '#fca5a5' : '#e2e8f0', appearance:'none', cursor:'pointer' }}
                      onFocus={e => e.target.style.borderColor='#0ea5e9'} onBlur={e => e.target.style.borderColor=errors.industry?'#fca5a5':'#e2e8f0'}>
                      <option value="">Select industry…</option>
                      {INDUSTRIES.map(i => <option key={i} value={i}>{i}</option>)}
                    </select>
                    {errors.industry && <p style={{ fontSize:11, color:'#ef4444', marginTop:4 }}>{errors.industry}</p>}
                  </div>
                </div>

                <Field label="Password" icon={Lock} error={errors.password}>
                  <input type={showPw ? 'text' : 'password'} value={form.password} onChange={e => set('password', e.target.value)}
                    placeholder="Min. 8 characters" style={{ ...inputStyle, paddingRight:40, borderColor: errors.password ? '#fca5a5' : '#e2e8f0' }}
                    onFocus={e => e.target.style.borderColor='#0ea5e9'} onBlur={e => e.target.style.borderColor=errors.password?'#fca5a5':'#e2e8f0'}/>
                  <button type="button" onClick={() => setShowPw(!showPw)} style={{ position:'absolute', right:12, top:'50%', transform:'translateY(-50%)', background:'none', border:'none', cursor:'pointer', color:'#94a3b8', padding:0, display:'flex' }}>
                    {showPw ? <EyeOff size={15}/> : <Eye size={15}/>}
                  </button>
                </Field>

                <Field label="Confirm Password" icon={Lock} error={errors.confirmPassword}>
                  <input type={showCpw ? 'text' : 'password'} value={form.confirmPassword} onChange={e => set('confirmPassword', e.target.value)}
                    placeholder="Re-enter password" style={{ ...inputStyle, paddingRight:40, borderColor: errors.confirmPassword ? '#fca5a5' : '#e2e8f0' }}
                    onFocus={e => e.target.style.borderColor='#0ea5e9'} onBlur={e => e.target.style.borderColor=errors.confirmPassword?'#fca5a5':'#e2e8f0'}/>
                  <button type="button" onClick={() => setShowCpw(!showCpw)} style={{ position:'absolute', right:12, top:'50%', transform:'translateY(-50%)', background:'none', border:'none', cursor:'pointer', color:'#94a3b8', padding:0, display:'flex' }}>
                    {showCpw ? <EyeOff size={15}/> : <Eye size={15}/>}
                  </button>
                </Field>

                {form.password.length > 0 && (
                  <div style={{ display:'flex', gap:16, flexWrap:'wrap' }}>
                    {[['8+ characters', form.password.length >= 8],['Uppercase', /[A-Z]/.test(form.password)],['Number', /\d/.test(form.password)]].map(([lbl, ok]) => (
                      <div key={lbl} style={{ display:'flex', alignItems:'center', gap:5 }}>
                        <div style={{ width:14, height:14, borderRadius:'50%', background: ok ? '#10b981' : '#e2e8f0', display:'flex', alignItems:'center', justifyContent:'center', flexShrink:0 }}>
                          {ok && <Check size={9} color="#fff"/>}
                        </div>
                        <span style={{ fontSize:11, color: ok ? '#059669' : '#94a3b8', fontWeight:500 }}>{lbl}</span>
                      </div>
                    ))}
                  </div>
                )}

                <button type="submit" disabled={loading} style={{
                  width:'100%', padding:'11px', borderRadius:11, border:'none',
                  background: loading ? 'rgba(14,165,233,0.7)' : 'linear-gradient(135deg,#0284c7,#0ea5e9)',
                  color:'#fff', fontSize:14, fontWeight:700, cursor: loading ? 'not-allowed' : 'pointer',
                  display:'flex', alignItems:'center', justifyContent:'center', gap:8,
                  boxShadow:'0 4px 16px rgba(14,165,233,0.35)', marginTop:6, fontFamily:'Inter,sans-serif',
                }}>
                  {loading
                    ? <div style={{ width:16, height:16, border:'2px solid rgba(255,255,255,0.3)', borderTopColor:'#fff', borderRadius:'50%', animation:'spin 0.7s linear infinite' }}/>
                    : <><ArrowRight size={15}/> Create Account</>
                  }
                </button>
              </form>

              <p style={{ textAlign:'center', fontSize:12, color:'#94a3b8', marginTop:18 }}>
                Already have an account?{' '}
                <Link to="/login" style={{ color:'#0ea5e9', fontWeight:600, textDecoration:'none' }}>Sign in</Link>
              </p>
            </>
          )}
        </div>

        <p style={{ textAlign:'center', color:'rgba(255,255,255,0.2)', fontSize:11, marginTop:20 }}>
          © 2026 LeadFlow Digital. All rights reserved.
        </p>
      </div>

      <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
    </div>
  )
}
