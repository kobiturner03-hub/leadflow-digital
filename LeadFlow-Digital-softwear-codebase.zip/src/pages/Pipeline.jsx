import { useState, useEffect, useCallback } from 'react'
import { useApp } from '../context/AppContext'
import { DragDropContext, Droppable, Draggable } from '@hello-pangea/dnd'
import { Phone, GripVertical, ChevronRight } from 'lucide-react'

const STAGES = ['New Lead', 'Contacted', 'Qualified', 'Quoted', 'Won (Booked)', 'Completed']

const STAGE_CONFIG = {
  'New Lead':     { accent: '#3b82f6', light: 'rgba(59,130,246,0.1)',  bg: 'rgba(59,130,246,0.04)' },
  'Contacted':    { accent: '#f59e0b', light: 'rgba(245,158,11,0.1)',  bg: 'rgba(245,158,11,0.04)' },
  'Qualified':    { accent: '#8b5cf6', light: 'rgba(139,92,246,0.1)', bg: 'rgba(139,92,246,0.04)' },
  'Quoted':       { accent: '#f97316', light: 'rgba(249,115,22,0.1)', bg: 'rgba(249,115,22,0.04)' },
  'Won (Booked)': { accent: '#22c55e', light: 'rgba(34,197,94,0.1)',  bg: 'rgba(34,197,94,0.04)' },
  'Completed':    { accent: '#10b981', light: 'rgba(16,185,129,0.1)', bg: 'rgba(16,185,129,0.04)' },
}

// Re-order within the same column
function reorderList(list, startIndex, endIndex) {
  const result = Array.from(list)
  const [removed] = result.splice(startIndex, 1)
  result.splice(endIndex, 0, removed)
  return result
}

export default function Pipeline() {
  const { getLeads, updateLead } = useApp()

  // Local optimistic state — keyed by stage
  const [columns, setColumns] = useState({})

  // Rebuild columns whenever upstream leads change (e.g. after page nav)
  useEffect(() => {
    const leads = getLeads()
    const grouped = STAGES.reduce((acc, s) => {
      acc[s] = leads.filter(l => l.status === s)
      return acc
    }, {})
    setColumns(grouped)
  }, []) // run once on mount; drag updates are handled locally

  const totalPipeline = STAGES.reduce(
    (sum, s) => sum + (columns[s] || []).reduce((sv, l) => sv + (Number(l.jobValue) || 0), 0),
    0
  )

  const onDragEnd = useCallback(({ destination, source, draggableId }) => {
    if (!destination) return
    const srcStage  = source.droppableId
    const destStage = destination.droppableId

    if (srcStage === destStage && destination.index === source.index) return

    setColumns(prev => {
      const srcList  = Array.from(prev[srcStage]  || [])
      const destList = srcStage === destStage ? srcList : Array.from(prev[destStage] || [])

      if (srcStage === destStage) {
        const reordered = reorderList(srcList, source.index, destination.index)
        return { ...prev, [srcStage]: reordered }
      }

      // Move card across columns
      const [moved] = srcList.splice(source.index, 1)
      const updatedCard = { ...moved, status: destStage }
      destList.splice(destination.index, 0, updatedCard)

      return {
        ...prev,
        [srcStage]: srcList,
        [destStage]: destList,
      }
    })

    // Persist the status change (fire-and-forget)
    if (srcStage !== destStage) {
      updateLead(Number(draggableId), { status: destStage })
    }
  }, [updateLead])

  return (
    <div style={{ padding: '28px 28px 0', minHeight: '100%', display: 'flex', flexDirection: 'column', gap: 20 }}>

      {/* Header */}
      <div style={{ display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between' }}>
        <div>
          <h1 style={{ fontSize: 20, fontWeight: 800, color: '#0f172a', letterSpacing: '-0.3px' }}>Pipeline</h1>
          <p style={{ fontSize: 13, color: '#94a3b8', marginTop: 3 }}>Drag cards between stages to update lead status</p>
        </div>
        <div style={{ background: 'linear-gradient(135deg,#0284c7,#0ea5e9)', borderRadius: 14, padding: '10px 20px', textAlign: 'right', boxShadow: '0 4px 16px rgba(14,165,233,0.3)' }}>
          <p style={{ color: 'rgba(255,255,255,0.6)', fontSize: 10, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.06em' }}>Total Pipeline</p>
          <p style={{ color: '#fff', fontSize: 20, fontWeight: 800, letterSpacing: '-0.3px', marginTop: 1 }}>
            ${totalPipeline.toLocaleString()}
          </p>
        </div>
      </div>

      {/* Stage summary strip */}
      <div style={{ display: 'flex', gap: 8, overflowX: 'auto', paddingBottom: 4 }}>
        {STAGES.map((stage, i) => {
          const cfg   = STAGE_CONFIG[stage]
          const items = columns[stage] || []
          const val   = items.reduce((s, l) => s + (Number(l.jobValue) || 0), 0)
          return (
            <div key={stage} style={{ background: '#fff', border: '1px solid #eaecf0', borderRadius: 12, padding: '10px 16px', minWidth: 136, flexShrink: 0, boxShadow: '0 1px 3px rgba(0,0,0,0.05)' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 5 }}>
                {i < STAGES.length - 1 && (
                  <ChevronRight size={10} style={{ color: '#cbd5e1', flexShrink: 0 }} />
                )}
                <span style={{ width: 7, height: 7, borderRadius: '50%', background: cfg.accent, display: 'inline-block', flexShrink: 0 }} />
                <p style={{ fontSize: 10, fontWeight: 600, color: '#64748b', whiteSpace: 'nowrap' }}>{stage}</p>
              </div>
              <p style={{ fontSize: 16, fontWeight: 800, color: '#0f172a', lineHeight: 1 }}>{items.length}</p>
              <p style={{ fontSize: 11, color: '#94a3b8', marginTop: 2 }}>${val.toLocaleString()}</p>
            </div>
          )
        })}
      </div>

      {/* Kanban board */}
      <DragDropContext onDragEnd={onDragEnd}>
        <div style={{ display: 'flex', gap: 12, overflowX: 'auto', flex: 1, paddingBottom: 24, alignItems: 'flex-start' }}>
          {STAGES.map(stage => {
            const cfg        = STAGE_CONFIG[stage]
            const stageLeads = columns[stage] || []
            const val        = stageLeads.reduce((s, l) => s + (Number(l.jobValue) || 0), 0)

            return (
              <div
                key={stage}
                style={{ flexShrink: 0, width: 234, display: 'flex', flexDirection: 'column' }}
              >
                {/* Column header */}
                <div style={{
                  background: '#fff',
                  border: '1px solid #eaecf0',
                  borderRadius: '14px 14px 0 0',
                  borderBottom: 'none',
                  padding: '11px 13px',
                  borderTop: `3px solid ${cfg.accent}`,
                }}>
                  <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                    <p style={{ fontSize: 12, fontWeight: 700, color: '#0f172a' }}>{stage}</p>
                    <span style={{ background: cfg.light, color: cfg.accent, fontSize: 11, fontWeight: 700, padding: '2px 8px', borderRadius: 20 }}>
                      {stageLeads.length}
                    </span>
                  </div>
                  <p style={{ fontSize: 11, color: '#94a3b8', marginTop: 2, fontWeight: 600 }}>
                    ${val.toLocaleString()}
                  </p>
                </div>

                <Droppable droppableId={stage}>
                  {(provided, snapshot) => (
                    <div
                      ref={provided.innerRef}
                      {...provided.droppableProps}
                      style={{
                        padding: '6px 6px 2px',
                        borderRadius: '0 0 14px 14px',
                        background: snapshot.isDraggingOver ? cfg.bg : '#f8fafc',
                        border: `1px solid ${snapshot.isDraggingOver ? cfg.accent + '40' : '#eaecf0'}`,
                        borderTop: 'none',
                        minHeight: 80,
                        transition: 'background 0.18s, border-color 0.18s',
                      }}
                    >
                      {stageLeads.map((lead, index) => (
                        <Draggable key={lead.id} draggableId={String(lead.id)} index={index}>
                          {(provided, snapshot) => (
                            <div
                              ref={provided.innerRef}
                              {...provided.draggableProps}
                              style={{
                                // IMPORTANT: spread library styles first and never override `transform`
                                // — dnd uses transform for hit-testing and overriding it breaks drop targets
                                ...provided.draggableProps.style,
                                position: 'relative',   // required for the accent bar child
                                marginBottom: 7,
                                borderRadius: 12,
                                background: '#fff',
                                border: snapshot.isDragging
                                  ? `1.5px solid ${cfg.accent}`
                                  : '1px solid #eaecf0',
                                boxShadow: snapshot.isDragging
                                  ? `0 16px 40px rgba(0,0,0,0.18), 0 0 0 3px ${cfg.accent}22`
                                  : '0 1px 3px rgba(0,0,0,0.05)',
                                opacity: snapshot.isDragging ? 0.96 : 1,
                                cursor: snapshot.isDragging ? 'grabbing' : 'default',
                                userSelect: 'none',
                                // no overflow:hidden — clips dnd's internal placeholder sentinel
                              }}
                            >
                              {/* Coloured left accent bar */}
                              <div style={{ position: 'absolute', left: 0, top: 0, bottom: 0, width: 3, background: cfg.accent, borderRadius: '12px 0 0 12px', pointerEvents: 'none' }} />

                              <div style={{ padding: '11px 12px 11px 15px' }}>
                                {/* Drag handle row */}
                                <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: 6 }}>
                                  <p style={{ fontSize: 13, fontWeight: 700, color: '#0f172a', lineHeight: 1.3, flex: 1 }}>{lead.name}</p>
                                  <div
                                    {...provided.dragHandleProps}
                                    style={{ color: '#cbd5e1', cursor: snapshot.isDragging ? 'grabbing' : 'grab', padding: '2px 0 0 6px', flexShrink: 0, touchAction: 'none' }}
                                  >
                                    <GripVertical size={14} />
                                  </div>
                                </div>

                                <p style={{ fontSize: 11, color: '#64748b', marginBottom: 10 }}>{lead.service}</p>

                                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                                  <div style={{ display: 'flex', alignItems: 'center', gap: 4, color: '#94a3b8' }}>
                                    <Phone size={10} />
                                    <span style={{ fontSize: 10 }}>{lead.phone}</span>
                                  </div>
                                  {lead.jobValue > 0 && (
                                    <span style={{
                                      fontSize: 12, fontWeight: 800, color: cfg.accent,
                                      background: cfg.light, padding: '2px 7px', borderRadius: 6,
                                    }}>
                                      ${Number(lead.jobValue).toLocaleString()}
                                    </span>
                                  )}
                                </div>
                              </div>
                            </div>
                          )}
                        </Draggable>
                      ))}

                      {provided.placeholder}

                      {stageLeads.length === 0 && !snapshot.isDraggingOver && (
                        <div style={{ textAlign: 'center', padding: '18px 0', color: '#cbd5e1', fontSize: 11, fontWeight: 500 }}>
                          Drop here
                        </div>
                      )}
                    </div>
                  )}
                </Droppable>
              </div>
            )
          })}
        </div>
      </DragDropContext>
    </div>
  )
}
