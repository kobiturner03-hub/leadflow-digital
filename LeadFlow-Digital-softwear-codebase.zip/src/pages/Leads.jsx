import { useState } from 'react'
import { createPortal } from 'react-dom'
import { useApp } from '../context/AppContext'
import { Plus, Search, Eye, Phone, CheckCircle, Trash2, X, Filter, Pencil, DollarSign, RefreshCw, Calendar, ChevronRight } from 'lucide-react'

const PAYMENT_STYLE = {
  'Unpaid':         { bg:'rgba(239,68,68,0.08)',   color:'#dc2626' },
  'Partially Paid': { bg:'rgba(245,158,11,0.1)',   color:'#b45309' },
  'Paid':           { bg:'rgba(16,185,129,0.1)',   color:'#065f46' },
}
const STATUS_STYLE = {
  'New Lead':     { bg:'rgba(59,130,246,0.08)',  color:'#0284c7' },
  'Contacted':    { bg:'rgba(245,158,11,0.1)',   color:'#b45309' },
  'Qualified':    { bg:'rgba(139,92,246,0.1)',   color:'#6d28d9' },
  'Quoted':       { bg:'rgba(249,115,22,0.1)',   color:'#c2410c' },
  'Won (Booked)': { bg:'rgba(34,197,94,0.1)',    color:'#15803d' },
  'Completed':    { bg:'rgba(16,185,129,0.1)',   color:'#065f46' },
}

const STATUSES = ['New Lead','Contacted','Qualified','Quoted','Won (Booked)','Completed']
const PAYMENT_STATUSES = ['Unpaid','Partially Paid','Paid']

function Badge({ label, map }) {
  const s = map[label] || { bg:'#f1f5f9', color:'#64748b' }
  return <span style={{ background:s.bg, color:s.color, fontSize:11, fontWeight:600, padding:'3px 10px', borderRadius:20, whiteSpace:'nowrap' }}>{label}</span>
}

function Modal({ title, onClose, children, maxWidth = 600 }) {
  return createPortal(
    <div style={{
      position:'fixed', top:0, left:0, width:'100vw', height:'100vh',
      zIndex:9999,
      display:'flex', alignItems:'center', justifyContent:'center',
      padding:'20px',
      background:'rgba(15,23,42,0.6)',
      backdropFilter:'blur(6px)',
    }}>
      <div style={{
        background:'#fff', borderRadius:20,
        boxShadow:'0 32px 96px rgba(0,0,0,0.28)',
        width:'100%', maxWidth,
        maxHeight:'calc(100vh - 40px)',
        display:'flex', flexDirection:'column',
        overflow:'hidden',
      }}>
        <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', padding:'20px 28px', borderBottom:'1px solid #f1f5f9', flexShrink:0 }}>
          <p style={{ fontWeight:800, color:'#0f172a', fontSize:16, letterSpacing:'-0.2px' }}>{title}</p>
          <button onClick={onClose} style={{ background:'#f1f5f9', border:'none', borderRadius:9, width:32, height:32, display:'flex', alignItems:'center', justifyContent:'center', cursor:'pointer', color:'#64748b' }}><X size={15} /></button>
        </div>
        <div style={{ padding:'24px 28px 28px', overflowY:'auto', flex:1 }}>{children}</div>
      </div>
    </div>,
    document.body
  )
}

const inputStyle = { width:'100%', padding:'10px 13px', borderRadius:10, border:'1.5px solid #e2e8f0', fontSize:14, outline:'none', fontFamily:'inherit', color:'#0f172a', background:'#fff', boxSizing:'border-box', transition:'border-color 0.15s' }
const labelStyle = { display:'block', fontSize:12, fontWeight:700, color:'#374151', marginBottom:6, letterSpacing:'0.02em' }
const sectionLabel = { fontSize:11, fontWeight:700, color:'#94a3b8', textTransform:'uppercase', letterSpacing:'0.08em', marginBottom:10, marginTop:4 }

function LeadForm({ onSubmit, onClose, initial = {}, submitLabel = 'Save Lead' }) {
  const [f, setF] = useState({
    name:'', phone:'', email:'', service:'', message:'', jobValue:'', paymentStatus:'Unpaid', status:'New Lead',
    isRecurring: false, recurringAmount:'', recurringNextDate:'', recurringNotes:'',
    ...initial
  })
  const s = (k,v) => setF(p => ({ ...p, [k]:v }))
  return (
    <form onSubmit={e => { e.preventDefault(); onSubmit(f) }} style={{ display:'flex', flexDirection:'column', gap:0 }}>

      {/* Contact info */}
      <p style={sectionLabel}>Contact Info</p>
      <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:14, marginBottom:14 }}>
        <div>
          <label style={labelStyle}>Full Name <span style={{ color:'#ef4444' }}>*</span></label>
          <input required value={f.name} onChange={e=>s('name',e.target.value)} style={inputStyle} placeholder="e.g. John Smith" />
        </div>
        <div>
          <label style={labelStyle}>Phone <span style={{ color:'#ef4444' }}>*</span></label>
          <input required value={f.phone} onChange={e=>s('phone',e.target.value)} style={inputStyle} placeholder="e.g. 0400 000 000" />
        </div>
      </div>
      <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:14, marginBottom:14 }}>
        <div>
          <label style={labelStyle}>Email</label>
          <input type="email" value={f.email} onChange={e=>s('email',e.target.value)} style={inputStyle} placeholder="e.g. john@email.com" />
        </div>
        <div>
          <label style={labelStyle}>Service / Type</label>
          <input value={f.service} onChange={e=>s('service',e.target.value)} style={inputStyle} placeholder="e.g. Plumbing, Electrical…" />
        </div>
      </div>
      <div style={{ marginBottom:20 }}>
        <label style={labelStyle}>Message / Notes</label>
        <textarea rows={3} value={f.message} onChange={e=>s('message',e.target.value)} style={{ ...inputStyle, resize:'vertical', minHeight:72 }} placeholder="Any additional details…" />
      </div>

      {/* Job value */}
      <p style={sectionLabel}>Financial</p>
      <div style={{ background:'linear-gradient(135deg,#f0f9ff,#f0fdf4)', border:'1.5px solid #bae6fd', borderRadius:14, padding:'16px 18px', marginBottom:16 }}>
        <label style={{ ...labelStyle, color:'#0284c7', fontSize:13 }}>
          <span style={{ display:'flex', alignItems:'center', gap:6 }}><DollarSign size={14}/>Job Value (AUD)</span>
        </label>
        <input type="number" min="0" step="0.01" placeholder="0.00" value={f.jobValue} onChange={e=>s('jobValue',e.target.value)}
          style={{ ...inputStyle, fontSize:22, fontWeight:800, color:'#059669', border:'1.5px solid #bbf7d0', background:'#fff', letterSpacing:'-0.5px', padding:'10px 14px' }} />
      </div>

      {/* Recurring payments toggle */}
      <div style={{ background: f.isRecurring ? 'linear-gradient(135deg,#fdf4ff,#f5f3ff)' : '#f8fafc', border: f.isRecurring ? '1.5px solid #e9d5ff' : '1.5px solid #e2e8f0', borderRadius:14, padding:'14px 18px', marginBottom:20 }}>
        <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', cursor:'pointer' }} onClick={()=>s('isRecurring',!f.isRecurring)}>
          <div style={{ display:'flex', alignItems:'center', gap:10 }}>
            <div style={{ width:32, height:32, borderRadius:8, background: f.isRecurring ? 'linear-gradient(135deg,#7c3aed,#6d28d9)' : '#e2e8f0', display:'flex', alignItems:'center', justifyContent:'center', transition:'background 0.2s' }}>
              <RefreshCw size={15} color={f.isRecurring ? '#fff' : '#94a3b8'} />
            </div>
            <div>
              <p style={{ fontSize:13, fontWeight:700, color: f.isRecurring ? '#6d28d9' : '#374151' }}>Monthly Recurring Payment</p>
              <p style={{ fontSize:11, color:'#94a3b8', marginTop:1 }}>Enable for subscription / retainer clients</p>
            </div>
          </div>
          <div style={{ width:40, height:22, borderRadius:11, background: f.isRecurring ? '#7c3aed' : '#cbd5e1', transition:'background 0.2s', position:'relative', flexShrink:0 }}>
            <div style={{ position:'absolute', top:3, left: f.isRecurring ? 21 : 3, width:16, height:16, borderRadius:'50%', background:'#fff', transition:'left 0.2s', boxShadow:'0 1px 4px rgba(0,0,0,0.2)' }} />
          </div>
        </div>
        {f.isRecurring && (
          <div style={{ marginTop:16, display:'flex', flexDirection:'column', gap:12 }}>
            <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:12 }}>
              <div>
                <label style={labelStyle}>Monthly Amount (AUD)</label>
                <div style={{ position:'relative' }}>
                  <span style={{ position:'absolute', left:12, top:'50%', transform:'translateY(-50%)', color:'#7c3aed', fontWeight:700, fontSize:14 }}>$</span>
                  <input type="number" min="0" step="0.01" placeholder="0.00"
                    value={f.recurringAmount} onChange={e=>s('recurringAmount',e.target.value)}
                    style={{ ...inputStyle, paddingLeft:26, fontWeight:700, color:'#6d28d9', borderColor:'#ddd6fe' }} />
                </div>
              </div>
              <div>
                <label style={labelStyle}>Next Payment Date</label>
                <input type="date" value={f.recurringNextDate} onChange={e=>s('recurringNextDate',e.target.value)}
                  style={{ ...inputStyle, borderColor:'#ddd6fe', color:'#374151' }} />
              </div>
            </div>
            <div>
              <label style={labelStyle}>Recurring Notes</label>
              <input placeholder="e.g. Monthly SEO retainer, charged 1st of each month"
                value={f.recurringNotes} onChange={e=>s('recurringNotes',e.target.value)}
                style={{ ...inputStyle, borderColor:'#ddd6fe' }} />
            </div>
          </div>
        )}
      </div>

      {/* Status */}
      <p style={sectionLabel}>Status</p>
      <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:14, marginBottom:24 }}>
        <div>
          <label style={labelStyle}>Lead Status</label>
          <select value={f.status} onChange={e=>s('status',e.target.value)} style={{ ...inputStyle, cursor:'pointer', appearance:'auto' }}>
            {STATUSES.map(p=><option key={p}>{p}</option>)}
          </select>
        </div>
        <div>
          <label style={labelStyle}>Payment Status</label>
          <select value={f.paymentStatus} onChange={e=>s('paymentStatus',e.target.value)} style={{ ...inputStyle, cursor:'pointer', appearance:'auto' }}>
            {PAYMENT_STATUSES.map(p=><option key={p}>{p}</option>)}
          </select>
        </div>
      </div>

      <div style={{ display:'flex', gap:10, paddingTop:4, borderTop:'1px solid #f1f5f9' }}>
        <button type="button" onClick={onClose} style={{ flex:1, padding:'11px', borderRadius:11, border:'1.5px solid #e2e8f0', background:'#fff', fontSize:13, fontWeight:700, color:'#64748b', cursor:'pointer' }}>Cancel</button>
        <button type="submit" style={{ flex:2, padding:'11px', borderRadius:11, border:'none', background:'linear-gradient(135deg,#0ea5e9,#0284c7)', fontSize:14, fontWeight:800, color:'#fff', cursor:'pointer', boxShadow:'0 4px 14px rgba(14,165,233,0.35)', letterSpacing:'-0.1px' }}>{submitLabel}</button>
      </div>
    </form>
  )
}

// Two-step delete button
function DeleteButton({ onConfirm }) {
  const [confirming, setConfirming] = useState(false)
  if (confirming) {
    return (
      <div style={{ display:'flex', alignItems:'center', gap:4 }}>
        <button onClick={() => { onConfirm(); setConfirming(false) }}
          style={{ height:28, padding:'0 10px', borderRadius:8, border:'none', background:'#dc2626', color:'#fff', fontSize:11, fontWeight:700, cursor:'pointer', whiteSpace:'nowrap' }}>
          Delete
        </button>
        <button onClick={() => setConfirming(false)}
          style={{ width:28, height:28, display:'flex', alignItems:'center', justifyContent:'center', background:'#f1f5f9', border:'1px solid #e2e8f0', borderRadius:8, cursor:'pointer', color:'#64748b' }}>
          <X size={12}/>
        </button>
      </div>
    )
  }
  return (
    <button title="Delete" onClick={() => setConfirming(true)}
      style={{ width:28, height:28, display:'flex', alignItems:'center', justifyContent:'center', background:'#f8fafc', border:'1px solid #eaecf0', borderRadius:8, cursor:'pointer', color:'#94a3b8' }}
      onMouseEnter={e=>{ e.currentTarget.style.background='#fef2f2'; e.currentTarget.style.color='#dc2626'; e.currentTarget.style.borderColor='#fecaca' }}
      onMouseLeave={e=>{ e.currentTarget.style.background='#f8fafc'; e.currentTarget.style.color='#94a3b8'; e.currentTarget.style.borderColor='#eaecf0' }}>
      <Trash2 size={13}/>
    </button>
  )
}

function RecurringSection({ leads, onEdit }) {
  const recurring = leads.filter(l => l.isRecurring)
  const totalMonthly = recurring.reduce((sum, l) => sum + (l.recurringAmount || 0), 0)

  // Days until next payment
  const daysUntil = (dateStr) => {
    if (!dateStr) return null
    const diff = Math.ceil((new Date(dateStr) - new Date()) / (1000*60*60*24))
    return diff
  }

  const urgencyColor = (days) => {
    if (days === null) return '#94a3b8'
    if (days <= 3) return '#dc2626'
    if (days <= 7) return '#b45309'
    return '#059669'
  }

  return (
    <div style={{ marginBottom:28 }}>
      {/* Section header */}
      <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', marginBottom:14 }}>
        <div style={{ display:'flex', alignItems:'center', gap:10 }}>
          <div style={{ width:34, height:34, borderRadius:10, background:'linear-gradient(135deg,#7c3aed,#6d28d9)', display:'flex', alignItems:'center', justifyContent:'center' }}>
            <RefreshCw size={16} color="#fff" />
          </div>
          <div>
            <h2 style={{ fontSize:15, fontWeight:800, color:'#0f172a', letterSpacing:'-0.2px' }}>Recurring Monthly Payments</h2>
            <p style={{ fontSize:12, color:'#94a3b8', marginTop:1 }}>{recurring.length} active client{recurring.length !== 1 ? 's' : ''}</p>
          </div>
        </div>
        <div style={{ background:'linear-gradient(135deg,#fdf4ff,#f5f3ff)', border:'1.5px solid #e9d5ff', borderRadius:14, padding:'10px 18px', textAlign:'right' }}>
          <p style={{ fontSize:11, color:'#9333ea', fontWeight:600, marginBottom:2 }}>MONTHLY RECURRING</p>
          <p style={{ fontSize:22, fontWeight:800, color:'#7c3aed', letterSpacing:'-0.5px' }}>${totalMonthly.toLocaleString('en-AU', { minimumFractionDigits:2, maximumFractionDigits:2 })}</p>
        </div>
      </div>

      {recurring.length === 0 ? (
        <div style={{ background:'#faf5ff', border:'1.5px dashed #ddd6fe', borderRadius:14, padding:'28px 24px', textAlign:'center' }}>
          <RefreshCw size={28} color="#c4b5fd" style={{ marginBottom:10 }} />
          <p style={{ fontSize:14, fontWeight:600, color:'#7c3aed', marginBottom:4 }}>No recurring payments yet</p>
          <p style={{ fontSize:12, color:'#a78bfa' }}>Enable "Monthly Recurring Payment" on any lead to track retainer clients here.</p>
        </div>
      ) : (
        <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fill, minmax(300px, 1fr))', gap:12 }}>
          {recurring.map(lead => {
            const days = daysUntil(lead.recurringNextDate)
            const color = urgencyColor(days)
            return (
              <div key={lead.id} style={{ background:'#fff', border:'1.5px solid #ede9fe', borderRadius:14, padding:'16px 18px', boxShadow:'0 2px 8px rgba(124,58,237,0.06)', transition:'box-shadow 0.15s' }}
                onMouseEnter={e=>e.currentTarget.style.boxShadow='0 4px 16px rgba(124,58,237,0.14)'}
                onMouseLeave={e=>e.currentTarget.style.boxShadow='0 2px 8px rgba(124,58,237,0.06)'}>
                <div style={{ display:'flex', alignItems:'flex-start', justifyContent:'space-between', marginBottom:12 }}>
                  <div style={{ display:'flex', alignItems:'center', gap:10 }}>
                    <div style={{ width:36, height:36, borderRadius:'50%', background:'linear-gradient(135deg,#7c3aed,#a78bfa)', display:'flex', alignItems:'center', justifyContent:'center', color:'#fff', fontSize:14, fontWeight:700, flexShrink:0 }}>
                      {lead.name?.charAt(0)}
                    </div>
                    <div>
                      <p style={{ fontWeight:700, color:'#0f172a', fontSize:13 }}>{lead.name}</p>
                      <p style={{ fontSize:11, color:'#94a3b8' }}>{lead.service || '—'}</p>
                    </div>
                  </div>
                  <div style={{ textAlign:'right' }}>
                    <p style={{ fontSize:18, fontWeight:800, color:'#7c3aed', letterSpacing:'-0.4px' }}>
                      ${(lead.recurringAmount || 0).toLocaleString('en-AU', { minimumFractionDigits:2 })}
                    </p>
                    <p style={{ fontSize:10, color:'#a78bfa', fontWeight:600 }}>/ month</p>
                  </div>
                </div>

                {lead.recurringNextDate && (
                  <div style={{ display:'flex', alignItems:'center', gap:6, background: days !== null && days <= 3 ? 'rgba(220,38,38,0.06)' : days !== null && days <= 7 ? 'rgba(180,83,9,0.06)' : 'rgba(5,150,105,0.06)', borderRadius:8, padding:'6px 10px', marginBottom:10 }}>
                    <Calendar size={12} color={color} />
                    <p style={{ fontSize:11, color, fontWeight:600 }}>
                      Next payment: {new Date(lead.recurringNextDate).toLocaleDateString('en-AU', { day:'numeric', month:'short', year:'numeric' })}
                      {days !== null && <span style={{ marginLeft:6, opacity:0.8 }}>({days === 0 ? 'Today' : days < 0 ? `${Math.abs(days)}d overdue` : `in ${days}d`})</span>}
                    </p>
                  </div>
                )}

                {lead.recurringNotes && (
                  <p style={{ fontSize:11, color:'#64748b', marginBottom:10, lineHeight:1.5, borderTop:'1px solid #f3f0ff', paddingTop:8 }}>{lead.recurringNotes}</p>
                )}

                <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', borderTop:'1px solid #f3f0ff', paddingTop:10 }}>
                  <Badge label={lead.paymentStatus} map={PAYMENT_STYLE} />
                  <button onClick={()=>onEdit(lead)}
                    style={{ display:'flex', alignItems:'center', gap:4, fontSize:11, fontWeight:700, color:'#7c3aed', background:'rgba(124,58,237,0.08)', border:'1px solid #ede9fe', borderRadius:8, padding:'4px 10px', cursor:'pointer' }}>
                    <Pencil size={11}/> Edit
                  </button>
                </div>
              </div>
            )
          })}
        </div>
      )}
    </div>
  )
}

export default function Leads() {
  const { getLeads, addLead, updateLead, deleteLead, currentUser } = useApp()
  const leads = getLeads()
  const [search, setSearch] = useState('')
  const [filterStatus, setFilterStatus] = useState('')
  const [activeTab, setActiveTab] = useState('all') // 'all' | 'recurring'
  const [showAdd, setShowAdd] = useState(false)
  const [view, setView] = useState(null)
  const [edit, setEdit] = useState(null)

  const filtered = leads.filter(l => {
    const q = search.toLowerCase()
    const matchSearch = !q || l.name?.toLowerCase().includes(q) || l.service?.toLowerCase().includes(q) || l.email?.toLowerCase().includes(q)
    const matchStatus = !filterStatus || l.status === filterStatus
    const matchTab = activeTab === 'recurring' ? l.isRecurring : true
    return matchSearch && matchStatus && matchTab
  })

  const recurringCount = leads.filter(l => l.isRecurring).length

  const handleEdit = (data) => {
    updateLead(edit.id, {
      ...data,
      jobValue: Number(data.jobValue) || 0,
      recurringAmount: Number(data.recurringAmount) || 0,
      recurringNextDate: data.recurringNextDate || null,
    })
    setEdit(null)
  }

  const thStyle = { textAlign:'left', padding:'11px 18px', fontSize:11, fontWeight:700, color:'#94a3b8', textTransform:'uppercase', letterSpacing:'0.06em', whiteSpace:'nowrap' }
  const tdStyle = { padding:'13px 18px', fontSize:13 }

  return (
    <div style={{ padding:28, minHeight:'100%' }}>
      <div style={{ display:'flex', alignItems:'flex-start', justifyContent:'space-between', marginBottom:22 }}>
        <div>
          <h1 style={{ fontSize:20, fontWeight:800, color:'#0f172a', letterSpacing:'-0.3px' }}>Leads</h1>
          <p style={{ fontSize:13, color:'#94a3b8', marginTop:3 }}>{leads.length} total leads</p>
        </div>
        <button onClick={() => setShowAdd(true)} style={{ display:'flex', alignItems:'center', gap:7, background:'#0ea5e9', color:'#fff', border:'none', borderRadius:11, padding:'9px 16px', fontSize:13, fontWeight:700, cursor:'pointer', boxShadow:'0 4px 12px rgba(14,165,233,0.3)' }}>
          <Plus size={15} /> Add Lead
        </button>
      </div>

      {/* Tabs */}
      <div style={{ display:'flex', gap:4, marginBottom:18, background:'#f1f5f9', borderRadius:12, padding:4, width:'fit-content' }}>
        {[
          { id:'all', label:'All Leads', count: leads.length },
          { id:'recurring', label:'Recurring', count: recurringCount, icon: <RefreshCw size={12}/> },
        ].map(tab => (
          <button key={tab.id} onClick={()=>setActiveTab(tab.id)}
            style={{ display:'flex', alignItems:'center', gap:6, padding:'7px 16px', borderRadius:9, border:'none', cursor:'pointer', fontSize:13, fontWeight:700, transition:'all 0.15s',
              background: activeTab === tab.id ? '#fff' : 'transparent',
              color: activeTab === tab.id ? '#0f172a' : '#64748b',
              boxShadow: activeTab === tab.id ? '0 1px 4px rgba(0,0,0,0.1)' : 'none',
            }}>
            {tab.icon}
            {tab.label}
            <span style={{ fontSize:11, fontWeight:700, background: activeTab === tab.id ? (tab.id === 'recurring' ? '#7c3aed' : '#0ea5e9') : '#cbd5e1', color:'#fff', borderRadius:20, padding:'1px 7px', minWidth:18, textAlign:'center' }}>
              {tab.count}
            </span>
          </button>
        ))}
      </div>

      {/* Recurring section (shown when tab = recurring) */}
      {activeTab === 'recurring' && (
        <RecurringSection leads={leads} onEdit={(lead) => setEdit(lead)} />
      )}

      {/* Filters */}
      <div style={{ display:'flex', gap:10, marginBottom:18, flexWrap:'wrap' }}>
        <div style={{ position:'relative', flex:1, minWidth:200 }}>
          <Search size={14} style={{ position:'absolute', left:12, top:'50%', transform:'translateY(-50%)', color:'#94a3b8' }} />
          <input value={search} onChange={e=>setSearch(e.target.value)} placeholder={activeTab === 'recurring' ? 'Search recurring leads…' : 'Search leads…'} style={{ ...inputStyle, paddingLeft:36, boxShadow:'0 1px 3px rgba(0,0,0,0.06)' }} />
        </div>
        <div style={{ position:'relative' }}>
          <Filter size={13} style={{ position:'absolute', left:12, top:'50%', transform:'translateY(-50%)', color:'#94a3b8' }} />
          <select value={filterStatus} onChange={e=>setFilterStatus(e.target.value)} style={{ ...inputStyle, paddingLeft:32, paddingRight:32, cursor:'pointer', boxShadow:'0 1px 3px rgba(0,0,0,0.06)', minWidth:160 }}>
            <option value="">All Statuses</option>
            {STATUSES.map(s=><option key={s}>{s}</option>)}
          </select>
        </div>
      </div>

      {/* Table */}
      <div style={{ background:'#fff', borderRadius:16, boxShadow:'0 1px 3px rgba(0,0,0,0.06)', border:'1px solid #eaecf0', overflow:'hidden' }}>
        <div style={{ overflowX:'auto' }}>
          <table style={{ width:'100%', borderCollapse:'collapse' }}>
            <thead style={{ background:'#f8fafc', borderBottom:'1px solid #eaecf0' }}>
              <tr>
                <th style={thStyle}>Contact</th>
                <th style={thStyle}>Service</th>
                <th style={thStyle}>Job Value</th>
                {activeTab === 'recurring' && <th style={thStyle}>Monthly</th>}
                <th style={thStyle}>Status</th>
                <th style={thStyle}>Payment</th>
                <th style={thStyle}>Date</th>
                <th style={thStyle}>Actions</th>
              </tr>
            </thead>
            <tbody>
              {filtered.length === 0 && (
                <tr><td colSpan={activeTab === 'recurring' ? 8 : 7} style={{ textAlign:'center', padding:48, color:'#94a3b8', fontSize:13 }}>No leads found</td></tr>
              )}
              {filtered.map((lead, i) => (
                <tr key={lead.id} style={{ borderBottom: i < filtered.length-1 ? '1px solid #f8fafc' : 'none' }}
                  onMouseEnter={e=>e.currentTarget.style.background='#fafbfc'}
                  onMouseLeave={e=>e.currentTarget.style.background='transparent'}>
                  <td style={tdStyle}>
                    <div style={{ display:'flex', alignItems:'center', gap:10 }}>
                      <div style={{ width:32, height:32, borderRadius:'50%', background: lead.isRecurring ? 'linear-gradient(135deg,#7c3aed,#a78bfa)' : 'linear-gradient(135deg,#2563eb,#7c3aed)', display:'flex', alignItems:'center', justifyContent:'center', color:'#fff', fontSize:12, fontWeight:700, flexShrink:0 }}>
                        {lead.name?.charAt(0)}
                      </div>
                      <div>
                        <div style={{ display:'flex', alignItems:'center', gap:6 }}>
                          <p style={{ fontWeight:600, color:'#0f172a', lineHeight:1.3 }}>{lead.name}</p>
                          {lead.isRecurring && (
                            <span title="Monthly recurring" style={{ display:'inline-flex', alignItems:'center', gap:3, background:'rgba(124,58,237,0.1)', color:'#7c3aed', fontSize:10, fontWeight:700, padding:'1px 6px', borderRadius:6 }}>
                              <RefreshCw size={9}/> recurring
                            </span>
                          )}
                        </div>
                        <p style={{ fontSize:11, color:'#94a3b8' }}>{lead.email}</p>
                      </div>
                    </div>
                  </td>
                  <td style={{ ...tdStyle, color:'#475569' }}>{lead.service}</td>
                  <td style={{ ...tdStyle, fontWeight:700, color: lead.jobValue ? '#059669' : '#94a3b8' }}>
                    {lead.jobValue ? `$${Number(lead.jobValue).toLocaleString()}` : '—'}
                  </td>
                  {activeTab === 'recurring' && (
                    <td style={{ ...tdStyle, fontWeight:700, color: lead.recurringAmount ? '#7c3aed' : '#94a3b8' }}>
                      {lead.recurringAmount ? `$${Number(lead.recurringAmount).toLocaleString()}/mo` : '—'}
                    </td>
                  )}
                  <td style={tdStyle}><Badge label={lead.status} map={STATUS_STYLE} /></td>
                  <td style={tdStyle}><Badge label={lead.paymentStatus} map={PAYMENT_STYLE} /></td>
                  <td style={{ ...tdStyle, color:'#94a3b8', fontSize:12 }}>{lead.dateSubmitted}</td>
                  <td style={{ ...tdStyle }}>
                    <div style={{ display:'flex', alignItems:'center', gap:4 }}>
                      <button title="View" onClick={()=>setView(lead)}
                        style={{ width:28, height:28, display:'flex', alignItems:'center', justifyContent:'center', background:'#f8fafc', border:'1px solid #eaecf0', borderRadius:8, cursor:'pointer', color:'#94a3b8' }}
                        onMouseEnter={e=>{ e.currentTarget.style.background='#f0f9ff'; e.currentTarget.style.color='#0ea5e9'; e.currentTarget.style.borderColor='#bae6fd' }}
                        onMouseLeave={e=>{ e.currentTarget.style.background='#f8fafc'; e.currentTarget.style.color='#94a3b8'; e.currentTarget.style.borderColor='#eaecf0' }}>
                        <Eye size={13}/>
                      </button>
                      <button title="Edit" onClick={()=>setEdit(lead)}
                        style={{ width:28, height:28, display:'flex', alignItems:'center', justifyContent:'center', background:'#f8fafc', border:'1px solid #eaecf0', borderRadius:8, cursor:'pointer', color:'#94a3b8' }}
                        onMouseEnter={e=>{ e.currentTarget.style.background='#fefce8'; e.currentTarget.style.color='#ca8a04'; e.currentTarget.style.borderColor='#fde68a' }}
                        onMouseLeave={e=>{ e.currentTarget.style.background='#f8fafc'; e.currentTarget.style.color='#94a3b8'; e.currentTarget.style.borderColor='#eaecf0' }}>
                        <Pencil size={13}/>
                      </button>
                      <button title="Mark Contacted" onClick={()=>updateLead(lead.id,{status:'Contacted'})}
                        style={{ width:28, height:28, display:'flex', alignItems:'center', justifyContent:'center', background:'#f8fafc', border:'1px solid #eaecf0', borderRadius:8, cursor:'pointer', color:'#94a3b8' }}
                        onMouseEnter={e=>{ e.currentTarget.style.background='#f0fdf4'; e.currentTarget.style.color='#16a34a'; e.currentTarget.style.borderColor='#bbf7d0' }}
                        onMouseLeave={e=>{ e.currentTarget.style.background='#f8fafc'; e.currentTarget.style.color='#94a3b8'; e.currentTarget.style.borderColor='#eaecf0' }}>
                        <Phone size={13}/>
                      </button>
                      <button title="Mark Completed" onClick={()=>updateLead(lead.id,{status:'Completed'})}
                        style={{ width:28, height:28, display:'flex', alignItems:'center', justifyContent:'center', background:'#f8fafc', border:'1px solid #eaecf0', borderRadius:8, cursor:'pointer', color:'#94a3b8' }}
                        onMouseEnter={e=>{ e.currentTarget.style.background='#ecfdf5'; e.currentTarget.style.color='#059669'; e.currentTarget.style.borderColor='#6ee7b7' }}
                        onMouseLeave={e=>{ e.currentTarget.style.background='#f8fafc'; e.currentTarget.style.color='#94a3b8'; e.currentTarget.style.borderColor='#eaecf0' }}>
                        <CheckCircle size={13}/>
                      </button>
                      <DeleteButton onConfirm={() => deleteLead(lead.id)} />
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add Modal */}
      {showAdd && (
        <Modal title="Add New Lead" onClose={()=>setShowAdd(false)}>
          <LeadForm
            onSubmit={data=>{ addLead({...data, jobValue:Number(data.jobValue)||0, recurringAmount:Number(data.recurringAmount)||0}); setShowAdd(false) }}
            onClose={()=>setShowAdd(false)}
            submitLabel="Add Lead"
          />
        </Modal>
      )}

      {/* Edit Modal */}
      {edit && (
        <Modal title="Edit Lead" onClose={()=>setEdit(null)}>
          <LeadForm
            initial={{ ...edit, jobValue: edit.jobValue || '', recurringAmount: edit.recurringAmount || '', recurringNextDate: edit.recurringNextDate || '', recurringNotes: edit.recurringNotes || '' }}
            onSubmit={handleEdit}
            onClose={()=>setEdit(null)}
            submitLabel="Save Changes"
          />
        </Modal>
      )}

      {/* View Modal */}
      {view && (
        <Modal title="Lead Details" onClose={()=>setView(null)}>
          <div style={{ display:'flex', flexDirection:'column', gap:16 }}>
            <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:12 }}>
              {[['Name',view.name],['Phone',view.phone],['Email',view.email],['Service',view.service]].map(([l,v])=>(
                <div key={l} style={{ background:'#f8fafc', borderRadius:10, padding:'10px 14px' }}>
                  <p style={{ fontSize:11, color:'#94a3b8', fontWeight:600, marginBottom:3 }}>{l}</p>
                  <p style={{ fontSize:13, color:'#0f172a', fontWeight:500 }}>{v||'—'}</p>
                </div>
              ))}
            </div>
            <div style={{ background:'#f8fafc', borderRadius:10, padding:'10px 14px' }}>
              <p style={{ fontSize:11, color:'#94a3b8', fontWeight:600, marginBottom:3 }}>Message</p>
              <p style={{ fontSize:13, color:'#0f172a' }}>{view.message||'—'}</p>
            </div>
            <div style={{ display:'grid', gridTemplateColumns:'repeat(3,1fr)', gap:10 }}>
              <div style={{ background:'#f0f9ff', borderRadius:12, padding:'12px 14px' }}>
                <p style={{ fontSize:11, color:'#93c5fd', fontWeight:600 }}>Job Value</p>
                <p style={{ fontSize:20, fontWeight:800, color:'#0284c7', marginTop:2 }}>{view.jobValue?`$${Number(view.jobValue).toLocaleString()}`:'—'}</p>
              </div>
              <div style={{ background:'#f8fafc', borderRadius:12, padding:'12px 14px' }}>
                <p style={{ fontSize:11, color:'#94a3b8', fontWeight:600 }}>Status</p>
                <div style={{ marginTop:6 }}><Badge label={view.status} map={STATUS_STYLE} /></div>
              </div>
              <div style={{ background:'#f8fafc', borderRadius:12, padding:'12px 14px' }}>
                <p style={{ fontSize:11, color:'#94a3b8', fontWeight:600 }}>Payment</p>
                <div style={{ marginTop:6 }}><Badge label={view.paymentStatus} map={PAYMENT_STYLE} /></div>
              </div>
            </div>

            {/* Recurring info in view modal */}
            {view.isRecurring && (
              <div style={{ background:'linear-gradient(135deg,#fdf4ff,#f5f3ff)', border:'1.5px solid #e9d5ff', borderRadius:14, padding:'14px 16px' }}>
                <div style={{ display:'flex', alignItems:'center', gap:7, marginBottom:12 }}>
                  <RefreshCw size={14} color="#7c3aed"/>
                  <p style={{ fontSize:12, fontWeight:700, color:'#6d28d9', textTransform:'uppercase', letterSpacing:'0.06em' }}>Monthly Recurring</p>
                </div>
                <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:10 }}>
                  <div style={{ background:'rgba(255,255,255,0.7)', borderRadius:10, padding:'10px 12px' }}>
                    <p style={{ fontSize:11, color:'#a78bfa', fontWeight:600, marginBottom:3 }}>Monthly Amount</p>
                    <p style={{ fontSize:18, fontWeight:800, color:'#7c3aed' }}>${(view.recurringAmount||0).toLocaleString('en-AU', { minimumFractionDigits:2 })}</p>
                  </div>
                  <div style={{ background:'rgba(255,255,255,0.7)', borderRadius:10, padding:'10px 12px' }}>
                    <p style={{ fontSize:11, color:'#a78bfa', fontWeight:600, marginBottom:3 }}>Next Payment</p>
                    <p style={{ fontSize:13, fontWeight:700, color:'#6d28d9' }}>
                      {view.recurringNextDate ? new Date(view.recurringNextDate).toLocaleDateString('en-AU', { day:'numeric', month:'short', year:'numeric' }) : '—'}
                    </p>
                  </div>
                </div>
                {view.recurringNotes && (
                  <p style={{ fontSize:12, color:'#7c3aed', marginTop:10, paddingTop:10, borderTop:'1px solid #ede9fe' }}>{view.recurringNotes}</p>
                )}
              </div>
            )}

            <div>
              <p style={{ fontSize:11, fontWeight:700, color:'#64748b', textTransform:'uppercase', letterSpacing:'0.06em', marginBottom:8 }}>Update Status</p>
              <div style={{ display:'flex', flexWrap:'wrap', gap:6 }}>
                {STATUSES.map(s=>(
                  <button key={s} onClick={()=>{updateLead(view.id,{status:s}); setView(p=>({...p,status:s}))}}
                    style={{ fontSize:12, padding:'5px 12px', borderRadius:8, fontWeight:600, cursor:'pointer', border: view.status===s ? '2px solid #2563eb' : '1px solid #e2e8f0', background: view.status===s ? '#0ea5e9' : '#fff', color: view.status===s ? '#fff' : '#475569' }}>
                    {s}
                  </button>
                ))}
              </div>
            </div>
            <div>
              <p style={{ fontSize:11, fontWeight:700, color:'#64748b', textTransform:'uppercase', letterSpacing:'0.06em', marginBottom:8 }}>Update Payment</p>
              <div style={{ display:'flex', gap:6 }}>
                {PAYMENT_STATUSES.map(s=>(
                  <button key={s} onClick={()=>{updateLead(view.id,{paymentStatus:s}); setView(p=>({...p,paymentStatus:s}))}}
                    style={{ fontSize:12, padding:'5px 14px', borderRadius:8, fontWeight:600, cursor:'pointer', border: view.paymentStatus===s ? '2px solid #2563eb' : '1px solid #e2e8f0', background: view.paymentStatus===s ? '#0ea5e9' : '#fff', color: view.paymentStatus===s ? '#fff' : '#475569' }}>
                    {s}
                  </button>
                ))}
              </div>
            </div>
            <button onClick={()=>{ setView(null); setEdit(view) }}
              style={{ display:'flex', alignItems:'center', justifyContent:'center', gap:7, padding:'10px', borderRadius:10, border:'1px solid #e2e8f0', background:'#fff', fontSize:13, fontWeight:600, color:'#374151', cursor:'pointer' }}>
              <Pencil size={14}/> Edit Full Details
            </button>
          </div>
        </Modal>
      )}
    </div>
  )
}
