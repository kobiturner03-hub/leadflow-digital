import { useState, useEffect } from 'react'
import { useParams } from 'react-router-dom'
import { supabase } from '../lib/supabase'
import { CheckCircle, AlertTriangle, Send, Phone, Mail, User, MessageSquare, Briefcase, ChevronDown } from 'lucide-react'

const SERVICES_DEFAULT = [
  'General Enquiry','Quote Request','Repair / Fix','Installation','Maintenance',
  'Inspection','Consultation','Emergency Call-out','Other',
]

const inputBase = {
  width: '100%', padding: '11px 14px 11px 40px', borderRadius: 11,
  border: '1px solid #e2e8f0', fontSize: 14, outline: 'none',
  fontFamily: 'Inter,-apple-system,sans-serif', color: '#0f172a',
  background: '#fff', boxSizing: 'border-box', transition: 'border-color 0.15s, box-shadow 0.15s',
}

function Field({ icon: Icon, label, children }) {
  return (
    <div>
      <label style={{ display:'block', fontSize:13, fontWeight:600, color:'#374151', marginBottom:6 }}>{label}</label>
      <div style={{ position:'relative' }}>
        <Icon size={15} style={{ position:'absolute', left:13, top:'50%', transform:'translateY(-50%)', color:'#94a3b8', pointerEvents:'none' }}/>
        {children}
      </div>
    </div>
  )
}

export default function LeadForm() {
  const { businessId } = useParams()
  const [biz,     setBiz]     = useState(null)
  const [loading, setLoading] = useState(true)
  const [notFound, setNotFound] = useState(false)
  const [submitted, setSubmitted] = useState(false)
  const [submitting, setSubmitting] = useState(false)
  const [error, setError] = useState('')
  const [form, setForm] = useState({
    name: '', phone: '', email: '', service: '', message: '',
  })

  useEffect(() => {
    if (!businessId) { setNotFound(true); setLoading(false); return }
    supabase
      .from('businesses')
      .select('id, name, phone, email, industry')
      .eq('id', businessId)
      .single()
      .then(({ data, error }) => {
        if (error || !data) { setNotFound(true) }
        else { setBiz(data) }
        setLoading(false)
      })
  }, [businessId])

  const set = (k, v) => setForm(p => ({ ...p, [k]: v }))
  const focus = e => { e.target.style.borderColor='#0ea5e9'; e.target.style.boxShadow='0 0 0 3px rgba(14,165,233,0.1)' }
  const blur  = e => { e.target.style.borderColor='#e2e8f0'; e.target.style.boxShadow='none' }

  const handleSubmit = async (e) => {
    e.preventDefault()
    if (!form.name || !form.phone || !form.service) {
      setError('Please fill in your name, phone, and service type.')
      return
    }
    setSubmitting(true)
    setError('')
    const today = new Date().toISOString().split('T')[0]
    const { error: insertErr } = await supabase.from('leads').insert({
      name:           form.name.trim(),
      phone:          form.phone.trim(),
      email:          form.email.trim() || null,
      service:        form.service,
      message:        form.message.trim() || null,
      status:         'New Lead',
      payment_status: 'Unpaid',
      job_value:      0,
      date_submitted: today,
      business_id:    Number(businessId),
    })
    if (insertErr) {
      setError('Something went wrong. Please try again or call us directly.')
      setSubmitting(false)
      return
    }
    setSubmitted(true)
    setSubmitting(false)
  }

  // ── Loading ──
  if (loading) return (
    <div style={{ minHeight:'100vh', background:'#f8fafc', display:'flex', alignItems:'center', justifyContent:'center' }}>
      <div style={{ width:36, height:36, border:'3px solid #e2e8f0', borderTopColor:'#0ea5e9', borderRadius:'50%', animation:'spin 0.8s linear infinite' }}/>
      <style>{`@keyframes spin{to{transform:rotate(360deg)}}`}</style>
    </div>
  )

  // ── Not found ──
  if (notFound) return (
    <div style={{ minHeight:'100vh', background:'#f8fafc', display:'flex', alignItems:'center', justifyContent:'center', padding:24 }}>
      <div style={{ textAlign:'center', maxWidth:360 }}>
        <div style={{ width:56, height:56, borderRadius:16, background:'#fef2f2', display:'flex', alignItems:'center', justifyContent:'center', margin:'0 auto 16px' }}>
          <AlertTriangle size={24} color="#ef4444"/>
        </div>
        <h2 style={{ fontSize:18, fontWeight:800, color:'#0f172a', marginBottom:8 }}>Form not found</h2>
        <p style={{ fontSize:14, color:'#64748b', lineHeight:1.6 }}>This lead capture form link is invalid or has been removed.</p>
      </div>
    </div>
  )

  // ── Submitted ──
  if (submitted) return (
    <div style={{ minHeight:'100vh', background:'linear-gradient(160deg,#f0f9ff,#f8fafc)', display:'flex', alignItems:'center', justifyContent:'center', padding:24 }}>
      <div style={{ textAlign:'center', maxWidth:400, background:'#fff', borderRadius:24, padding:'48px 36px', boxShadow:'0 8px 40px rgba(0,0,0,0.1)' }}>
        <div style={{ width:72, height:72, borderRadius:22, background:'linear-gradient(135deg,rgba(16,185,129,0.12),rgba(5,150,105,0.08))', display:'flex', alignItems:'center', justifyContent:'center', margin:'0 auto 20px' }}>
          <CheckCircle size={36} color="#10b981"/>
        </div>
        <h2 style={{ fontSize:22, fontWeight:800, color:'#0f172a', marginBottom:10, letterSpacing:'-0.3px' }}>Enquiry received!</h2>
        <p style={{ fontSize:15, color:'#64748b', lineHeight:1.7, marginBottom:8 }}>
          Thanks <strong>{form.name.split(' ')[0]}</strong>! We've received your enquiry and will be in touch with you shortly.
        </p>
        {biz?.phone && (
          <p style={{ fontSize:13, color:'#94a3b8', marginTop:16 }}>
            Need urgent help? Call us on <a href={`tel:${biz.phone}`} style={{ color:'#0ea5e9', fontWeight:600, textDecoration:'none' }}>{biz.phone}</a>
          </p>
        )}
        <div style={{ marginTop:28, padding:'14px 18px', background:'#f8fafc', borderRadius:12, border:'1px solid #eaecf0' }}>
          <p style={{ fontSize:12, color:'#94a3b8' }}>Powered by <strong style={{ color:'#64748b' }}>LeadFlow Digital</strong></p>
        </div>
      </div>
    </div>
  )

  // ── Form ──
  const accentColor = '#0ea5e9'
  return (
    <div style={{ minHeight:'100vh', background:'linear-gradient(160deg,#f0f9ff 0%,#f8fafc 100%)', display:'flex', alignItems:'flex-start', justifyContent:'center', padding:'40px 16px 60px', fontFamily:'Inter,-apple-system,sans-serif' }}>
      <div style={{ width:'100%', maxWidth:520 }}>

        {/* Header */}
        <div style={{ textAlign:'center', marginBottom:28 }}>
          <div style={{ display:'inline-flex', alignItems:'center', justifyContent:'center', width:52, height:52, borderRadius:16, background:'linear-gradient(135deg,#0284c7,#0ea5e9)', marginBottom:14, boxShadow:'0 8px 24px rgba(14,165,233,0.3)' }}>
            <span style={{ color:'#fff', fontWeight:900, fontSize:18 }}>{biz?.name?.[0]?.toUpperCase() || '?'}</span>
          </div>
          <h1 style={{ fontSize:22, fontWeight:800, color:'#0f172a', letterSpacing:'-0.4px', marginBottom:6 }}>
            {biz?.name || 'Contact Us'}
          </h1>
          <p style={{ fontSize:14, color:'#64748b', lineHeight:1.6 }}>
            Fill in your details below and we'll get back to you as soon as possible.
          </p>
        </div>

        {/* Card */}
        <div style={{ background:'#fff', borderRadius:20, padding:'32px 28px', boxShadow:'0 4px 24px rgba(0,0,0,0.08)', border:'1px solid #eaecf0' }}>
          <form onSubmit={handleSubmit} style={{ display:'flex', flexDirection:'column', gap:18 }}>

            <Field icon={User} label="Full Name *">
              <input
                type="text" value={form.name} onChange={e => set('name', e.target.value)}
                placeholder="Jane Smith" required
                style={inputBase} onFocus={focus} onBlur={blur}
              />
            </Field>

            <Field icon={Phone} label="Phone Number *">
              <input
                type="tel" value={form.phone} onChange={e => set('phone', e.target.value)}
                placeholder="04XX XXX XXX" required
                style={inputBase} onFocus={focus} onBlur={blur}
              />
            </Field>

            <Field icon={Mail} label="Email Address">
              <input
                type="email" value={form.email} onChange={e => set('email', e.target.value)}
                placeholder="jane@example.com"
                style={inputBase} onFocus={focus} onBlur={blur}
              />
            </Field>

            <Field icon={Briefcase} label="Service Required *">
              <div style={{ position:'relative' }}>
                <select
                  value={form.service} onChange={e => set('service', e.target.value)} required
                  style={{ ...inputBase, appearance:'none', cursor:'pointer' }}
                  onFocus={focus} onBlur={blur}
                >
                  <option value="">Select a service…</option>
                  {SERVICES_DEFAULT.map(s => <option key={s} value={s}>{s}</option>)}
                </select>
                <ChevronDown size={14} style={{ position:'absolute', right:12, top:'50%', transform:'translateY(-50%)', color:'#94a3b8', pointerEvents:'none' }}/>
              </div>
            </Field>

            <div>
              <label style={{ display:'block', fontSize:13, fontWeight:600, color:'#374151', marginBottom:6 }}>
                Additional Details
              </label>
              <div style={{ position:'relative' }}>
                <MessageSquare size={15} style={{ position:'absolute', left:13, top:13, color:'#94a3b8', pointerEvents:'none' }}/>
                <textarea
                  value={form.message} onChange={e => set('message', e.target.value)}
                  placeholder="Tell us a bit more about what you need…"
                  rows={4}
                  style={{ ...inputBase, paddingTop:11, paddingLeft:40, resize:'vertical', lineHeight:1.6 }}
                  onFocus={focus} onBlur={blur}
                />
              </div>
            </div>

            {error && (
              <div style={{ background:'#fef2f2', border:'1px solid #fecaca', borderRadius:10, padding:'10px 14px', display:'flex', gap:9, alignItems:'center' }}>
                <AlertTriangle size={14} color="#ef4444" style={{ flexShrink:0 }}/>
                <p style={{ fontSize:13, color:'#dc2626', fontWeight:500 }}>{error}</p>
              </div>
            )}

            <button type="submit" disabled={submitting} style={{
              width:'100%', padding:'13px', borderRadius:12, border:'none',
              background: submitting ? 'rgba(14,165,233,0.7)' : 'linear-gradient(135deg,#0284c7,#0ea5e9)',
              color:'#fff', fontSize:15, fontWeight:700, cursor: submitting ? 'not-allowed' : 'pointer',
              display:'flex', alignItems:'center', justifyContent:'center', gap:9,
              boxShadow:'0 4px 16px rgba(14,165,233,0.35)', marginTop:4,
            }}>
              {submitting
                ? <><div style={{ width:16, height:16, border:'2px solid rgba(255,255,255,0.35)', borderTopColor:'#fff', borderRadius:'50%', animation:'spin 0.7s linear infinite' }}/> Submitting…</>
                : <><Send size={15}/> Send Enquiry</>
              }
            </button>
          </form>

          <p style={{ textAlign:'center', fontSize:12, color:'#94a3b8', marginTop:20 }}>
            Your information is kept private and secure.
          </p>
        </div>

        {/* Contact details */}
        {(biz?.phone || biz?.email) && (
          <div style={{ marginTop:20, background:'#fff', border:'1px solid #eaecf0', borderRadius:14, padding:'16px 22px', display:'flex', gap:20, justifyContent:'center', flexWrap:'wrap' }}>
            {biz.phone && (
              <a href={`tel:${biz.phone}`} style={{ display:'flex', alignItems:'center', gap:7, textDecoration:'none', color:'#374151' }}>
                <div style={{ width:30, height:30, borderRadius:8, background:'rgba(14,165,233,0.08)', display:'flex', alignItems:'center', justifyContent:'center' }}>
                  <Phone size={13} color={accentColor}/>
                </div>
                <span style={{ fontSize:13, fontWeight:600 }}>{biz.phone}</span>
              </a>
            )}
            {biz.email && (
              <a href={`mailto:${biz.email}`} style={{ display:'flex', alignItems:'center', gap:7, textDecoration:'none', color:'#374151' }}>
                <div style={{ width:30, height:30, borderRadius:8, background:'rgba(14,165,233,0.08)', display:'flex', alignItems:'center', justifyContent:'center' }}>
                  <Mail size={13} color={accentColor}/>
                </div>
                <span style={{ fontSize:13, fontWeight:600 }}>{biz.email}</span>
              </a>
            )}
          </div>
        )}

        <p style={{ textAlign:'center', fontSize:11, color:'rgba(0,0,0,0.25)', marginTop:20 }}>
          Powered by LeadFlow Digital
        </p>
      </div>
      <style>{`@keyframes spin{to{transform:rotate(360deg)}}`}</style>
    </div>
  )
}
