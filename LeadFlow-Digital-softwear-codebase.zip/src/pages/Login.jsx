import { useState, useEffect } from 'react'
import { useNavigate, Link } from 'react-router-dom'
import { useApp } from '../context/AppContext'
import { supabase } from '../lib/supabase'
import { Eye, EyeOff, LogIn, TrendingUp, Users, Zap, MailCheck, AlertTriangle, KeyRound, CheckCircle, User } from 'lucide-react'

const features = [
  { icon: TrendingUp, text: 'Revenue tracking & analytics' },
  { icon: Users,      text: 'Lead pipeline management' },
  { icon: Zap,        text: 'Automated email & SMS sequences' },
]

const inputStyle = {
  width: '100%', padding: '10px 14px', borderRadius: 11,
  border: '1px solid #e2e8f0', fontSize: 13, outline: 'none',
  fontFamily: 'Inter,sans-serif', color: '#0f172a', background: '#fff',
  boxSizing: 'border-box', transition: 'border-color 0.15s',
}

export default function Login() {
  const { login }  = useApp()
  const navigate   = useNavigate()

  // Sign-in state
  const [email,    setEmail]    = useState('')
  const [password, setPassword] = useState('')
  const [showPw,   setShowPw]   = useState(false)
  const [error,    setError]    = useState('')
  const [loading,  setLoading]  = useState(false)

  // Forgot password state
  const [forgotMode,   setForgotMode]   = useState(false)
  const [resetEmail,   setResetEmail]   = useState('')
  const [resetSent,    setResetSent]    = useState(false)
  const [resetLoading, setResetLoading] = useState(false)

  // Password recovery (after clicking reset link in email)
  const [recoveryMode,    setRecoveryMode]    = useState(false)
  const [completeMode,    setCompleteMode]    = useState(false)
  const [completeSession, setCompleteSession] = useState(null)
  const [completeForm,    setCompleteForm]    = useState({ fullName:'', businessName:'', phone:'', industry:'' })
  const [completeLoading, setCompleteLoading] = useState(false)
  const [completeError,   setCompleteError]   = useState('')
  const [newPw,        setNewPw]        = useState('')
  const [newPwConfirm, setNewPwConfirm] = useState('')
  const [showNewPw,    setShowNewPw]    = useState(false)
  const [pwSaving,     setPwSaving]     = useState(false)
  const [pwSaved,      setPwSaved]      = useState(false)
  const [pwError,      setPwError]      = useState('')

  // Link error (expired OTP etc.)
  const [linkError, setLinkError] = useState(null)

  // Detect password recovery via Supabase auth event (handles both hash and PKCE flows)
  useEffect(() => {
    // Let Supabase process the URL tokens first, then listen for the event
    const { data: { subscription } } = supabase.auth.onAuthStateChange((event) => {
      if (event === 'PASSWORD_RECOVERY') {
        setRecoveryMode(true)
      }
    })

    // Also check hash for error codes (expired link etc.)
    const hash = window.location.hash
    if (hash) {
      const params = new URLSearchParams(hash.replace(/^#/, ''))
      const errCode = params.get('error_code') || params.get('error')
      if (errCode) {
        window.history.replaceState(null, '', window.location.pathname)
        setLinkError(errCode === 'otp_expired' || errCode === 'access_denied' ? 'expired' : 'generic')
      }
    }

    return () => subscription.unsubscribe()
  }, [])

  // ── Handlers ────────────────────────────────────────────────────────────────
  const handleSubmit = async (e) => {
    e.preventDefault()
    setLoading(true); setError('')
    const result = await login(email, password)
    if (result === true) {
      navigate('/dashboard')
    } else if (result === 'disabled') {
      setError('This account has been disabled. Please contact LeadFlow Digital.')
      setLoading(false)
    } else if (result === 'no_profile') {
      // Get session so we can complete setup
      const { data: { session } } = await supabase.auth.getSession()
      setCompleteSession(session)
      setCompleteMode(true)
      setLoading(false)
    } else {
      setError('Invalid email or password. Please try again.')
      setLoading(false)
    }
  }

  const handleCompleteProfile = async (e) => {
    e.preventDefault()
    const { fullName, businessName, phone, industry } = completeForm
    if (!fullName || !businessName || !phone || !industry) { setCompleteError('All fields are required.'); return }
    setCompleteLoading(true); setCompleteError('')
    try {
      const userId    = completeSession?.user?.id
      const userEmail = completeSession?.user?.email
      const { error: rpcErr } = await supabase.rpc('create_business_and_profile', {
        p_user_id:       userId,
        p_full_name:     fullName,
        p_business_name: businessName,
        p_email:         userEmail,
        p_phone:         phone,
        p_industry:      industry,
      })
      if (rpcErr) throw rpcErr
      const result = await login(email, password)
      if (result === true) { navigate('/dashboard'); return }
    } catch (err) {
      setCompleteError('Could not complete setup: ' + err.message)
    }
    setCompleteLoading(false)
  }

  const handleForgotPassword = async (e) => {
    e.preventDefault()
    setResetLoading(true)
    await supabase.auth.resetPasswordForEmail(resetEmail, {
      redirectTo: window.location.origin + '/reset-password',
    })
    setResetSent(true)
    setResetLoading(false)
  }

  const handleSetNewPassword = async (e) => {
    e.preventDefault()
    setPwError('')
    if (newPw.length < 8) { setPwError('Password must be at least 8 characters.'); return }
    if (newPw !== newPwConfirm) { setPwError('Passwords do not match.'); return }
    setPwSaving(true)
    const { error: err } = await supabase.auth.updateUser({ password: newPw })
    if (err) { setPwError(err.message); setPwSaving(false); return }
    setPwSaved(true)
    setPwSaving(false)
    // Sign out recovery session then show login form after a short delay
    setTimeout(async () => {
      await supabase.auth.signOut()
      setRecoveryMode(false); setPwSaved(false); setNewPw(''); setNewPwConfirm('')
    }, 2500)
  }

  // ── Shared wrappers ─────────────────────────────────────────────────────────
  const Spinner = () => (
    <div style={{ width:16, height:16, border:'2px solid rgba(255,255,255,0.3)', borderTopColor:'#fff', borderRadius:'50%', animation:'spin 0.7s linear infinite' }}/>
  )

  const focusBlue  = e => { e.target.style.borderColor = '#0ea5e9' }
  const blurGrey   = e => { e.target.style.borderColor = '#e2e8f0' }

  // ── Card content ─────────────────────────────────────────────────────────────
  const renderCard = () => {

    // Complete profile mode
    if (completeMode) return (
      <>
        <div style={{ marginBottom:20 }}>
          <div style={{ width:44, height:44, borderRadius:12, background:'rgba(245,158,11,0.1)', display:'flex', alignItems:'center', justifyContent:'center', marginBottom:14 }}>
            <User size={20} color="#f59e0b"/>
          </div>
          <h2 style={{ fontSize:17, fontWeight:800, color:'#0f172a', letterSpacing:'-0.3px' }}>Complete your setup</h2>
          <p style={{ fontSize:12, color:'#94a3b8', marginTop:4 }}>Your account was created but needs a few more details</p>
        </div>
        <form onSubmit={handleCompleteProfile} style={{ display:'flex', flexDirection:'column', gap:13 }}>
          {[
            ['Full Name',      'fullName',      'Jane Smith',          'text'],
            ['Business Name',  'businessName',  'My Business Pty Ltd', 'text'],
            ['Phone Number',   'phone',         '04XX XXX XXX',        'tel'],
          ].map(([label, key, placeholder, type]) => (
            <div key={key}>
              <label style={{ display:'block', fontSize:12, fontWeight:600, color:'#374151', marginBottom:5 }}>{label}</label>
              <input type={type} value={completeForm[key]} onChange={e => setCompleteForm(f => ({ ...f, [key]: e.target.value }))}
                placeholder={placeholder} required
                style={{ width:'100%', padding:'10px 14px', borderRadius:11, border:'1px solid #e2e8f0', fontSize:13, outline:'none', fontFamily:'Inter,sans-serif', color:'#0f172a', background:'#fff', boxSizing:'border-box' }}
                onFocus={e => e.target.style.borderColor='#0ea5e9'} onBlur={e => e.target.style.borderColor='#e2e8f0'}/>
            </div>
          ))}
          <div>
            <label style={{ display:'block', fontSize:12, fontWeight:600, color:'#374151', marginBottom:5 }}>Industry</label>
            <select value={completeForm.industry} onChange={e => setCompleteForm(f => ({ ...f, industry: e.target.value }))} required
              style={{ width:'100%', padding:'10px 14px', borderRadius:11, border:'1px solid #e2e8f0', fontSize:13, outline:'none', fontFamily:'Inter,sans-serif', color:'#0f172a', background:'#fff', boxSizing:'border-box', appearance:'none' }}
              onFocus={e => e.target.style.borderColor='#0ea5e9'} onBlur={e => e.target.style.borderColor='#e2e8f0'}>
              <option value="">Select industry…</option>
              {['Trades & Construction','Beauty & Wellness','Automotive & Mechanical','Cleaning Services','Landscaping & Gardening','Health & Fitness','Real Estate','Hospitality & Food','Education & Tutoring','Retail','Technology & IT','Other'].map(i => <option key={i} value={i}>{i}</option>)}
            </select>
          </div>
          {completeError && (
            <div style={{ background:'#fef2f2', border:'1px solid #fecaca', borderRadius:9, padding:'9px 13px', display:'flex', gap:7, alignItems:'center' }}>
              <div style={{ width:5, height:5, borderRadius:'50%', background:'#ef4444', flexShrink:0 }}/>
              <p style={{ fontSize:12, color:'#dc2626', fontWeight:500 }}>{completeError}</p>
            </div>
          )}
          <button type="submit" disabled={completeLoading}
            style={{ width:'100%', padding:'11px', borderRadius:11, border:'none', background: completeLoading ? 'rgba(14,165,233,0.7)' : 'linear-gradient(135deg,#0284c7,#0ea5e9)', color:'#fff', fontSize:14, fontWeight:700, cursor:'pointer', display:'flex', alignItems:'center', justifyContent:'center', gap:8, marginTop:4 }}>
            {completeLoading ? <div style={{ width:16, height:16, border:'2px solid rgba(255,255,255,0.3)', borderTopColor:'#fff', borderRadius:'50%', animation:'spin 0.7s linear infinite' }}/> : <><LogIn size={15}/> Complete & Sign In</>}
          </button>
        </form>
      </>
    )

    // Password recovery mode
    if (recoveryMode) return (
      <>
        <div style={{ marginBottom:20 }}>
          <div style={{ width:44, height:44, borderRadius:12, background:'rgba(14,165,233,0.1)', display:'flex', alignItems:'center', justifyContent:'center', marginBottom:14 }}>
            <KeyRound size={20} color="#2563eb"/>
          </div>
          <h2 style={{ fontSize:17, fontWeight:800, color:'#0f172a', letterSpacing:'-0.3px' }}>Set a new password</h2>
          <p style={{ fontSize:12, color:'#94a3b8', marginTop:4 }}>Choose a strong password for your account</p>
        </div>
        {pwSaved ? (
          <div style={{ textAlign:'center', padding:'16px 0' }}>
            <CheckCircle size={40} color="#10b981" style={{ margin:'0 auto 12px', display:'block' }}/>
            <p style={{ fontSize:14, fontWeight:700, color:'#0f172a', marginBottom:4 }}>Password updated!</p>
            <p style={{ fontSize:12, color:'#64748b' }}>Redirecting you to sign in…</p>
          </div>
        ) : (
          <form onSubmit={handleSetNewPassword} style={{ display:'flex', flexDirection:'column', gap:14 }}>
            <div>
              <label style={{ display:'block', fontSize:12, fontWeight:600, color:'#374151', marginBottom:6 }}>New password</label>
              <div style={{ position:'relative' }}>
                <input type={showNewPw ? 'text' : 'password'} value={newPw} onChange={e => setNewPw(e.target.value)}
                  required placeholder="Min. 8 characters"
                  style={{ ...inputStyle, paddingRight:42 }} onFocus={focusBlue} onBlur={blurGrey}/>
                <button type="button" onClick={() => setShowNewPw(!showNewPw)}
                  style={{ position:'absolute', right:12, top:'50%', transform:'translateY(-50%)', background:'none', border:'none', cursor:'pointer', color:'#94a3b8', display:'flex', alignItems:'center', padding:0 }}>
                  {showNewPw ? <EyeOff size={15}/> : <Eye size={15}/>}
                </button>
              </div>
            </div>
            <div>
              <label style={{ display:'block', fontSize:12, fontWeight:600, color:'#374151', marginBottom:6 }}>Confirm new password</label>
              <input type="password" value={newPwConfirm} onChange={e => setNewPwConfirm(e.target.value)}
                required placeholder="Re-enter password" style={inputStyle} onFocus={focusBlue} onBlur={blurGrey}/>
            </div>
            {pwError && (
              <div style={{ background:'#fef2f2', border:'1px solid #fecaca', borderRadius:9, padding:'9px 13px', display:'flex', alignItems:'center', gap:7 }}>
                <div style={{ width:5, height:5, borderRadius:'50%', background:'#ef4444', flexShrink:0 }}/>
                <p style={{ fontSize:12, color:'#dc2626', fontWeight:500 }}>{pwError}</p>
              </div>
            )}
            <button type="submit" disabled={pwSaving}
              style={{ width:'100%', padding:'11px', borderRadius:11, border:'none', background: pwSaving ? 'rgba(14,165,233,0.7)' : 'linear-gradient(135deg,#0284c7,#0ea5e9)', color:'#fff', fontSize:14, fontWeight:700, cursor:'pointer', display:'flex', alignItems:'center', justifyContent:'center', gap:8 }}>
              {pwSaving ? <Spinner/> : 'Update Password'}
            </button>
          </form>
        )}
      </>
    )

    // Forgot password mode
    if (forgotMode) return (
      <>
        <div style={{ marginBottom:20 }}>
          <h2 style={{ fontSize:17, fontWeight:800, color:'#0f172a', letterSpacing:'-0.3px' }}>Reset your password</h2>
          <p style={{ fontSize:12, color:'#94a3b8', marginTop:4 }}>Enter your email and we'll send a reset link</p>
        </div>
        {resetSent ? (
          <div style={{ textAlign:'center', padding:'16px 0' }}>
            <div style={{ width:48, height:48, borderRadius:14, background:'rgba(16,185,129,0.1)', display:'flex', alignItems:'center', justifyContent:'center', margin:'0 auto 14px' }}>
              <MailCheck size={22} color="#10b981"/>
            </div>
            <p style={{ fontSize:14, fontWeight:700, color:'#0f172a', marginBottom:6 }}>Check your email</p>
            <p style={{ fontSize:12, color:'#64748b', lineHeight:1.6, marginBottom:16 }}>We've sent a reset link to <strong>{resetEmail}</strong></p>
            <button onClick={() => { setForgotMode(false); setResetSent(false) }}
              style={{ fontSize:13, fontWeight:600, color:'#0ea5e9', background:'none', border:'none', cursor:'pointer' }}>
              Back to sign in
            </button>
          </div>
        ) : (
          <form onSubmit={handleForgotPassword} style={{ display:'flex', flexDirection:'column', gap:14 }}>
            <div>
              <label style={{ display:'block', fontSize:12, fontWeight:600, color:'#374151', marginBottom:6 }}>Email address</label>
              <input type="email" value={resetEmail} onChange={e => setResetEmail(e.target.value)}
                required placeholder="you@example.com.au" style={inputStyle} onFocus={focusBlue} onBlur={blurGrey}/>
            </div>
            <button type="submit" disabled={resetLoading}
              style={{ width:'100%', padding:'11px', borderRadius:11, border:'none', background:'linear-gradient(135deg,#0284c7,#0ea5e9)', color:'#fff', fontSize:14, fontWeight:700, cursor:'pointer', display:'flex', alignItems:'center', justifyContent:'center', gap:8 }}>
              {resetLoading ? <Spinner/> : 'Send Reset Link'}
            </button>
            <button type="button" onClick={() => setForgotMode(false)}
              style={{ fontSize:13, fontWeight:600, color:'#64748b', background:'none', border:'none', cursor:'pointer', textAlign:'center' }}>
              Back to sign in
            </button>
          </form>
        )}
      </>
    )

    // Default: sign in mode
    return (
      <>
        {/* Expired link banner */}
        {linkError && (
          <div style={{ background:'#fff7ed', border:'1px solid #fed7aa', borderRadius:12, padding:'14px 16px', marginBottom:20, display:'flex', gap:10, alignItems:'flex-start' }}>
            <AlertTriangle size={16} color="#ea580c" style={{ flexShrink:0, marginTop:1 }}/>
            <div>
              <p style={{ fontSize:13, fontWeight:700, color:'#9a3412', marginBottom:3 }}>Confirmation link expired</p>
              <p style={{ fontSize:12, color:'#c2410c', lineHeight:1.5, marginBottom:8 }}>This link has expired. Please sign up again to get a fresh confirmation email.</p>
              <Link to="/signup" style={{ fontSize:12, fontWeight:700, color:'#fff', background:'#ea580c', padding:'5px 12px', borderRadius:7, textDecoration:'none', display:'inline-flex', alignItems:'center', gap:5 }}>
                <MailCheck size={12}/> Sign up again
              </Link>
            </div>
          </div>
        )}

        <div style={{ marginBottom:24 }}>
          <h2 style={{ fontSize:17, fontWeight:800, color:'#0f172a', letterSpacing:'-0.3px' }}>Sign in to your account</h2>
          <p style={{ fontSize:12, color:'#94a3b8', marginTop:4 }}>Enter your credentials to continue</p>
        </div>

        <form onSubmit={handleSubmit} style={{ display:'flex', flexDirection:'column', gap:16 }}>
          <div>
            <label style={{ display:'block', fontSize:12, fontWeight:600, color:'#374151', marginBottom:6 }}>Email address</label>
            <input type="email" value={email} onChange={e => setEmail(e.target.value)} required
              placeholder="you@example.com.au" style={inputStyle} onFocus={focusBlue} onBlur={blurGrey}/>
          </div>

          <div>
            <label style={{ display:'block', fontSize:12, fontWeight:600, color:'#374151', marginBottom:6 }}>Password</label>
            <div style={{ position:'relative' }}>
              <input type={showPw ? 'text' : 'password'} value={password} onChange={e => setPassword(e.target.value)}
                required placeholder="••••••••" style={{ ...inputStyle, paddingRight:42 }} onFocus={focusBlue} onBlur={blurGrey}/>
              <button type="button" onClick={() => setShowPw(!showPw)}
                style={{ position:'absolute', right:12, top:'50%', transform:'translateY(-50%)', background:'none', border:'none', cursor:'pointer', color:'#94a3b8', display:'flex', alignItems:'center', padding:0 }}>
                {showPw ? <EyeOff size={15}/> : <Eye size={15}/>}
              </button>
            </div>
          </div>

          {error && (
            <div style={{ background:'#fef2f2', border:'1px solid #fecaca', borderRadius:10, padding:'10px 14px', display:'flex', alignItems:'center', gap:8 }}>
              <div style={{ width:6, height:6, borderRadius:'50%', background:'#ef4444', flexShrink:0 }}/>
              <p style={{ fontSize:12, color:'#dc2626', fontWeight:500 }}>{error}</p>
            </div>
          )}

          <div style={{ textAlign:'right', marginTop:-8 }}>
            <button type="button" onClick={() => { setForgotMode(true); setResetEmail(email) }}
              style={{ fontSize:12, fontWeight:600, color:'#0ea5e9', background:'none', border:'none', cursor:'pointer', padding:0 }}>
              Forgot password?
            </button>
          </div>

          <button type="submit" disabled={loading} style={{
            width:'100%', padding:'11px', borderRadius:11, border:'none',
            background: loading ? 'rgba(14,165,233,0.7)' : 'linear-gradient(135deg,#0284c7,#0ea5e9)',
            color:'#fff', fontSize:14, fontWeight:700, cursor: loading ? 'not-allowed' : 'pointer',
            display:'flex', alignItems:'center', justifyContent:'center', gap:8,
            boxShadow:'0 4px 16px rgba(14,165,233,0.35)', marginTop:4, transition:'opacity 0.15s', fontFamily:'Inter,sans-serif',
          }}>
            {loading ? <Spinner/> : <><LogIn size={15}/> Sign In</>}
          </button>
        </form>

        <p style={{ textAlign:'center', fontSize:12, color:'#94a3b8', marginTop:22 }}>
          Don't have an account?{' '}
          <Link to="/signup" style={{ color:'#0ea5e9', fontWeight:600, textDecoration:'none' }}>Sign up free</Link>
        </p>
      </>
    )
  }

  return (
    <div style={{
      minHeight: '100vh',
      background: 'linear-gradient(160deg,#0d1f3c 0%,#0a3a5c 55%,#062a44 100%)',
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      padding: '24px 16px', position: 'relative', overflow: 'hidden',
    }}>
      <div style={{ position:'absolute', top:'-120px', right:'-120px', width:450, height:450, borderRadius:'50%', background:'radial-gradient(circle,rgba(14,165,233,0.13) 0%,transparent 70%)', pointerEvents:'none' }}/>
      <div style={{ position:'absolute', bottom:'-100px', left:'-100px', width:380, height:380, borderRadius:'50%', background:'radial-gradient(circle,rgba(34,197,94,0.09) 0%,transparent 70%)', pointerEvents:'none' }}/>
      <div style={{ position:'absolute', top:'40%', left:'10%', width:2, height:120, background:'linear-gradient(to bottom,transparent,rgba(14,165,233,0.3),transparent)', pointerEvents:'none' }}/>
      <div style={{ position:'absolute', top:'20%', right:'12%', width:2, height:80, background:'linear-gradient(to bottom,transparent,rgba(34,197,94,0.2),transparent)', pointerEvents:'none' }}/>

      <div style={{ width:'100%', maxWidth:440, position:'relative', zIndex:1 }}>

        {/* Logo */}
        <div style={{ textAlign:'center', marginBottom:32 }}>
          <div style={{ display:'inline-block', background:'rgba(255,255,255,0.97)', borderRadius:16, padding:'0 28px', height:64, overflow:'hidden', marginBottom:16, boxShadow:'0 8px 32px rgba(0,0,0,0.18)', display:'inline-flex', alignItems:'center' }}>
            <img src="/leadflow-logo.png" alt="LeadFlow Digital" style={{ height:82, width:'auto', objectFit:'contain', display:'block', flexShrink:0 }} />
          </div>
          <p style={{ color:'rgba(255,255,255,0.4)', fontSize:13 }}>All-in-one CRM for Australian businesses</p>
        </div>

        {/* Card */}
        <div style={{ background:'#fff', borderRadius:20, padding:'32px 32px 28px', boxShadow:'0 24px 80px rgba(0,0,0,0.35), 0 0 0 1px rgba(255,255,255,0.06)' }}>
          {renderCard()}
        </div>

        {/* Feature pills */}
        <div style={{ display:'flex', justifyContent:'center', gap:12, marginTop:24, flexWrap:'wrap' }}>
          {features.map(({ icon:Icon, text }) => (
            <div key={text} style={{ display:'flex', alignItems:'center', gap:6, background:'rgba(255,255,255,0.06)', border:'1px solid rgba(255,255,255,0.1)', borderRadius:20, padding:'5px 12px' }}>
              <Icon size={11} color="rgba(255,255,255,0.45)"/>
              <span style={{ fontSize:11, color:'rgba(255,255,255,0.4)', fontWeight:500 }}>{text}</span>
            </div>
          ))}
        </div>

        <p style={{ textAlign:'center', color:'rgba(255,255,255,0.2)', fontSize:11, marginTop:20 }}>
          © 2026 LeadFlow Digital. All rights reserved.
        </p>
      </div>

      <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
    </div>
  )
}
