import { createContext, useContext, useState, useCallback, useEffect, useRef } from 'react'
import { supabase } from '../lib/supabase'

const AppContext = createContext(null)

// ─── Static template data (not stored in DB yet) ──────────────────────────────
const INITIAL_EMAIL_TEMPLATES = [
  { id: 1, name: 'New Lead Welcome',     trigger: 'new_lead',          subject: 'Thanks for reaching out!',    body: "Hi {{name}},\n\nThank you for contacting us. We've received your enquiry and will be in touch within 24 hours.\n\nKind regards,\nThe Team", active: true },
  { id: 2, name: 'Booking Confirmation', trigger: 'booking_confirmed', subject: 'Your booking is confirmed',    body: 'Hi {{name}},\n\nYour booking for {{service}} on {{date}} at {{time}} is confirmed.\n\nSee you then!\nThe Team', active: true },
  { id: 3, name: 'Follow-up Reminder',   trigger: 'follow_up',         subject: 'Following up on your enquiry', body: 'Hi {{name}},\n\nJust following up on your recent enquiry. Do you have any questions?\n\nThe Team', active: false },
]

const INITIAL_SMS_TEMPLATES = [
  { id: 1, name: 'New Lead Alert',       trigger: 'new_lead',             message: 'New lead from {{name}} for {{service}}. Call: {{phone}}', active: true },
  { id: 2, name: 'Appointment Reminder', trigger: 'appointment_reminder', message: 'Reminder: Your appointment is tomorrow at {{time}}. Reply CONFIRM or CANCEL.', active: true },
]

// ─── Row mappers (snake_case → camelCase) ─────────────────────────────────────
const mapLead = l => ({
  id: l.id, name: l.name, phone: l.phone, email: l.email,
  service: l.service, message: l.message,
  dateSubmitted: l.date_submitted,
  jobValue: Number(l.job_value) || 0,
  paymentStatus: l.payment_status,
  status: l.status,
  businessId: l.business_id,
  isRecurring: l.is_recurring || false,
  recurringAmount: Number(l.recurring_amount) || 0,
  recurringNextDate: l.recurring_next_date || '',
  recurringNotes: l.recurring_notes || '',
})

const mapBooking = b => ({
  id: b.id, customerName: b.customer_name, phone: b.phone,
  service: b.service, date: b.date, time: b.time,
  businessId: b.business_id,
})

const mapProfile = p => ({
  id: p.id, name: p.name, email: p.email, role: p.role,
  businessId: p.business_id, businessName: p.business_name,
  phone: p.phone, industry: p.industry,
  active: p.active, createdAt: p.created_at,
})

// ─── Provider ─────────────────────────────────────────────────────────────────
export function AppProvider({ children }) {
  const [currentUser,    setCurrentUser]    = useState(null)
  const [authLoading,    setAuthLoading]    = useState(true)
  const [leads,          setLeads]          = useState([])
  const [bookings,       setBookings]       = useState([])
  const [users,          setUsersState]     = useState([])
  const [businesses,     setBusinesses]     = useState([])
  const [emailTemplates, setEmailTemplates] = useState(INITIAL_EMAIL_TEMPLATES)
  const [smsTemplates,   setSmsTemplates]   = useState(INITIAL_SMS_TEMPLATES)
  const [settings,       setSettings]       = useState({
    name: '', phone: '', email: '',
    notifications: { email: true, sms: true, newLead: true, booking: true },
    automations:   { welcomeEmail: true, bookingConfirm: true, followUp: false },
  })

  const currentUserRef = useRef(null)

  // ── Load helpers ────────────────────────────────────────────────────────────
  const loadProfile = useCallback(async (userId) => {
    const { data, error } = await supabase.from('profiles').select('*').eq('id', userId).single()
    if (error || !data) return null
    const user = mapProfile(data)
    currentUserRef.current = user
    setCurrentUser(user)
    return user
  }, [])

  const loadSettings = useCallback(async (businessId) => {
    const { data } = await supabase.from('businesses').select('*').eq('id', businessId).single()
    if (data) setSettings(prev => ({
      ...prev,
      name:         data.name         || '',
      phone:        data.phone        || '',
      email:        data.email        || '',
      twilioSid:    data.twilio_sid   || '',
      twilioToken:  data.twilio_token || '',
      twilioFrom:   data.twilio_from  || '',
      resendKey:    data.resend_key   || '',
    }))
  }, [])

  const loadData = useCallback(async (user) => {
    if (!user) return
    const [leadsRes, bookingsRes] = await Promise.all([
      supabase.from('leads').select('*').order('created_at', { ascending: false }),
      supabase.from('bookings').select('*').order('date', { ascending: true }),
    ])
    if (leadsRes.data)    setLeads(leadsRes.data.map(mapLead))
    if (bookingsRes.data) setBookings(bookingsRes.data.map(mapBooking))
    if (user.businessId)  await loadSettings(user.businessId)
    if (user.role === 'admin') {
      const [profRes, bizRes] = await Promise.all([
        supabase.from('profiles').select('*'),
        supabase.from('businesses').select('*'),
      ])
      if (profRes.data) setUsersState(profRes.data.map(mapProfile))
      if (bizRes.data)  setBusinesses(bizRes.data)
    }
  }, [loadSettings])

  // ── Complete registration after email confirmation ───────────────────────────
  const completeRegistration = useCallback(async (userId, email) => {
    const pendingKey = `jsms_pending_${userId}`
    const pendingRaw = localStorage.getItem(pendingKey)
    if (!pendingRaw) return false
    const { fullName, businessName, phone, industry } = JSON.parse(pendingRaw)
    const { error } = await supabase.rpc('create_business_and_profile', {
      p_user_id:       userId,
      p_full_name:     fullName,
      p_business_name: businessName,
      p_email:         email,
      p_phone:         phone,
      p_industry:      industry,
    })
    if (error) throw error
    localStorage.removeItem(pendingKey)
    return true
  }, [])

  // ── Auth state listener ──────────────────────────────────────────────────────
  useEffect(() => {
    let handled = false

    const handleSession = async (session) => {
      if (!session) {
        currentUserRef.current = null
        setCurrentUser(null)
        setAuthLoading(false)
        return
      }
      if (currentUserRef.current?.id === session.user.id) {
        setAuthLoading(false)
        return
      }
      try {
        if (localStorage.getItem(`jsms_pending_${session.user.id}`)) {
          await completeRegistration(session.user.id, session.user.email)
        }
        const user = await loadProfile(session.user.id)
        if (user) await loadData(user)
      } catch (e) {
        console.error('Session setup error:', e)
      }
      setAuthLoading(false)
    }

    supabase.auth.getSession().then(({ data: { session } }) => {
      if (!handled) {
        handled = true
        // Don't auto-login on password recovery redirects — Login.jsx handles those
        const hash = window.location.hash
        const isRecovery = hash.includes('type=recovery') || hash.includes('type%3Drecovery')
        if (isRecovery) { setAuthLoading(false); return }
        handleSession(session)
      }
    })

    const { data: { subscription } } = supabase.auth.onAuthStateChange((event, session) => {
      if (event === 'PASSWORD_RECOVERY') {
        // User clicked a password reset link — do NOT log them in.
        // Login.jsx handles this event and shows the reset form.
        setAuthLoading(false)
        return
      }
      if (event === 'SIGNED_IN') {
        // Only handle if not already processed (e.g. email confirmation redirect)
        if (!currentUserRef.current && session) {
          handleSession(session)
        }
      } else if (event === 'SIGNED_OUT') {
        currentUserRef.current = null
        setCurrentUser(null)
        setLeads([]); setBookings([]); setUsersState([]); setBusinesses([])
        setAuthLoading(false)
      }
    })

    return () => subscription.unsubscribe()
  }, [loadProfile, loadData, completeRegistration])

  // ── Auth ────────────────────────────────────────────────────────────────────
  const login = useCallback(async (email, password) => {
    const { data, error } = await supabase.auth.signInWithPassword({ email, password })
    if (error) return false

    let { data: profile } = await supabase.from('profiles').select('*').eq('id', data.user.id).single()

    // Profile missing — try to complete registration from pending localStorage data
    if (!profile) {
      const pendingKey = `jsms_pending_${data.user.id}`
      if (localStorage.getItem(pendingKey)) {
        try {
          await completeRegistration(data.user.id, data.user.email)
          const { data: newProfile } = await supabase.from('profiles').select('*').eq('id', data.user.id).single()
          profile = newProfile
        } catch (e) {
          console.error('completeRegistration failed:', e)
        }
      }
    }

    if (!profile) return 'no_profile'
    if (!profile.active) { await supabase.auth.signOut(); return 'disabled' }

    const user = mapProfile(profile)
    currentUserRef.current = user
    setCurrentUser(user)
    await loadData(user)
    return true
  }, [loadData, completeRegistration])

  const logout = useCallback(async () => {
    await supabase.auth.signOut()
    currentUserRef.current = null
    setCurrentUser(null)
    setLeads([]); setBookings([]); setUsersState([]); setBusinesses([])
  }, [])

  const register = useCallback(async ({ fullName, businessName, email, phone, industry, password }) => {
    const { data, error } = await supabase.auth.signUp({
      email, password,
      options: { emailRedirectTo: window.location.origin + '/login' },
    })
    if (error) return { ok: false, error: error.message }

    if (!data.session) {
      localStorage.setItem(`jsms_pending_${data.user.id}`, JSON.stringify({ fullName, businessName, phone, industry }))
      return { ok: false, needsConfirmation: true }
    }

    // Email confirmation disabled — create business + profile via secure RPC
    try {
      const { error: rpcErr } = await supabase.rpc('create_business_and_profile', {
        p_user_id:       data.user.id,
        p_full_name:     fullName,
        p_business_name: businessName,
        p_email:         email,
        p_phone:         phone,
        p_industry:      industry,
      })
      if (rpcErr) throw new Error(rpcErr.message)
      const user = await loadProfile(data.user.id)
      if (user) await loadData(user)
      return { ok: true }
    } catch (e) {
      console.error('Registration error:', e)
      return { ok: false, error: e.message || 'Failed to set up your business. Please try again.' }
    }
  }, [loadProfile, loadData])

  // ── User management (admin) ─────────────────────────────────────────────────
  const deleteUser = useCallback(async (userId) => {
    await supabase.from('profiles').delete().eq('id', userId)
    setUsersState(prev => prev.filter(u => u.id !== userId))
  }, [])

  const toggleUserActive = useCallback(async (userId) => {
    const user = users.find(u => u.id === userId)
    if (!user) return
    const newActive = !user.active
    await supabase.from('profiles').update({ active: newActive }).eq('id', userId)
    setUsersState(prev => prev.map(u => u.id === userId ? { ...u, active: newActive } : u))
  }, [users])

  // ── Leads ───────────────────────────────────────────────────────────────────
  const getLeads = useCallback(() => {
    if (!currentUser) return []
    if (currentUser.role === 'admin') return leads
    return leads.filter(l => l.businessId === currentUser.businessId)
  }, [leads, currentUser])

  // ── Notification helper (calls Supabase Edge Function) ──────────────────────
  const sendNotification = useCallback(async (type, { recipientName, recipientEmail, recipientPhone, service, date, time, businessId }) => {
    try {
      await supabase.functions.invoke('send-notification', {
        body: { type, businessId, recipientName, recipientEmail, recipientPhone, service, date, time },
      })
    } catch (e) {
      console.warn('Notification failed (non-blocking):', e)
    }
  }, [])

  const addLead = useCallback(async (lead) => {
    const { data, error } = await supabase.from('leads').insert({
      name: lead.name, phone: lead.phone, email: lead.email,
      service: lead.service, message: lead.message || '',
      job_value: lead.jobValue || 0, payment_status: 'Unpaid', status: 'New Lead',
      business_id: currentUser?.businessId,
    }).select().single()
    if (!error && data) {
      setLeads(prev => [mapLead(data), ...prev])
      // Fire notification (non-blocking)
      sendNotification('new_lead', {
        recipientName:  lead.name,
        recipientEmail: lead.email,
        recipientPhone: lead.phone,
        service:        lead.service,
        businessId:     currentUser?.businessId,
      })
    }
  }, [currentUser, sendNotification])

  const updateLead = useCallback(async (id, updates) => {
    const db = {}
    if (updates.name             !== undefined) db.name              = updates.name
    if (updates.phone            !== undefined) db.phone             = updates.phone
    if (updates.email            !== undefined) db.email             = updates.email
    if (updates.service          !== undefined) db.service           = updates.service
    if (updates.message          !== undefined) db.message           = updates.message
    if (updates.status           !== undefined) db.status            = updates.status
    if (updates.jobValue         !== undefined) db.job_value         = updates.jobValue
    if (updates.paymentStatus    !== undefined) db.payment_status    = updates.paymentStatus
    if (updates.isRecurring      !== undefined) db.is_recurring      = updates.isRecurring
    if (updates.recurringAmount  !== undefined) db.recurring_amount  = updates.recurringAmount
    if (updates.recurringNextDate !== undefined) db.recurring_next_date = updates.recurringNextDate || null
    if (updates.recurringNotes   !== undefined) db.recurring_notes   = updates.recurringNotes
    const { data, error } = await supabase.from('leads').update(db).eq('id', id).select().single()
    if (!error && data) setLeads(prev => prev.map(l => l.id === id ? mapLead(data) : l))
  }, [])

  const deleteLead = useCallback(async (id) => {
    await supabase.from('leads').delete().eq('id', id)
    setLeads(prev => prev.filter(l => l.id !== id))
  }, [])

  // ── Bookings ────────────────────────────────────────────────────────────────
  const getBookings = useCallback(() => {
    if (!currentUser) return []
    if (currentUser.role === 'admin') return bookings
    return bookings.filter(b => b.businessId === currentUser.businessId)
  }, [bookings, currentUser])

  const addBooking = useCallback(async (booking) => {
    const { data, error } = await supabase.from('bookings').insert({
      customer_name: booking.customerName, phone: booking.phone,
      service: booking.service, date: booking.date, time: booking.time,
      business_id: currentUser?.businessId,
    }).select().single()
    if (!error && data) {
      setBookings(prev => [...prev, mapBooking(data)])
      sendNotification('booking_confirmed', {
        recipientName:  booking.customerName,
        recipientPhone: booking.phone,
        service:        booking.service,
        date:           booking.date,
        time:           booking.time,
        businessId:     currentUser?.businessId,
      })
    }
  }, [currentUser, sendNotification])

  const deleteBooking = useCallback(async (id) => {
    await supabase.from('bookings').delete().eq('id', id)
    setBookings(prev => prev.filter(b => b.id !== id))
  }, [])

  // ── Settings ────────────────────────────────────────────────────────────────
  const updateSettings = useCallback(async (updates) => {
    setSettings(prev => ({ ...prev, ...updates }))
    if (currentUser?.businessId) {
      const db = {}
      if (updates.name        !== undefined) db.name         = updates.name
      if (updates.phone       !== undefined) db.phone        = updates.phone
      if (updates.email       !== undefined) db.email        = updates.email
      if (updates.twilioSid   !== undefined) db.twilio_sid   = updates.twilioSid
      if (updates.twilioToken !== undefined) db.twilio_token = updates.twilioToken
      if (updates.twilioFrom  !== undefined) db.twilio_from  = updates.twilioFrom
      if (updates.resendKey   !== undefined) db.resend_key   = updates.resendKey
      if (Object.keys(db).length) {
        await supabase.from('businesses').update(db).eq('id', currentUser.businessId)
      }
    }
  }, [currentUser])

  // ── Templates ───────────────────────────────────────────────────────────────
  const updateEmailTemplate = useCallback((id, updates) =>
    setEmailTemplates(prev => prev.map(t => t.id === id ? { ...t, ...updates } : t)), [])
  const updateSmsTemplate = useCallback((id, updates) =>
    setSmsTemplates(prev => prev.map(t => t.id === id ? { ...t, ...updates } : t)), [])

  // ── Metrics ─────────────────────────────────────────────────────────────────
  const getMetrics = useCallback(() => {
    const userLeads        = getLeads()
    const completed        = userLeads.filter(l => l.status === 'Completed')
    const revenueGenerated = completed.reduce((s, l) => s + (l.jobValue || 0), 0)
    const cashCollected    = userLeads.filter(l => l.paymentStatus === 'Paid').reduce((s, l) => s + (l.jobValue || 0), 0)
    const outstanding      = revenueGenerated - cashCollected
    const avgJobValue      = completed.length ? revenueGenerated / completed.length : 0
    const today            = new Date().toISOString().split('T')[0]
    const newToday         = userLeads.filter(l => l.dateSubmitted === today).length
    const totalLeads       = userLeads.length
    const conversionRate   = totalLeads ? ((completed.length / totalLeads) * 100).toFixed(1) : 0
    return { revenueGenerated, cashCollected, outstanding, avgJobValue, newToday, totalLeads, conversionRate, completedJobs: completed.length }
  }, [getLeads])

  return (
    <AppContext.Provider value={{
      currentUser, authLoading, login, logout, register,
      users, deleteUser, toggleUserActive,
      leads, getLeads, addLead, updateLead, deleteLead,
      bookings, getBookings, addBooking, deleteBooking,
      emailTemplates, updateEmailTemplate,
      smsTemplates, updateSmsTemplate,
      settings, updateSettings,
      businesses, getMetrics,
    }}>
      {children}
    </AppContext.Provider>
  )
}

export const useApp = () => useContext(AppContext)
