import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom'
import { AppProvider, useApp } from './context/AppContext'
import Layout from './components/Layout'
import Login from './pages/Login'
import SignUp from './pages/SignUp'
import Landing from './pages/Landing'
import LeadForm from './pages/LeadForm'
import Dashboard from './pages/Dashboard'
import Leads from './pages/Leads'
import Pipeline from './pages/Pipeline'
import Bookings from './pages/Bookings'
import Analytics from './pages/Analytics'
import Settings from './pages/Settings'
import UserManagement from './pages/UserManagement'
import Billing from './pages/Billing'
import ResetPassword from './pages/ResetPassword'

function LoadingScreen() {
  return (
    <div style={{
      minHeight: '100vh',
      background: 'linear-gradient(160deg,#0d1f3c 0%,#0a3a5c 50%,#062a44 100%)',
      display: 'flex', alignItems: 'center', justifyContent: 'center', flexDirection: 'column', gap: 24,
    }}>
      <div style={{ position:'absolute', top:'-100px', right:'-100px', width:400, height:400, borderRadius:'50%', background:'radial-gradient(circle,rgba(14,165,233,0.1) 0%,transparent 70%)', pointerEvents:'none' }}/>
      <div style={{ position:'absolute', bottom:'-80px', left:'-80px', width:300, height:300, borderRadius:'50%', background:'radial-gradient(circle,rgba(34,197,94,0.08) 0%,transparent 70%)', pointerEvents:'none' }}/>
      <div style={{ display:'inline-block', background:'rgba(255,255,255,0.97)', borderRadius:20, padding:'14px 32px', boxShadow:'0 8px 32px rgba(0,0,0,0.2)', position:'relative', zIndex:1 }}>
        <img src="/leadflow-logo.png" alt="LeadFlow Digital" style={{ height:96, width:'auto', objectFit:'contain', display:'block' }} />
      </div>
      <div style={{ width: 32, height: 32, border: '3px solid rgba(255,255,255,0.1)', borderTopColor: '#0ea5e9', borderRadius: '50%', animation: 'spin 0.8s linear infinite', position:'relative', zIndex:1 }} />
      <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
    </div>
  )
}

function ProtectedRoute({ children, adminOnly = false }) {
  const { currentUser, authLoading } = useApp()
  if (authLoading) return <LoadingScreen />
  if (!currentUser) return <Navigate to="/login" replace />
  if (adminOnly && currentUser.role !== 'admin') return <Navigate to="/dashboard" replace />
  return <Layout>{children}</Layout>
}


function AppRoutes() {
  const { currentUser, authLoading } = useApp()
  if (authLoading) return <LoadingScreen />
  return (
    <Routes>
      <Route path="/"                element={<Landing />} />
      <Route path="/form/:businessId"  element={<LeadForm />} />
      <Route path="/reset-password"   element={<ResetPassword />} />
      <Route path="/login"  element={currentUser ? <Navigate to="/dashboard" replace /> : <Login />} />
      <Route path="/signup" element={currentUser ? <Navigate to="/dashboard" replace /> : <SignUp />} />
      <Route path="/dashboard"   element={<ProtectedRoute><Dashboard /></ProtectedRoute>} />
      <Route path="/leads"       element={<ProtectedRoute><Leads /></ProtectedRoute>} />
      <Route path="/pipeline"    element={<ProtectedRoute><Pipeline /></ProtectedRoute>} />
      <Route path="/bookings"    element={<ProtectedRoute><Bookings /></ProtectedRoute>} />
      <Route path="/analytics"   element={<ProtectedRoute><Analytics /></ProtectedRoute>} />
      <Route path="/billing"     element={<ProtectedRoute><Billing /></ProtectedRoute>} />
      <Route path="/settings"    element={<ProtectedRoute><Settings /></ProtectedRoute>} />
      <Route path="/users"       element={<ProtectedRoute adminOnly><UserManagement /></ProtectedRoute>} />
      <Route path="*" element={<Navigate to={currentUser ? '/dashboard' : '/'} replace />} />
    </Routes>
  )
}

export default function App() {
  return (
    <BrowserRouter>
      <AppProvider>
        <AppRoutes />
      </AppProvider>
    </BrowserRouter>
  )
}
