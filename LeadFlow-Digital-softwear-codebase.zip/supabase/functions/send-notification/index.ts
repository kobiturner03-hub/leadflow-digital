// Supabase Edge Function: send-notification
// Triggered by the app when a new lead is added or booking is confirmed.
// Sends email via Resend and/or SMS via Twilio based on business settings.
//
// Environment variables required in Supabase Dashboard → Settings → Edge Functions:
//   RESEND_API_KEY      — from resend.com → API Keys
//   RESEND_FROM_EMAIL   — verified sender email e.g. noreply@yourdomain.com.au
//   SUPABASE_URL        — auto-set by Supabase
//   SUPABASE_SERVICE_ROLE_KEY — auto-set by Supabase

import { serve } from 'https://deno.land/std@0.168.0/http/server.ts'
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin':  '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

interface NotificationPayload {
  type:       'new_lead' | 'booking_confirmed' | 'follow_up' | 'appointment_reminder'
  businessId: number
  leadId?:    number
  bookingId?: number
  // Recipient data (passed directly to avoid extra DB reads)
  recipientName:  string
  recipientEmail?: string
  recipientPhone?: string
  service?:  string
  date?:     string
  time?:     string
}

function fillTemplate(template: string, vars: Record<string, string>): string {
  return template.replace(/\{\{(\w+)\}\}/g, (_, key) => vars[key] || '')
}

serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders })

  try {
    const payload: NotificationPayload = await req.json()
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL')!,
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!,
    )

    // Load business + their Twilio credentials
    const { data: biz } = await supabase
      .from('businesses')
      .select('id, name, email, phone, twilio_sid, twilio_token, twilio_from')
      .eq('id', payload.businessId)
      .single()

    if (!biz) return new Response(JSON.stringify({ error: 'Business not found' }), { status: 404, headers: corsHeaders })

    const resendKey   = Deno.env.get('RESEND_API_KEY')
    const fromEmail   = Deno.env.get('RESEND_FROM_EMAIL') || 'noreply@jsmarketingsoftware.com.au'
    const vars = {
      name:    payload.recipientName,
      service: payload.service    || '',
      date:    payload.date       || '',
      time:    payload.time       || '',
      phone:   payload.recipientPhone || '',
    }

    const results: string[] = []

    // ── Email via Resend ──────────────────────────────────────────────────────
    if (resendKey && payload.recipientEmail) {
      const subjects: Record<string, string> = {
        new_lead:             `Thanks for your enquiry, ${payload.recipientName}!`,
        booking_confirmed:    `Your booking is confirmed — ${payload.service}`,
        follow_up:            `Following up on your enquiry`,
        appointment_reminder: `Reminder: your appointment is tomorrow`,
      }
      const bodies: Record<string, string> = {
        new_lead: `Hi ${payload.recipientName},\n\nThank you for contacting ${biz.name}. We've received your enquiry and will be in touch within 24 hours.\n\nKind regards,\n${biz.name}`,
        booking_confirmed: `Hi ${payload.recipientName},\n\nYour booking for ${payload.service} on ${payload.date} at ${payload.time} is confirmed.\n\nSee you then!\n${biz.name}`,
        follow_up: `Hi ${payload.recipientName},\n\nJust following up on your recent enquiry about ${payload.service}. Do you have any questions?\n\n${biz.name}`,
        appointment_reminder: `Hi ${payload.recipientName},\n\nThis is a reminder that your appointment for ${payload.service} is tomorrow at ${payload.time}.\n\n${biz.name}`,
      }

      const emailRes = await fetch('https://api.resend.com/emails', {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${resendKey}`, 'Content-Type': 'application/json' },
        body: JSON.stringify({
          from:    `${biz.name} <${fromEmail}>`,
          to:      [payload.recipientEmail],
          subject: subjects[payload.type] || 'Message from ' + biz.name,
          text:    bodies[payload.type]   || '',
        }),
      })
      const emailData = await emailRes.json()
      results.push(`email:${emailRes.ok ? 'sent' : 'failed:' + emailData.message}`)
    }

    // ── SMS via Twilio ────────────────────────────────────────────────────────
    if (biz.twilio_sid && biz.twilio_token && biz.twilio_from && payload.recipientPhone) {
      const smsMessages: Record<string, string> = {
        new_lead:             `Hi ${payload.recipientName}, thanks for contacting ${biz.name}! We'll be in touch shortly. - ${biz.name}`,
        booking_confirmed:    `Hi ${payload.recipientName}, your booking for ${payload.service} on ${payload.date} at ${payload.time} is confirmed. - ${biz.name}`,
        follow_up:            `Hi ${payload.recipientName}, just following up on your enquiry. Reply or call us. - ${biz.name}`,
        appointment_reminder: `Hi ${payload.recipientName}, reminder: your appointment is tomorrow at ${payload.time}. Reply CONFIRM or CANCEL. - ${biz.name}`,
      }
      const msg = smsMessages[payload.type]
      if (msg) {
        const twilioRes = await fetch(
          `https://api.twilio.com/2010-04-01/Accounts/${biz.twilio_sid}/Messages.json`,
          {
            method: 'POST',
            headers: {
              'Authorization': 'Basic ' + btoa(`${biz.twilio_sid}:${biz.twilio_token}`),
              'Content-Type':  'application/x-www-form-urlencoded',
            },
            body: new URLSearchParams({ To: payload.recipientPhone, From: biz.twilio_from, Body: msg }),
          }
        )
        const twilioData = await twilioRes.json()
        results.push(`sms:${twilioRes.ok ? 'sent' : 'failed:' + twilioData.message}`)
      }
    }

    return new Response(JSON.stringify({ ok: true, results }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    })
  } catch (err) {
    return new Response(JSON.stringify({ error: String(err) }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    })
  }
})
